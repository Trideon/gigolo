-- MySQL dump 10.13  Distrib 5.6.27, for Linux (x86_64)
--
-- Host: localhost    Database: gmagigol_wp960
-- ------------------------------------------------------
-- Server version	5.6.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_commentmeta`
--

DROP TABLE IF EXISTS `wp_commentmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_commentmeta`
--

LOCK TABLES `wp_commentmeta` WRITE;
/*!40000 ALTER TABLE `wp_commentmeta` DISABLE KEYS */;
INSERT INTO `wp_commentmeta` VALUES (1,1,'_wp_trash_meta_status','0');
/*!40000 ALTER TABLE `wp_commentmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_comments`
--

DROP TABLE IF EXISTS `wp_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_comments`
--

LOCK TABLES `wp_comments` WRITE;
/*!40000 ALTER TABLE `wp_comments` DISABLE KEYS */;
INSERT INTO `wp_comments` VALUES (1,1,'oakley sunglasses outlet store','','http://ok.sunglasses-outlet.us.com/','67.227.228.181','2015-10-29 20:57:11','2015-10-30 00:57:11','<strong>oakley sunglasses outlet store</strong>\n\nI’m really impressed with your writing skills as well as with the layout on your blog. Is this a paid theme or did you customize it yourself? Either way keep up the nice quality writing, it is rare to see a nice blog like this one nowadays..',0,'spam','Mozilla/5.0 (Windows NT 6.1; Trident/7.0; rv:11.0) like Gecko','trackback',0,0);
/*!40000 ALTER TABLE `wp_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_iqblock_logging`
--

DROP TABLE IF EXISTS `wp_iqblock_logging`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_iqblock_logging` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `datetime` datetime NOT NULL,
  `ipaddress` tinytext NOT NULL,
  `country` tinytext NOT NULL,
  `url` varchar(250) NOT NULL DEFAULT '/',
  `banned` enum('F','B','A','T') NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_iqblock_logging`
--

LOCK TABLES `wp_iqblock_logging` WRITE;
/*!40000 ALTER TABLE `wp_iqblock_logging` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_iqblock_logging` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_iwp_backup_status`
--

DROP TABLE IF EXISTS `wp_iwp_backup_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_iwp_backup_status` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `historyID` int(11) NOT NULL,
  `taskName` varchar(255) NOT NULL,
  `action` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `stage` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `finalStatus` varchar(50) DEFAULT NULL,
  `statusMsg` varchar(255) NOT NULL,
  `requestParams` text NOT NULL,
  `responseParams` longtext,
  `taskResults` text,
  `startTime` int(11) DEFAULT NULL,
  `endTime` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_iwp_backup_status`
--

LOCK TABLES `wp_iwp_backup_status` WRITE;
/*!40000 ALTER TABLE `wp_iwp_backup_status` DISABLE KEYS */;
INSERT INTO `wp_iwp_backup_status` VALUES (1,5,'Backup Now','now','backup','full','db_dump','processing','0','processing','a:5:{s:9:\"task_name\";s:10:\"Backup Now\";s:9:\"mechanism\";s:10:\"singleCall\";s:4:\"args\";a:15:{s:4:\"type\";s:6:\"backup\";s:6:\"action\";s:3:\"now\";s:4:\"what\";s:4:\"full\";s:15:\"optimize_tables\";s:1:\"1\";s:7:\"exclude\";a:1:{i:0;s:0:\"\";}s:17:\"exclude_file_size\";i:50;s:18:\"exclude_extensions\";s:0:\"\";s:7:\"include\";a:1:{i:0;s:0:\"\";}s:13:\"del_host_file\";N;s:12:\"disable_comp\";s:1:\"1\";s:12:\"fail_safe_db\";N;s:15:\"fail_safe_files\";N;s:5:\"limit\";s:1:\"5\";s:11:\"backup_name\";s:5:\"test1\";s:9:\"parentHID\";i:5;}s:8:\"username\";s:7:\"trideon\";s:12:\"account_info\";N;}',NULL,'a:1:{s:15:\"backhack_status\";a:2:{s:14:\"adminHistoryID\";i:5;s:7:\"db_dump\";a:1:{s:5:\"start\";d:1447498767.0809180736541748046875;}}}',1447498767,0);
/*!40000 ALTER TABLE `wp_iwp_backup_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_links`
--

DROP TABLE IF EXISTS `wp_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_links`
--

LOCK TABLES `wp_links` WRITE;
/*!40000 ALTER TABLE `wp_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_options`
--

DROP TABLE IF EXISTS `wp_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6069 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_options`
--

LOCK TABLES `wp_options` WRITE;
/*!40000 ALTER TABLE `wp_options` DISABLE KEYS */;
INSERT INTO `wp_options` VALUES (1,'siteurl','http://gmagigolo.com','yes');
INSERT INTO `wp_options` VALUES (2,'home','http://gmagigolo.com','yes');
INSERT INTO `wp_options` VALUES (3,'blogname','gMaGigolo','yes');
INSERT INTO `wp_options` VALUES (4,'blogdescription','here, let me google that for you.','yes');
INSERT INTO `wp_options` VALUES (5,'users_can_register','0','yes');
INSERT INTO `wp_options` VALUES (6,'admin_email','trideon@gmail.com','yes');
INSERT INTO `wp_options` VALUES (7,'start_of_week','1','yes');
INSERT INTO `wp_options` VALUES (8,'use_balanceTags','0','yes');
INSERT INTO `wp_options` VALUES (9,'use_smilies','1','yes');
INSERT INTO `wp_options` VALUES (10,'require_name_email','1','yes');
INSERT INTO `wp_options` VALUES (11,'comments_notify','','yes');
INSERT INTO `wp_options` VALUES (12,'posts_per_rss','10','yes');
INSERT INTO `wp_options` VALUES (13,'rss_use_excerpt','0','yes');
INSERT INTO `wp_options` VALUES (14,'mailserver_url','mail.example.com','yes');
INSERT INTO `wp_options` VALUES (15,'mailserver_login','login@example.com','yes');
INSERT INTO `wp_options` VALUES (16,'mailserver_pass','password','yes');
INSERT INTO `wp_options` VALUES (17,'mailserver_port','110','yes');
INSERT INTO `wp_options` VALUES (18,'default_category','1','yes');
INSERT INTO `wp_options` VALUES (19,'default_comment_status','closed','yes');
INSERT INTO `wp_options` VALUES (20,'default_ping_status','closed','yes');
INSERT INTO `wp_options` VALUES (21,'default_pingback_flag','1','yes');
INSERT INTO `wp_options` VALUES (22,'posts_per_page','10','yes');
INSERT INTO `wp_options` VALUES (23,'date_format','F j, Y','yes');
INSERT INTO `wp_options` VALUES (24,'time_format','g:i a','yes');
INSERT INTO `wp_options` VALUES (25,'links_updated_date_format','F j, Y g:i a','yes');
INSERT INTO `wp_options` VALUES (26,'comment_moderation','1','yes');
INSERT INTO `wp_options` VALUES (27,'moderation_notify','1','yes');
INSERT INTO `wp_options` VALUES (28,'permalink_structure','','yes');
INSERT INTO `wp_options` VALUES (29,'gzipcompression','0','yes');
INSERT INTO `wp_options` VALUES (30,'hack_file','0','yes');
INSERT INTO `wp_options` VALUES (31,'blog_charset','UTF-8','yes');
INSERT INTO `wp_options` VALUES (32,'moderation_keys','','no');
INSERT INTO `wp_options` VALUES (33,'active_plugins','a:3:{i:0;s:41:\"dw-question-answer/dw-question-answer.php\";i:1;s:19:\"iwp-client/init.php\";i:2;s:23:\"wordfence/wordfence.php\";}','yes');
INSERT INTO `wp_options` VALUES (34,'category_base','','yes');
INSERT INTO `wp_options` VALUES (35,'ping_sites','http://rpc.pingomatic.com/','yes');
INSERT INTO `wp_options` VALUES (36,'advanced_edit','0','yes');
INSERT INTO `wp_options` VALUES (37,'comment_max_links','2','yes');
INSERT INTO `wp_options` VALUES (38,'gmt_offset','-4','yes');
INSERT INTO `wp_options` VALUES (39,'default_email_category','1','yes');
INSERT INTO `wp_options` VALUES (40,'recently_edited','','no');
INSERT INTO `wp_options` VALUES (41,'template','gridster-lite','yes');
INSERT INTO `wp_options` VALUES (42,'stylesheet','gridster-lite','yes');
INSERT INTO `wp_options` VALUES (43,'comment_whitelist','1','yes');
INSERT INTO `wp_options` VALUES (44,'blacklist_keys','','no');
INSERT INTO `wp_options` VALUES (45,'comment_registration','1','yes');
INSERT INTO `wp_options` VALUES (46,'html_type','text/html','yes');
INSERT INTO `wp_options` VALUES (47,'use_trackback','0','yes');
INSERT INTO `wp_options` VALUES (48,'default_role','subscriber','yes');
INSERT INTO `wp_options` VALUES (49,'db_version','33056','yes');
INSERT INTO `wp_options` VALUES (50,'uploads_use_yearmonth_folders','1','yes');
INSERT INTO `wp_options` VALUES (51,'upload_path','','yes');
INSERT INTO `wp_options` VALUES (52,'blog_public','1','yes');
INSERT INTO `wp_options` VALUES (53,'default_link_category','2','yes');
INSERT INTO `wp_options` VALUES (54,'show_on_front','posts','yes');
INSERT INTO `wp_options` VALUES (55,'tag_base','','yes');
INSERT INTO `wp_options` VALUES (56,'show_avatars','1','yes');
INSERT INTO `wp_options` VALUES (57,'avatar_rating','PG','yes');
INSERT INTO `wp_options` VALUES (58,'upload_url_path','','yes');
INSERT INTO `wp_options` VALUES (59,'thumbnail_size_w','150','yes');
INSERT INTO `wp_options` VALUES (60,'thumbnail_size_h','150','yes');
INSERT INTO `wp_options` VALUES (61,'thumbnail_crop','1','yes');
INSERT INTO `wp_options` VALUES (62,'medium_size_w','300','yes');
INSERT INTO `wp_options` VALUES (63,'medium_size_h','300','yes');
INSERT INTO `wp_options` VALUES (64,'avatar_default','gravatar_default','yes');
INSERT INTO `wp_options` VALUES (65,'large_size_w','1024','yes');
INSERT INTO `wp_options` VALUES (66,'large_size_h','1024','yes');
INSERT INTO `wp_options` VALUES (67,'image_default_link_type','file','yes');
INSERT INTO `wp_options` VALUES (68,'image_default_size','','yes');
INSERT INTO `wp_options` VALUES (69,'image_default_align','','yes');
INSERT INTO `wp_options` VALUES (70,'close_comments_for_old_posts','','yes');
INSERT INTO `wp_options` VALUES (71,'close_comments_days_old','14','yes');
INSERT INTO `wp_options` VALUES (72,'thread_comments','1','yes');
INSERT INTO `wp_options` VALUES (73,'thread_comments_depth','5','yes');
INSERT INTO `wp_options` VALUES (74,'page_comments','','yes');
INSERT INTO `wp_options` VALUES (75,'comments_per_page','50','yes');
INSERT INTO `wp_options` VALUES (76,'default_comments_page','newest','yes');
INSERT INTO `wp_options` VALUES (77,'comment_order','asc','yes');
INSERT INTO `wp_options` VALUES (78,'sticky_posts','a:0:{}','yes');
INSERT INTO `wp_options` VALUES (79,'widget_categories','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (80,'widget_text','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (81,'widget_rss','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (82,'uninstall_plugins','a:1:{s:37:\"iq-block-country/iq-block-country.php\";s:24:\"iqblockcountry_uninstall\";}','no');
INSERT INTO `wp_options` VALUES (83,'timezone_string','','yes');
INSERT INTO `wp_options` VALUES (84,'page_for_posts','0','yes');
INSERT INTO `wp_options` VALUES (85,'page_on_front','0','yes');
INSERT INTO `wp_options` VALUES (86,'default_post_format','0','yes');
INSERT INTO `wp_options` VALUES (87,'link_manager_enabled','0','yes');
INSERT INTO `wp_options` VALUES (88,'initial_db_version','30133','yes');
INSERT INTO `wp_options` VALUES (89,'wp_user_roles','a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:74:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:9:\"add_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:22:\"dwqa_can_read_question\";b:1;s:22:\"dwqa_can_post_question\";b:1;s:22:\"dwqa_can_edit_question\";b:1;s:24:\"dwqa_can_delete_question\";b:1;s:20:\"dwqa_can_read_answer\";b:1;s:20:\"dwqa_can_post_answer\";b:1;s:20:\"dwqa_can_edit_answer\";b:1;s:22:\"dwqa_can_delete_answer\";b:1;s:21:\"dwqa_can_read_comment\";b:1;s:21:\"dwqa_can_post_comment\";b:1;s:21:\"dwqa_can_edit_comment\";b:1;s:23:\"dwqa_can_delete_comment\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:46:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:22:\"dwqa_can_read_question\";b:1;s:22:\"dwqa_can_post_question\";b:1;s:22:\"dwqa_can_edit_question\";b:1;s:24:\"dwqa_can_delete_question\";b:1;s:20:\"dwqa_can_read_answer\";b:1;s:20:\"dwqa_can_post_answer\";b:1;s:20:\"dwqa_can_edit_answer\";b:1;s:22:\"dwqa_can_delete_answer\";b:1;s:21:\"dwqa_can_read_comment\";b:1;s:21:\"dwqa_can_post_comment\";b:1;s:21:\"dwqa_can_edit_comment\";b:1;s:23:\"dwqa_can_delete_comment\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:16:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:22:\"dwqa_can_read_question\";b:1;s:22:\"dwqa_can_post_question\";b:1;s:20:\"dwqa_can_read_answer\";b:1;s:20:\"dwqa_can_post_answer\";b:1;s:21:\"dwqa_can_read_comment\";b:1;s:21:\"dwqa_can_post_comment\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:11:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"dwqa_can_read_question\";b:1;s:22:\"dwqa_can_post_question\";b:1;s:20:\"dwqa_can_read_answer\";b:1;s:20:\"dwqa_can_post_answer\";b:1;s:21:\"dwqa_can_read_comment\";b:1;s:21:\"dwqa_can_post_comment\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:8:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;s:22:\"dwqa_can_read_question\";b:1;s:22:\"dwqa_can_post_question\";b:1;s:20:\"dwqa_can_read_answer\";b:1;s:20:\"dwqa_can_post_answer\";b:1;s:21:\"dwqa_can_read_comment\";b:1;s:21:\"dwqa_can_post_comment\";b:1;}}}','yes');
INSERT INTO `wp_options` VALUES (90,'widget_search','a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (91,'widget_recent-posts','a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (92,'widget_recent-comments','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (93,'widget_archives','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (94,'widget_meta','a:1:{s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (95,'sidebars_widgets','a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:2:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";}s:13:\"array_version\";i:3;}','yes');
INSERT INTO `wp_options` VALUES (96,'cron','a:16:{i:1447500048;a:1:{s:17:\"dwqa_hourly_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1447500329;a:1:{s:21:\"wordfence_hourly_cron\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1447514729;a:2:{s:26:\"wordfence_daily_autoUpdate\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:20:\"wordfence_daily_cron\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1447519616;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1447519627;a:1:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1447530480;a:1:{s:20:\"wp_maybe_auto_update\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1447544772;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1447558595;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1447629456;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1447704000;a:1:{s:31:\"wordfence_email_activity_report\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1447715368;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1447803277;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1447890945;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1447974113;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1448061248;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}s:7:\"version\";i:2;}','yes');
INSERT INTO `wp_options` VALUES (106,'_transient_random_seed','9a437838bd8575dbb6d4c8cc4d83f1c3','yes');
INSERT INTO `wp_options` VALUES (131,'recently_activated','a:0:{}','yes');
INSERT INTO `wp_options` VALUES (139,'wordfence_version','6.0.20','yes');
INSERT INTO `wp_options` VALUES (140,'wordfenceActivated','1','yes');
INSERT INTO `wp_options` VALUES (141,'wf_plugin_act_error','','yes');
INSERT INTO `wp_options` VALUES (143,'theme_mods_gridster-lite','a:3:{s:16:\"background_color\";s:6:\"52843c\";s:30:\"themefurnacefooter_footer_text\";s:48:\"Thanks for visiting. call 517-325-DUMB for help.\";s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:2;}}','yes');
INSERT INTO `wp_options` VALUES (160,'WPLANG','','yes');
INSERT INTO `wp_options` VALUES (166,'blockcountry_version','1.1.19','yes');
INSERT INTO `wp_options` VALUES (167,'blockcountry_dbversion','121','yes');
INSERT INTO `wp_options` VALUES (168,'blockcountry_blockfrontend','on','yes');
INSERT INTO `wp_options` VALUES (169,'blockcountry_backendnrblocks','0','yes');
INSERT INTO `wp_options` VALUES (170,'blockcountry_frontendnrblocks','0','yes');
INSERT INTO `wp_options` VALUES (171,'blockcountry_header','on','yes');
INSERT INTO `wp_options` VALUES (172,'blockcountry_nrstatistics','15','yes');
INSERT INTO `wp_options` VALUES (173,'blockcountry_backendwhitelist','107.140.168.182','yes');
INSERT INTO `wp_options` VALUES (181,'nav_menu_options','a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}','yes');
INSERT INTO `wp_options` VALUES (193,'category_children','a:0:{}','yes');
INSERT INTO `wp_options` VALUES (274,'auto_core_update_notified','a:4:{s:4:\"type\";s:6:\"manual\";s:5:\"email\";s:17:\"trideon@gmail.com\";s:7:\"version\";s:5:\"4.2.2\";s:9:\"timestamp\";i:1431507320;}','yes');
INSERT INTO `wp_options` VALUES (458,'db_upgraded','','yes');
INSERT INTO `wp_options` VALUES (1585,'dwqa_options','a:11:{s:5:\"pages\";a:3:{s:16:\"archive-question\";s:2:\"14\";s:15:\"submit-question\";s:2:\"15\";i:404;s:1:\"0\";}s:14:\"posts-per-page\";s:1:\"5\";s:23:\"enable-private-question\";s:1:\"1\";s:15:\"single-template\";s:8:\"page.php\";s:23:\"question-new-time-frame\";s:1:\"4\";s:27:\"question-overdue-time-frame\";s:1:\"2\";s:25:\"captcha-google-public-key\";s:0:\"\";s:26:\"captcha-google-private-key\";s:0:\"\";s:16:\"question-rewrite\";s:8:\"question\";s:25:\"question-category-rewrite\";s:17:\"question-category\";s:20:\"question-tag-rewrite\";s:12:\"question-tag\";}','yes');
INSERT INTO `wp_options` VALUES (1587,'dwqa_permission','a:6:{s:13:\"administrator\";a:3:{s:8:\"question\";a:4:{s:4:\"read\";i:1;s:4:\"post\";i:1;s:4:\"edit\";i:1;s:6:\"delete\";i:1;}s:6:\"answer\";a:4:{s:4:\"read\";i:1;s:4:\"post\";i:1;s:4:\"edit\";i:1;s:6:\"delete\";i:1;}s:7:\"comment\";a:4:{s:4:\"read\";i:1;s:4:\"post\";i:1;s:4:\"edit\";i:1;s:6:\"delete\";i:1;}}s:6:\"editor\";a:3:{s:8:\"question\";a:4:{s:4:\"read\";i:1;s:4:\"post\";i:1;s:4:\"edit\";i:1;s:6:\"delete\";i:1;}s:6:\"answer\";a:4:{s:4:\"read\";i:1;s:4:\"post\";i:1;s:4:\"edit\";i:1;s:6:\"delete\";i:1;}s:7:\"comment\";a:4:{s:4:\"read\";i:1;s:4:\"post\";i:1;s:4:\"edit\";i:1;s:6:\"delete\";i:1;}}s:6:\"author\";a:3:{s:8:\"question\";a:4:{s:4:\"read\";i:1;s:4:\"post\";i:1;s:4:\"edit\";i:0;s:6:\"delete\";i:0;}s:6:\"answer\";a:4:{s:4:\"read\";i:1;s:4:\"post\";i:1;s:4:\"edit\";i:0;s:6:\"delete\";i:0;}s:7:\"comment\";a:4:{s:4:\"read\";i:1;s:4:\"post\";i:1;s:4:\"edit\";i:0;s:6:\"delete\";i:0;}}s:11:\"contributor\";a:3:{s:8:\"question\";a:4:{s:4:\"read\";i:1;s:4:\"post\";i:1;s:4:\"edit\";i:0;s:6:\"delete\";i:0;}s:6:\"answer\";a:4:{s:4:\"read\";i:1;s:4:\"post\";i:1;s:4:\"edit\";i:0;s:6:\"delete\";i:0;}s:7:\"comment\";a:4:{s:4:\"read\";i:1;s:4:\"post\";i:1;s:4:\"edit\";i:0;s:6:\"delete\";i:0;}}s:10:\"subscriber\";a:3:{s:8:\"question\";a:4:{s:4:\"read\";i:1;s:4:\"post\";i:1;s:4:\"edit\";i:0;s:6:\"delete\";i:0;}s:6:\"answer\";a:4:{s:4:\"read\";i:1;s:4:\"post\";i:1;s:4:\"edit\";i:0;s:6:\"delete\";i:0;}s:7:\"comment\";a:4:{s:4:\"read\";i:1;s:4:\"post\";i:1;s:4:\"edit\";i:0;s:6:\"delete\";i:0;}}s:9:\"anonymous\";a:3:{s:8:\"question\";a:4:{s:4:\"read\";i:1;s:4:\"post\";i:1;s:4:\"edit\";i:0;s:6:\"delete\";i:0;}s:6:\"answer\";a:4:{s:4:\"read\";i:1;s:4:\"post\";i:0;s:4:\"edit\";i:0;s:6:\"delete\";i:0;}s:7:\"comment\";a:4:{s:4:\"read\";i:1;s:4:\"post\";i:0;s:4:\"edit\";i:0;s:6:\"delete\";i:0;}}}','yes');
INSERT INTO `wp_options` VALUES (1588,'dwqa_has_roles','1','yes');
INSERT INTO `wp_options` VALUES (1603,'dwqa-question_category_children','a:0:{}','yes');
INSERT INTO `wp_options` VALUES (1608,'dwqa_sticky_questions','a:1:{i:0;i:16;}','yes');
INSERT INTO `wp_options` VALUES (1653,'widget_calendar','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (1654,'widget_nav_menu','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (1655,'widget_dwqa-closed-question','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (1656,'widget_dwqa-latest-question','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (1657,'widget_dwqa-popular-question','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (1658,'widget_dwqa-related-question','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (1659,'widget_pages','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (1661,'widget_tag_cloud','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','yes');
INSERT INTO `wp_options` VALUES (6024,'_site_transient_timeout_theme_roots','1447500419','yes');
INSERT INTO `wp_options` VALUES (6025,'_site_transient_theme_roots','a:4:{s:13:\"gridster-lite\";s:7:\"/themes\";s:13:\"twentyfifteen\";s:7:\"/themes\";s:14:\"twentyfourteen\";s:7:\"/themes\";s:14:\"twentythirteen\";s:7:\"/themes\";}','yes');
INSERT INTO `wp_options` VALUES (6026,'_site_transient_timeout_browser_35b9c6fc11746da0c28463cc345f7802','1448103428','yes');
INSERT INTO `wp_options` VALUES (6027,'_site_transient_browser_35b9c6fc11746da0c28463cc345f7802','a:9:{s:8:\"platform\";s:7:\"Windows\";s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:4:\"41.0\";s:10:\"update_url\";s:23:\"http://www.firefox.com/\";s:7:\"img_src\";s:50:\"http://s.wordpress.org/images/browsers/firefox.png\";s:11:\"img_src_ssl\";s:49:\"https://wordpress.org/images/browsers/firefox.png\";s:15:\"current_version\";s:2:\"16\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}','yes');
INSERT INTO `wp_options` VALUES (6029,'_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca','1447541830','no');
INSERT INTO `wp_options` VALUES (6030,'_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca','a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"\n\n\n\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"\n	\n	\n	\n	\n	\n	\n	\n	\n	\n	\n		\n		\n		\n		\n		\n		\n		\n		\n		\n	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"https://wordpress.org/news\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 12 Nov 2015 00:04:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/?v=4.4-beta4-35636\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:39:\"\n		\n		\n		\n		\n				\n		\n		\n\n		\n		\n				\n			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 4.4 Beta 4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/11/wordpress-4-4-beta-4/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 12 Nov 2015 00:04:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=3977\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:337:\"WordPress 4.4 Beta 4 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.4, try the WordPress Beta Tester plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Scott Taylor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1407:\"<p>WordPress 4.4 Beta 4 is now available!</p>\n<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.4, try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href=\"https://wordpress.org/wordpress-4.4-beta4.zip\">download the beta here</a> (zip).</p>\n<p>For more information about what’s new in version 4.4, check out the <a href=\"https://wordpress.org/news/2015/10/wordpress-4-4-beta-1/\" target=\"_blank\">Beta 1</a> blog post. This our final planned beta. Next week will be our first Release Candidate.</p>\n<p>If you think you’ve found a bug, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href=\"https://core.trac.wordpress.org/\">file one on the WordPress Trac</a>. There, you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a> and <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.4\">everything we’ve fixed</a>.</p>\n<p><em>Closer To The End</em><br />\n<em>Tickets Are Being Shuffled</em><br />\n<i>Onward to RC</i></p>\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:36:\"\n		\n		\n		\n		\n				\n		\n\n		\n		\n				\n			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 4.4 Beta 3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/11/wordpress-4-4-beta-3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 04 Nov 2015 22:10:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=3969\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:374:\"WordPress 4.4 Beta 3 is now available for download and testing. This is software still in development, so we don’t recommend that you run it on a production site. To get the beta, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can download the beta here (zip). For more of what’s new in version 4.4, check out [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Scott Taylor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1245:\"<p>WordPress 4.4 Beta 3 is now available for download and testing. This is software still in development, so we don’t recommend that you run it on a production site. To get the beta, try the <a href=\"https://wordpress.org/extend/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href=\"https://wordpress.org/wordpress-4.4-beta3.zip\">download the beta here</a> (zip).</p>\n<p>For more of what’s new in version 4.4, <a href=\"https://wordpress.org/news/2015/10/wordpress-4-4-beta-1/\" target=\"_blank\">check out the Beta 1 blog post</a>.</p>\n<p>If you think you’ve found a bug, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href=\"https://core.trac.wordpress.org/\">file one on the WordPress Trac</a>. There, you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a> and <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.4\">everything we’ve fixed</a>.</p>\n<p><em>Four-four beta three<br />\nEven more activity<br />\nNary a shared term</em></p>\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:36:\"\n		\n		\n		\n		\n				\n		\n\n		\n		\n				\n			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 4.4 Beta 2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/10/wordpress-4-4-beta-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 28 Oct 2015 20:50:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=3966\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:374:\"WordPress 4.4 Beta 2 is now available for download and testing. This is software still in development, so we don’t recommend that you run it on a production site. To get the beta, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can download the beta here (zip). For more of what’s new in version 4.4, check out [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Scott Taylor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1246:\"<p>WordPress 4.4 Beta 2 is now available for download and testing. This is software still in development, so we don’t recommend that you run it on a production site. To get the beta, try the <a href=\"https://wordpress.org/extend/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href=\"https://wordpress.org/wordpress-4.4-beta2.zip\">download the beta here</a> (zip).</p>\n<p>For more of what’s new in version 4.4, <a href=\"https://wordpress.org/news/2015/10/wordpress-4-4-beta-1/\" target=\"_blank\">check out the Beta 1 blog post</a>.</p>\n<p>If you think you’ve found a bug, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href=\"https://core.trac.wordpress.org/\">file one on the WordPress Trac</a>. There, you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a> and <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.4\">everything we’ve fixed</a>.</p>\n<p><em>Four-four beta two<br />\nAnother week of progress<br />\nREST API lives!</em></p>\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:36:\"\n		\n		\n		\n		\n				\n		\n\n		\n		\n				\n			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 4.4 Beta 1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/10/wordpress-4-4-beta-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 22 Oct 2015 23:54:19 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=3926\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:329:\"WordPress 4.4 Beta 1 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.4, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Scott Taylor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4293:\"<p>WordPress 4.4 Beta 1 is now available!</p>\n<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.4, try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\" target=\"_blank\">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href=\"https://wordpress.org/wordpress-4.4-beta1.zip\" target=\"_blank\">download the beta here</a> (zip).</p>\n<p>WordPress 4.4 is slated for release on <a href=\"https://make.wordpress.org/core/version-4-4-project-schedule/\" target=\"_blank\">December 8</a>, but to get there, we need your help testing what we have been working on, including:</p>\n<ul>\n<li><strong>Twenty Sixteen </strong>— The <a href=\"https://make.wordpress.org/core/2015/08/25/introducing-twenty-sixteen/\">newest</a> default theme for WordPress.</li>\n<li><strong>Responsive Images </strong>— WordPress automatically delivers a <a href=\"https://make.wordpress.org/core/2015/09/30/responsive-images-merge-proposal/\">more appropriate image</a> to users depending on a variety of conditions like screen size, viewport size, and screen resolution.</li>\n<li><strong>Embeds </strong>— WordPress can now embed rich content from nearly all sites that support the oEmbed standard — not just YouTube, Flickr, Twitter, and the like. You can even embed <a href=\"https://make.wordpress.org/core/2015/09/30/feature-plugin-merge-proposal-oembed/\">previews of posts</a> from other WordPress sites by pasting the URL on its own line.</li>\n</ul>\n<p>There have been a lot of changes for developers to play with as well:</p>\n<ul>\n<li><strong>REST API (phase 1) </strong>— The underlying infrastructure of the WordPress REST API <a href=\"https://wordpress.org/plugins/rest-api/\">plugin</a> has been <a href=\"https://make.wordpress.org/core/2015/09/21/wp-rest-api-merge-proposal/\">included in WordPress 4.4</a>. Plugin authors can take advantage of this by adding custom endpoints.</li>\n<li><strong>Term Metadata </strong>— Taxonomy term metadata is <a href=\"https://make.wordpress.org/core/2015/09/04/taxonomy-term-metadata-proposal/\">now included</a> in WordPress 4.4. If you&#8217;ve already been using a plugin to implement term metadata, you should read <a href=\"https://make.wordpress.org/core/2015/09/22/preparing-your-plugins-and-your-client-sites-for-termmeta/\">this post</a> on how to prepare. Also, the underlying <code>WP_Term</code> class improves caching when working with terms. (<a href=\"https://core.trac.wordpress.org/ticket/14162\">#14162</a>)</li>\n<li><strong>Improved <code>&lt;title&gt;</code> output</strong> — <code>wp_title()</code> is now deprecated; WordPress can <a href=\"https://make.wordpress.org/core/2015/10/20/document-title-in-4-4/\">handle the rendering</a> of the document title automatically.</li>\n<li><strong>Comments </strong>— Comment queries are now split for performance. Also, the underlying <code>WP_Comment</code> class improves caching and introduces strong-typing. (<a href=\"https://core.trac.wordpress.org/ticket/8071\">#8071</a>, <a href=\"https://core.trac.wordpress.org/ticket/32619\">#32619</a>)</li>\n</ul>\n<p>If you want a more in-depth view of what major changes have made it into 4.4, <a href=\"https://make.wordpress.org/core/tag/4-4/\" target=\"_blank\">check out all 4.4-tagged posts</a> on the main development blog, or check out a <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.4\">list of everything</a> that&#8217;s changed.</p>\n<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\" target=\"_blank\">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href=\"https://make.wordpress.org/core/reports/\" target=\"_blank\">file one on the WordPress Trac</a>. There, you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\" target=\"_blank\">a list of known bugs</a>.</p>\n<p>Happy testing!</p>\n<p><em>Many small changes</em><br />\n<em>Some groundbreaking new features<br />\nFun times had by all<br />\n</em></p>\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:39:\"\n		\n		\n		\n		\n				\n		\n		\n\n		\n		\n				\n			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"WordPress 4.3.1 Security and Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/news/2015/09/wordpress-4-3-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 15 Sep 2015 15:22:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3914\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:439:\"WordPress 4.3.1 is now available. This is a security release for all previous versions and we strongly encourage you to update your sites immediately. This release addresses three issues, including two cross-site scripting vulnerabilities and a potential privilege escalation. WordPress versions 4.3 and earlier are vulnerable to a cross-site scripting vulnerability when processing shortcode tags (CVE-2015-5714). Reported by [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Samuel Sidler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4022:\"<div class=\"storycontent\">\n<p>WordPress 4.3.1 is now available. This is a<strong> security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>\n<p>This release addresses three issues, including two cross-site scripting vulnerabilities and a potential privilege escalation.</p>\n<ul>\n<li>WordPress versions 4.3 and earlier are vulnerable to a cross-site scripting vulnerability when processing shortcode tags (CVE-2015-5714). Reported by Shahar Tal and Netanel Rubin of <a href=\"http://checkpoint.com/\">Check Point</a>.</li>\n<li>A separate cross-site scripting vulnerability was found in the user list table. Reported by Ben Bidner of the WordPress security team.</li>\n<li>Finally, in certain cases, users without proper permissions could publish private posts and make them sticky (CVE-2015-5715). Reported by Shahar Tal and Netanel Rubin of <a href=\"http://checkpoint.com/\">Check Point</a>.</li>\n</ul>\n<p>Our thanks to those who have practiced <a href=\"https://make.wordpress.org/core/handbook/testing/reporting-security-vulnerabilities/\">responsible disclosure</a> of security issues.</p>\n<p>WordPress 4.3.1 also fixes twenty-six bugs. For more information, see the <a href=\"https://codex.wordpress.org/Version_4.3.1\">release notes</a> or consult the <a href=\"https://core.trac.wordpress.org/log/branches/4.3/?rev=34199&amp;stop_rev=33647\">list of changes</a>.</p>\n<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.3.1</a> or venture over to Dashboard → Updates and simply click “Update Now.” Sites that support automatic background updates are already beginning to update to WordPress 4.3.1.</p>\n</div>\n<p>Thanks to everyone who contributed to 4.3.1:</p>\n<p><a href=\"https://profiles.wordpress.org/adamsilverstein\">Adam Silverstein</a>, <a href=\"https://profiles.wordpress.org/afercia\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/azaozz\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/boonebgorges\">Boone Gorges</a>, <a href=\"https://profiles.wordpress.org/kraftbj\">Brandon Kraft</a>, <a href=\"https://profiles.wordpress.org/chriscct7\">chriscct7</a>, <a href=\"https://profiles.wordpress.org/extendwings\">Daisuke Takahashi</a>, <a href=\"https://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/ocean90\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/DrewAPicture\">Drew Jaynes</a>, <a href=\"https://profiles.wordpress.org/dustinbolton\">dustinbolton</a>, <a href=\"https://profiles.wordpress.org/pento\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/hauvong\">hauvong</a>, <a href=\"https://profiles.wordpress.org/macmanx\">James Huff</a>, <a href=\"https://profiles.wordpress.org/jeremyfelt\">Jeremy Felt</a>, <a href=\"https://profiles.wordpress.org/jobst\">jobst</a>, <a href=\"https://profiles.wordpress.org/tyxla\">Marin Atanasov</a>, <a href=\"https://profiles.wordpress.org/celloexpressions\">Nick Halsey</a>, <a href=\"https://profiles.wordpress.org/nikeo\">nikeo</a>, <a href=\"https://profiles.wordpress.org/nbachiyski\">Nikolay Bachiyski</a>, <a href=\"https://profiles.wordpress.org/swissspidy\">Pascal Birchler</a>, <a href=\"https://profiles.wordpress.org/figureone\">Paul Ryan</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/miqrogroove\">Robert Chapin</a>, <a href=\"https://profiles.wordpress.org/otto42\">Samuel Wood</a>, <a href=\"https://profiles.wordpress.org/wonderboymusic\">Scott Taylor</a>, <a href=\"https://profiles.wordpress.org/SergeyBiryukov\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/tmatsuur\">tmatsuur</a>, <a href=\"https://profiles.wordpress.org/liljimmi\">Tracy Levesque</a>, <a href=\"https://profiles.wordpress.org/umeshnevase\">Umesh Nevase</a>, <a href=\"https://profiles.wordpress.org/vortfu\">vortfu</a>, <a href=\"https://profiles.wordpress.org/welcher\">welcher</a>, <a href=\"https://profiles.wordpress.org/westonruter\">Weston Ruter</a></p>\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:36:\"\n		\n		\n		\n		\n				\n		\n\n		\n		\n				\n			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"WordPress 4.3 “Billie”\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"https://wordpress.org/news/2015/08/billie/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 18 Aug 2015 19:12:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:3:\"4.3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3845\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:352:\"Version 4.3 of WordPress, named &#8220;Billie&#8221; in honor of jazz singer Billie Holiday, is available for download or update in your WordPress dashboard. New features in 4.3 make it even easier to format your content and customize your site. Menus in the Customizer Create your menu, update it, and assign it, all while live-previewing in [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:22531:\"<p style=\"margin: 0;height: 0\"><img src=\"https://wordpress.org/news/files/2015/08/WordPress-4-3-billie-1024x574.png\" alt=\"WordPress 4.3 - &quot;Billie&quot;\" width=\"692\" height=\"388\" class=\"alignnone size-large wp-image-3896\" style=\"height:0px;width: 0px;margin: 0\" srcset=\"https://wordpress.org/news/files/2015/08/WordPress-4-3-billie-300x168.png 300w, https://wordpress.org/news/files/2015/08/WordPress-4-3-billie-1024x574.png 1024w\" sizes=\"(max-width: 692px) 100vw, 692px\" /></p>\n<p>Version 4.3 of WordPress, named &#8220;Billie&#8221; in honor of jazz singer <a href=\"https://en.wikipedia.org/wiki/Billie_Holiday\">Billie Holiday</a>, is available for <a href=\"https://wordpress.org/download/\">download</a> or update in your WordPress dashboard. New features in 4.3 make it even easier to format your content and customize your site.</p>\n<p><iframe width=\'692\' height=\'389\' src=\'https://videopress.com/embed/T54Iy7Tw?hd=1\' frameborder=\'0\' allowfullscreen></iframe><script src=\'https://v0.wordpress.com/js/next/videopress-iframe.js?m=1435166243\'></script></p>\n<hr />\n<h2>Menus in the Customizer</h2>\n<div><img src=\"//s.w.org/images/core/4.3/menu-customizer.png\" alt=\"\" /></div>\n<p>Create your menu, update it, and assign it, all while live-previewing in the customizer. The streamlined customizer design provides a mobile-friendly and accessible interface. With every release, it becomes easier and faster to make your site just the way you want it.</p>\n<hr />\n<h2>Formatting Shortcuts</h2>\n<div style=\"margin-bottom: 0\"><div style=\"width: 640px; \" class=\"wp-video\"><!--[if lt IE 9]><script>document.createElement(\'video\');</script><![endif]-->\n<video class=\"wp-video-shortcode\" id=\"video-3845-1\" width=\"640\" height=\"360\" loop=\"1\" autoplay=\"1\" preload=\"metadata\" controls=\"controls\"><source type=\"video/mp4\" src=\"//s.w.org/images/core/4.3/formatting.mp4?_=1\" /><source type=\"video/webm\" src=\"//s.w.org/images/core/4.3/formatting.webm?_=1\" /><source type=\"video/ogg\" src=\"//s.w.org/images/core/4.3/formatting.ogv?_=1\" /><a href=\"//s.w.org/images/core/4.3/formatting.mp4\">//s.w.org/images/core/4.3/formatting.mp4</a></video></div></div>\n<p>Your writing flow just got faster with new formatting shortcuts in WordPress 4.3. Use asterisks to create lists and number signs to make a heading. No more breaking your flow; your text looks great with a <code>*</code> and a <code>#</code>.</p>\n<hr />\n<h2>Site Icons</h2>\n<p><img src=\"//s.w.org/images/core/4.3/site-icon-customizer.png\" alt=\"\" /><br />\n&nbsp;<br />\nSite icons represent your site in browser tabs, bookmark menus, and on the home screen of mobile devices. Add your unique site icon in the customizer; it will even stay in place when you switch themes. Make your whole site reflect your brand.</p>\n<hr />\n<h2>Better Passwords</h2>\n<p><img src=\"//s.w.org/images/core/4.3/better-passwords.png\" alt=\"\" /><br />\n&nbsp;<br />\nKeep your site more secure with WordPress’ improved approach to passwords. Instead of receiving passwords via email, you’ll get a password reset link. When you add new users to your site or edit a user profile, WordPress will automatically generate a secure password.</p>\n<hr />\n<h2>Other improvements</h2>\n<ul>\n<li><strong>A smoother admin experience</strong> &#8211; Refinements to the list view across the admin make your WordPress more accessible and easier to work with on any device.</li>\n<li><strong>Comments turned off on pages</strong> &#8211; All new pages that you create will have comments turned off. Keep discussions to your blog, right where they’re supposed to happen.</li>\n<li><strong>Customize your site quickly</strong> &#8211; Wherever you are on the front-end, you can click the customize link in the toolbar to swiftly make changes to your site.</li>\n</ul>\n<hr />\n<h2>The Team</h2>\n<p><a class=\"alignleft\" href=\"https://profiles.wordpress.org/obenland\"><img src=\"https://www.gravatar.com/avatar/2370ea5912750f4cb0f3c51ae1cbca55?d=mm&amp;s=180&amp;r=G\" alt=\"Konstantin Obenland\" width=\"80\" height=\"80\" /></a>This release was led by <a href=\"http://konstantin.obenland.it/\">Konstantin Obenland</a>, with the help of these fine individuals. There are 246 contributors with props in this release. Pull up some Billie Holiday on your music service of choice, and check out some of their profiles:</p>\n<a href=\"https://profiles.wordpress.org/mercime\">@mercime</a>, <a href=\"https://profiles.wordpress.org/aaroncampbell\">Aaron D. Campbell</a>, <a href=\"https://profiles.wordpress.org/jorbin\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/adamkheckler\">Adam Heckler</a>, <a href=\"https://profiles.wordpress.org/adamsilverstein\">Adam Silverstein</a>, <a href=\"https://profiles.wordpress.org/akibjorklund\">Aki Bjorklund</a>, <a href=\"https://profiles.wordpress.org/akirk\">Alex Kirk</a>, <a href=\"https://profiles.wordpress.org/viper007bond\">Alex Mills (Viper007Bond)</a>, <a href=\"https://profiles.wordpress.org/tellyworth\">Alex Shiels</a>, <a href=\"https://profiles.wordpress.org/deconf\">Alin Marcu</a>, <a href=\"https://profiles.wordpress.org/andfinally\">andfinally</a>, <a href=\"https://profiles.wordpress.org/afercia\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/andg\">Andrea Gandino</a>, <a href=\"https://profiles.wordpress.org/nacin\">Andrew Nacin</a>, <a href=\"https://profiles.wordpress.org/azaozz\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/afragen\">Andy Fragen</a>, <a href=\"https://profiles.wordpress.org/ankit-k-gupta\">Ankit K Gupta</a>, <a href=\"https://profiles.wordpress.org/antpb\">Anthony Burchell</a>, <a href=\"https://profiles.wordpress.org/anubisthejackle\">anubisthejackle</a>, <a href=\"https://profiles.wordpress.org/aramzs\">Aram Zucker-Scharff</a>, <a href=\"https://profiles.wordpress.org/arjunskumar\">Arjun S Kumar</a>, <a href=\"https://profiles.wordpress.org/avnarun\">avnarun</a>, <a href=\"https://profiles.wordpress.org/brad2dabone\">Bad Feather</a>, <a href=\"https://profiles.wordpress.org/bcole808\">Ben Cole</a>, <a href=\"https://profiles.wordpress.org/empireoflight\">Ben Dunkle</a>, <a href=\"https://profiles.wordpress.org/binarykitten\">BinaryKitten</a>, <a href=\"https://profiles.wordpress.org/birgire\">Birgir Erlendsson (birgire)</a>, <a href=\"https://profiles.wordpress.org/bjornjohansen\">Bjorn Johansen</a>, <a href=\"https://profiles.wordpress.org/bolo1988\">bolo1988</a>, <a href=\"https://profiles.wordpress.org/boonebgorges\">Boone B. Gorges</a>, <a href=\"https://profiles.wordpress.org/bradt\">Brad Touesnard</a>, <a href=\"https://profiles.wordpress.org/bramd\">Bram Duvigneau</a>, <a href=\"https://profiles.wordpress.org/kraftbj\">Brandon Kraft</a>, <a href=\"https://profiles.wordpress.org/krogsgard\">Brian Krogsgard</a>, <a href=\"https://profiles.wordpress.org/brianlayman\">Brian Layman</a>, <a href=\"https://profiles.wordpress.org/icaleb\">Caleb Burks</a>, <a href=\"https://profiles.wordpress.org/calevans\">CalEvans</a>, <a href=\"https://profiles.wordpress.org/chasewiseman\">Chase Wiseman</a>, <a href=\"https://profiles.wordpress.org/chipbennett\">Chip Bennett</a>, <a href=\"https://profiles.wordpress.org/chouby\">Chouby</a>, <a href=\"https://profiles.wordpress.org/c3mdigital\">Chris Olbekson</a>, <a href=\"https://profiles.wordpress.org/chriscct7\">chriscct7</a>, <a href=\"https://profiles.wordpress.org/craig-ralston\">Craig Ralston</a>, <a href=\"https://profiles.wordpress.org/extendwings\">Daisuke Takahashi</a>, <a href=\"https://profiles.wordpress.org/danielbachhuber\">Daniel Bachhuber</a>, <a href=\"https://profiles.wordpress.org/redsweater\">Daniel Jalkut (Red Sweater)</a>, <a href=\"https://profiles.wordpress.org/mte90\">Daniele Mte90 Scasciafratte</a>, <a href=\"https://profiles.wordpress.org/daniluk4000\">daniluk4000</a>, <a href=\"https://profiles.wordpress.org/dmchale\">Dave McHale</a>, <a href=\"https://profiles.wordpress.org/daveal\">DaveAl</a>, <a href=\"https://profiles.wordpress.org/davidakennedy\">David A. Kennedy</a>, <a href=\"https://profiles.wordpress.org/dlh\">David Herrera</a>, <a href=\"https://profiles.wordpress.org/daxelrod\">daxelrod</a>, <a href=\"https://profiles.wordpress.org/denis-de-bernardy\">Denis de Bernardy</a>, <a href=\"https://profiles.wordpress.org/realloc\">Dennis Ploetner</a>, <a href=\"https://profiles.wordpress.org/valendesigns\">Derek Herman</a>, <a href=\"https://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/dipeshkakadiya\">dipesh.kakadiya</a>, <a href=\"https://profiles.wordpress.org/dmsnell\">dmsnell</a>, <a href=\"https://profiles.wordpress.org/ocean90\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/drewapicture\">Drew Jaynes</a>, <a href=\"https://profiles.wordpress.org/dustinbolton\">dustinbolton</a>, <a href=\"https://profiles.wordpress.org/kucrut\">Dzikri Aziz</a>, <a href=\"https://profiles.wordpress.org/eclev91\">eclev91</a>, <a href=\"https://profiles.wordpress.org/eligijus\">eligijus</a>, <a href=\"https://profiles.wordpress.org/eliorivero\">Elio Rivero</a>, <a href=\"https://profiles.wordpress.org/iseulde\">Ella Iseulde Van Dorpe</a>, <a href=\"https://profiles.wordpress.org/ericlewis\">Eric Andrew Lewis</a>, <a href=\"https://profiles.wordpress.org/ebinnion\">Eric Binnion</a>, <a href=\"https://profiles.wordpress.org/ericmann\">Eric Mann</a>, <a href=\"https://profiles.wordpress.org/fab1en\">Fabien Quatravaux</a>, <a href=\"https://profiles.wordpress.org/flixos90\">Felix Arntz</a>, <a href=\"https://profiles.wordpress.org/francoeurdavid\">francoeurdavid</a>, <a href=\"https://profiles.wordpress.org/frank-klein\">Frank Klein</a>, <a href=\"https://profiles.wordpress.org/gabrielperezs\">gabrielperezs</a>, <a href=\"https://profiles.wordpress.org/voldemortensen\">Garth Mortensen</a>, <a href=\"https://profiles.wordpress.org/garyj\">Gary Jones</a>, <a href=\"https://profiles.wordpress.org/pento\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/georgestephanis\">George Stephanis</a>, <a href=\"https://profiles.wordpress.org/glennm\">glennm</a>, <a href=\"https://profiles.wordpress.org/gtuk\">gtuk</a>, <a href=\"https://profiles.wordpress.org/hailin\">hailin</a>, <a href=\"https://profiles.wordpress.org/hauvong\">hauvong</a>, <a href=\"https://profiles.wordpress.org/helen\">Helen Hou-Sandí</a>, <a href=\"https://profiles.wordpress.org/henrikakselsen\">henrikakselsen</a>, <a href=\"https://profiles.wordpress.org/hnle\">Hinaloe</a>, <a href=\"https://profiles.wordpress.org/hrishiv90\">Hrishikesh Vaipurkar</a>, <a href=\"https://profiles.wordpress.org/hugobaeta\">Hugo Baeta</a>, <a href=\"https://profiles.wordpress.org/polevaultweb\">Iain Poulson</a>, <a href=\"https://profiles.wordpress.org/imath\">imath</a>, <a href=\"https://profiles.wordpress.org/ipstenu\">Ipstenu (Mika Epstein)</a>, <a href=\"https://profiles.wordpress.org/isaacchapman\">isaacchapman</a>, <a href=\"https://profiles.wordpress.org/izem\">izem</a>, <a href=\"https://profiles.wordpress.org/jdgrimes\">J.D. Grimes</a>, <a href=\"https://profiles.wordpress.org/jacklenox\">Jack Lenox</a>, <a href=\"https://profiles.wordpress.org/jadpm\">jadpm</a>, <a href=\"https://profiles.wordpress.org/macmanx\">James Huff</a>, <a href=\"https://profiles.wordpress.org/jamesgol\">jamesgol</a>, <a href=\"https://profiles.wordpress.org/jancbeck\">jancbeck</a>, <a href=\"https://profiles.wordpress.org/jfarthing84\">Jeff Farthing</a>, <a href=\"https://profiles.wordpress.org/jeremyfelt\">Jeremy Felt</a>, <a href=\"https://profiles.wordpress.org/jpry\">Jeremy Pry</a>, <a href=\"https://profiles.wordpress.org/jmichaelward\">Jeremy Ward</a>, <a href=\"https://profiles.wordpress.org/jesin\">Jesin A</a>, <a href=\"https://profiles.wordpress.org/jipmoors\">jipmoors</a>, <a href=\"https://profiles.wordpress.org/eltobiano\">jjberry</a>, <a href=\"https://profiles.wordpress.org/jobst\">Jobst Schmalenbach</a>, <a href=\"https://profiles.wordpress.org/joedolson\">Joe Dolson</a>, <a href=\"https://profiles.wordpress.org/joehoyle\">Joe Hoyle</a>, <a href=\"https://profiles.wordpress.org/joemcgill\">Joe McGill</a>, <a href=\"https://profiles.wordpress.org/jkudish\">Joey Kudish</a>, <a href=\"https://profiles.wordpress.org/johnbillion\">John Blackbourn</a>, <a href=\"https://profiles.wordpress.org/johnjamesjacoby\">John James Jacoby</a>, <a href=\"https://profiles.wordpress.org/picard102\">John Leschinski</a>, <a href=\"https://profiles.wordpress.org/joostdevalk\">Joost de Valk</a>, <a href=\"https://profiles.wordpress.org/maxxsnake\">Josh Davis</a>, <a href=\"https://profiles.wordpress.org/jpyper\">Jpyper</a>, <a href=\"https://profiles.wordpress.org/jrf\">jrf</a>, <a href=\"https://profiles.wordpress.org/juliobox\">Julio Potier</a>, <a href=\"https://profiles.wordpress.org/jtsternberg\">Justin Sternberg</a>, <a href=\"https://profiles.wordpress.org/ungestaltbar\">Kai</a>, <a href=\"https://profiles.wordpress.org/karinchristen\">karinchristen</a>, <a href=\"https://profiles.wordpress.org/karpstrucking\">karpstrucking</a>, <a href=\"https://profiles.wordpress.org/ryelle\">Kelly Dwan</a>, <a href=\"https://profiles.wordpress.org/kevkoeh\">Kevin Koehler</a>, <a href=\"https://profiles.wordpress.org/kitchin\">kitchin</a>, <a href=\"https://profiles.wordpress.org/ixkaito\">Kite</a>, <a href=\"https://profiles.wordpress.org/kovshenin\">Konstantin Kovshenin</a>, <a href=\"https://profiles.wordpress.org/lancewillett\">Lance Willett</a>, <a href=\"https://profiles.wordpress.org/leewillis77\">Lee Willis</a>, <a href=\"https://profiles.wordpress.org/leogopal\">Leo Gopal</a>, <a href=\"https://profiles.wordpress.org/loushou\">loushou</a>, <a href=\"https://profiles.wordpress.org/lumaraf\">Lumaraf</a>, <a href=\"https://profiles.wordpress.org/tyxla\">Marin Atanasov</a>, <a href=\"https://profiles.wordpress.org/nofearinc\">Mario Peshev</a>, <a href=\"https://profiles.wordpress.org/clorith\">Marius (Clorith)</a>, <a href=\"https://profiles.wordpress.org/markjaquith\">Mark Jaquith</a>, <a href=\"https://profiles.wordpress.org/markoheijnen\">Marko Heijnen</a>, <a href=\"https://profiles.wordpress.org/marsjaninzmarsa\">marsjaninzmarsa</a>, <a href=\"https://profiles.wordpress.org/martinsachse\">martinsachse</a>, <a href=\"https://profiles.wordpress.org/matt\">Matt Mullenweg</a>, <a href=\"https://profiles.wordpress.org/veraxus\">Matt van Andel</a>, <a href=\"https://profiles.wordpress.org/mattwiebe\">Matt Wiebe</a>, <a href=\"https://profiles.wordpress.org/mattyrob\">mattyrob</a>, <a href=\"https://profiles.wordpress.org/melchoyce\">Mel Choyce</a>, <a href=\"https://profiles.wordpress.org/nikonratm\">Michael</a>, <a href=\"https://profiles.wordpress.org/mdawaffe\">Michael Adams (mdawaffe)</a>, <a href=\"https://profiles.wordpress.org/michael-arestad\">Michael Arestad</a>, <a href=\"https://profiles.wordpress.org/michaelryanmcneill\">michaelryanmcneill</a>, <a href=\"https://profiles.wordpress.org/mcguive7\">Mickey Kay</a>, <a href=\"https://profiles.wordpress.org/mihai\">mihai</a>, <a href=\"https://profiles.wordpress.org/mikehansenme\">Mike Hansen</a>, <a href=\"https://profiles.wordpress.org/mnelson4\">Mike Nelson</a>, <a href=\"https://profiles.wordpress.org/dh-shredder\">Mike Schroder</a>, <a href=\"https://profiles.wordpress.org/dimadin\">Milan Dinic</a>, <a href=\"https://profiles.wordpress.org/morganestes\">Morgan Estes</a>, <a href=\"https://profiles.wordpress.org/mrutz\">mrutz</a>, <a href=\"https://profiles.wordpress.org/nabil_kadimi\">nabil_kadimi</a>, <a href=\"https://profiles.wordpress.org/Nao\">Naoko Takano</a>, <a href=\"https://profiles.wordpress.org/nazmulhossainnihal\">Nazmul Hossain Nihal</a>, <a href=\"https://profiles.wordpress.org/nicholas_io\">nicholas_io</a>, <a href=\"https://profiles.wordpress.org/celloexpressions\">Nick Halsey</a>, <a href=\"https://profiles.wordpress.org/nickmomrik\">Nick Momrik</a>, <a href=\"https://profiles.wordpress.org/nikeo\">nikeo</a>, <a href=\"https://profiles.wordpress.org/nbachiyski\">Nikolay Bachiyski</a>, <a href=\"https://profiles.wordpress.org/rabmalin\">Nilambar Sharma</a>, <a href=\"https://profiles.wordpress.org/onnimonni\">Onni Hakala</a>, <a href=\"https://profiles.wordpress.org/ozh\">Ozh</a>, <a href=\"https://profiles.wordpress.org/pareshradadiya-1\">Paresh Radadiya</a>, <a href=\"https://profiles.wordpress.org/swissspidy\">Pascal Birchler</a>, <a href=\"https://profiles.wordpress.org/djpaul\">Paul Gibbs</a>, <a href=\"https://profiles.wordpress.org/figureone\">Paul Ryan</a>, <a href=\"https://profiles.wordpress.org/paulwilde\">Paul Wilde</a>, <a href=\"https://profiles.wordpress.org/pavelevap\">pavelevap</a>, <a href=\"https://profiles.wordpress.org/gungeekatx\">Pete Nelson</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/peterrknight\">PeterRKnight</a>, <a href=\"https://profiles.wordpress.org/philiparthurmoore\">Philip Arthur Moore</a>, <a href=\"https://profiles.wordpress.org/mordauk\">Pippin Williamson</a>, <a href=\"https://profiles.wordpress.org/posykrat\">posykrat</a>, <a href=\"https://profiles.wordpress.org/pragunbhutani\">pragunbhutani</a>, <a href=\"https://profiles.wordpress.org/rachelbaker\">Rachel Baker</a>, <a href=\"https://profiles.wordpress.org/ramiy\">Rami Yushuvaev</a>, <a href=\"https://profiles.wordpress.org/rarylson\">rarylson</a>, <a href=\"https://profiles.wordpress.org/lamosty\">Rastislav Lamos</a>, <a href=\"https://profiles.wordpress.org/rauchg\">rauchg</a>, <a href=\"https://profiles.wordpress.org/ravinderk\">Ravinder Kumar</a>, <a href=\"https://profiles.wordpress.org/rclations\">RC Lations</a>, <a href=\"https://profiles.wordpress.org/greuben\">Reuben Gunday</a>, <a href=\"https://profiles.wordpress.org/rianrietveld\">Rian Rietveld</a>, <a href=\"https://profiles.wordpress.org/ritteshpatel\">Ritesh Patel</a>, <a href=\"https://profiles.wordpress.org/miqrogroove\">Robert Chapin</a>, <a href=\"https://profiles.wordpress.org/rdall\">Robert Dall</a>, <a href=\"https://profiles.wordpress.org/rodrigosprimo\">Rodrigo Primo</a>, <a href=\"https://profiles.wordpress.org/rommelxcastro\">Rommel Castro</a>, <a href=\"https://profiles.wordpress.org/magicroundabout\">Ross Wintle</a>, <a href=\"https://profiles.wordpress.org/rhurling\">Rouven Hurling</a>, <a href=\"https://profiles.wordpress.org/ryan\">Ryan Boren</a>, <a href=\"https://profiles.wordpress.org/rmarks\">Ryan Marks</a>, <a href=\"https://profiles.wordpress.org/rmccue\">Ryan McCue</a>, <a href=\"https://profiles.wordpress.org/ohryan\">Ryan Neudorf</a>, <a href=\"https://profiles.wordpress.org/welcher\">Ryan Welcher</a>, <a href=\"https://profiles.wordpress.org/sagarjadhav\">Sagar Jadhav</a>, <a href=\"https://profiles.wordpress.org/salcode\">Sal Ferrarello</a>, <a href=\"https://profiles.wordpress.org/solarissmoke\">Samir Shah</a>, <a href=\"https://profiles.wordpress.org/santagada\">santagada</a>, <a href=\"https://profiles.wordpress.org/sc0ttkclark\">Scott Kingsley Clark</a>, <a href=\"https://profiles.wordpress.org/coffee2code\">Scott Reilly</a>, <a href=\"https://profiles.wordpress.org/wonderboymusic\">Scott Taylor</a>, <a href=\"https://profiles.wordpress.org/scribu\">scribu</a>, <a href=\"https://profiles.wordpress.org/scruffian\">scruffian</a>, <a href=\"https://profiles.wordpress.org/seanchayes\">Sean Hayes</a>, <a href=\"https://profiles.wordpress.org/sebastiantiede\">Sebastian</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/shooper\">Shawn Hooper</a>, <a href=\"https://profiles.wordpress.org/designsimply\">Sheri Bigelow</a>, <a href=\"https://profiles.wordpress.org/simonwheatley\">Simon Wheatley</a>, <a href=\"https://profiles.wordpress.org/siobhan\">Siobhan</a>, <a href=\"https://profiles.wordpress.org/metodiew\">Stanko Metodiev</a>, <a href=\"https://profiles.wordpress.org/stephdau\">Stephane Daury (stephdau)</a>, <a href=\"https://profiles.wordpress.org/netweb\">Stephen Edgar</a>, <a href=\"https://profiles.wordpress.org/stevegrunwell\">Steve Grunwell</a>, <a href=\"https://profiles.wordpress.org/stevenkword\">Steven Word</a>, <a href=\"https://profiles.wordpress.org/stuartshields\">stuartshields</a>, <a href=\"https://profiles.wordpress.org/sudar\">Sudar Muthu</a>, <a href=\"https://profiles.wordpress.org/sunnyratilal\">Sunny Ratilal</a>, <a href=\"https://profiles.wordpress.org/taka2\">taka2</a>, <a href=\"https://profiles.wordpress.org/tharsheblows\">tharsheblows</a>, <a href=\"https://profiles.wordpress.org/thorbrink\">Thor Brink</a>, <a href=\"https://profiles.wordpress.org/creativeinfusion\">Tim Smith</a>, <a href=\"https://profiles.wordpress.org/tlexcellent\">tlexcellent</a>, <a href=\"https://profiles.wordpress.org/tmatsuur\">tmatsuur</a>, <a href=\"https://profiles.wordpress.org/tobiasbg\">TobiasBg</a>, <a href=\"https://profiles.wordpress.org/tomasm\">Tomas Mackevicius</a>, <a href=\"https://profiles.wordpress.org/tomharrigan\">TomHarrigan</a>, <a href=\"https://profiles.wordpress.org/toro_unit\">Toro_Unit (Hiroshi Urabe)</a>, <a href=\"https://profiles.wordpress.org/toru\">Toru Miki</a>, <a href=\"https://profiles.wordpress.org/liljimmi\">Tracy (LilJimmi) Levesque</a>, <a href=\"https://profiles.wordpress.org/tryon\">Tryon Eggleston</a>, <a href=\"https://profiles.wordpress.org/tywayne\">Ty Carlson</a>, <a href=\"https://profiles.wordpress.org/desaiuditd\">Udit Desai</a>, <a href=\"https://profiles.wordpress.org/umeshnevase\">Umesh Nevase</a>, <a href=\"https://profiles.wordpress.org/vivekbhusal\">vivekbhusal</a>, <a href=\"https://profiles.wordpress.org/vortfu\">vortfu</a>, <a href=\"https://profiles.wordpress.org/westonruter\">Weston Ruter</a>, <a href=\"https://profiles.wordpress.org/willnorris\">Will Norris</a>, <a href=\"https://profiles.wordpress.org/willgladstone\">willgladstone</a>, <a href=\"https://profiles.wordpress.org/earnjam\">William Earnhardt</a>, <a href=\"https://profiles.wordpress.org/willstedt\">willstedt</a>, <a href=\"https://profiles.wordpress.org/yoavf\">Yoav Farhi</a>, <a href=\"https://profiles.wordpress.org/ysalame\">Yuri Salame</a>, <a href=\"https://profiles.wordpress.org/oxymoron\">Zach Wills</a>, <a href=\"https://profiles.wordpress.org/katzwebdesign\">Zack Katz</a>, and <a href=\"https://profiles.wordpress.org/tollmanz\">Zack Tollman</a>.\n<p>&nbsp;</p>\n<p>Special thanks go to <a href=\"http://siobhanmckeown.com/\">Siobhan McKeown</a> for producing the release video, <a href=\"http://hugobaeta.com/\">Hugo Baeta</a> for the design, and <a href=\"http://jacklenox.com/\">Jack Lenox</a> for the voice-over.</p>\n<p>Finally, thanks to all of the contributors who provided subtitles for the release video, which at last count had been translated into 30 languages!</p>\n<p>If you want to follow along or help out, check out <a href=\"https://make.wordpress.org/\">Make WordPress</a> and our <a href=\"https://make.wordpress.org/core/\">core development blog</a>. Thanks for choosing WordPress. See you soon for version 4.4!</p>\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:39:\"\n		\n		\n		\n		\n				\n		\n		\n\n		\n		\n				\n			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"WordPress 4.2.4 Security and Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"https://wordpress.org/news/2015/08/wordpress-4-2-4-security-and-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 04 Aug 2015 12:10:40 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3827\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:397:\"WordPress 4.2.4 is now available. This is a security release for all previous versions and we strongly encourage you to update your sites immediately. This release addresses six issues, including three cross-site scripting vulnerabilities and a potential SQL injection that could be used to compromise a site, which were discovered by Marc-Alexandre Montpas of Sucuri, Helen Hou-Sandí [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Samuel Sidler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2011:\"<p>WordPress 4.2.4 is now available. This is a<strong> security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>\n<p>This release addresses six issues, including three cross-site scripting vulnerabilities and a potential SQL injection that could be used to compromise a site, which were discovered by <a href=\"https://sucuri.net/\">Marc-Alexandre Montpas</a> of Sucuri, <a href=\"http://helenhousandi.com/\">Helen Hou-Sandí</a> of the WordPress security team, <a href=\"http://www.checkpoint.com/\">Netanel Rubin</a> of Check Point, and <a href=\"https://hackerone.com/reactors08\">Ivan Grigorov</a>. It also includes a fix for a potential timing side-channel attack, discovered by <a href=\"http://www.scrutinizer-ci.com/\">Johannes Schmitt</a> of Scrutinizer, and prevents an attacker from locking a post from being edited, discovered by <a href=\"https://www.linkedin.com/in/symbiansymoh\">Mohamed A. Baset</a>.</p>\n<p>Our thanks to those who have practiced <a href=\"https://make.wordpress.org/core/handbook/testing/reporting-security-vulnerabilities/\">responsible disclosure</a> of security issues.</p>\n<p>WordPress 4.2.4 also fixes four bugs. For more information, see the <a href=\"https://codex.wordpress.org/Version_4.2.4\">release notes</a> or consult the <a href=\"https://core.trac.wordpress.org/log/branches/4.2?rev=33573&amp;stop_rev=33396\">list of changes</a>.</p>\n<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.2.4</a> or venture over to Dashboard → Updates and simply click “Update Now.” Sites that support automatic background updates are already beginning to update to WordPress 4.2.4.</p>\n<p><em>Already testing WordPress 4.3? The second release candidate is now available (<a href=\"https://wordpress.org/wordpress-4.3-RC2.zip\">zip</a>) and it contains these fixes. For more on 4.3, see <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-release-candidate/\">the RC 1 announcement post</a>.</em></p>\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:39:\"\n		\n		\n		\n		\n				\n		\n		\n\n		\n		\n				\n			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"WordPress 4.3 Release Candidate\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wordpress.org/news/2015/07/wordpress-4-3-release-candidate/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 29 Jul 2015 23:50:43 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3817\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:340:\"The release candidate for WordPress 4.3 is now available. We&#8217;ve made more than 100 changes since releasing Beta 4 a week ago. RC means we think we’re done, but with millions of users and thousands of plugins and themes, it’s possible we’ve missed something. We hope to ship WordPress 4.3 on Tuesday, August 18, but we [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Konstantin Obenland\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2256:\"<p>The release candidate for WordPress 4.3 is now available.</p>\n<p>We&#8217;ve made more than <a href=\"https://core.trac.wordpress.org/log/trunk?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=33512&amp;stop_rev=33372&amp;limit=120\">100 changes</a> since releasing Beta 4 a week ago. RC means we think we’re done, but with millions of users and thousands of plugins and themes, it’s possible we’ve missed something. We hope to ship WordPress 4.3 on <strong>Tuesday, August 18</strong>, but we need your help to get there.</p>\n<p>If you haven’t tested 4.3 yet, now is the time!</p>\n<p><strong>Think you&#8217;ve found a bug?</strong> Please post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta support forum</a>. If any known issues come up, you&#8217;ll be able to <a href=\"https://core.trac.wordpress.org/report/5\">find them here</a>.</p>\n<p>To test WordPress 4.3 RC1, you can use the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin or you can <a href=\"https://wordpress.org/wordpress-4.3-RC1.zip\">download the release candidate here</a> (zip).</p>\n<p>For more information about what’s new in version 4.3, check out the <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/\">Beta 1</a>, <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/\">Beta 2</a>, <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/\">Beta 3</a>, and <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-4/\">Beta 4</a> blog posts.</p>\n<p><strong>Developers</strong>, please test your plugins and themes against WordPress 4.3 and update your plugin&#8217;s <em>Tested up to</em> version in the readme to 4.3 before next week. If you find compatibility problems, we never want to break things, so please be sure to post to the support forums so we can figure those out before the final release.</p>\n<p>Be sure to <a href=\"https://make.wordpress.org/core/\">follow along the core development blog</a>, where we&#8217;ll continue to post <a href=\"https://make.wordpress.org/core/tag/dev-notes+4-3/\">notes for developers</a> for 4.3.</p>\n<p><em>Drei Monate Arbeit</em><br />\n<em>Endlich das Ziel vor Augen</em><br />\n<em>Bald hab ich Urlaub!</em></p>\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:39:\"\n		\n		\n		\n		\n				\n		\n		\n\n		\n		\n				\n			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"WordPress 4.2.3 Security and Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/news/2015/07/wordpress-4-2-3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 23 Jul 2015 11:21:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3807\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:380:\"WordPress 4.2.3 is now available. This is a security release for all previous versions and we strongly encourage you to update your sites immediately. WordPress versions 4.2.2 and earlier are affected by a cross-site scripting vulnerability, which could allow users with the Contributor or Author role to compromise a site. This was initially reported by Jon Cave and [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Gary Pendergast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2708:\"<p>WordPress 4.2.3 is now available. This is a<strong> security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>\n<p>WordPress versions 4.2.2 and earlier are affected by a cross-site scripting vulnerability, which could allow users with the Contributor or Author role to compromise a site. This was initially reported by <a href=\"https://profiles.wordpress.org/duck_\">Jon Cave</a> and fixed by <a href=\"http://www.miqrogroove.com/\">Robert Chapin</a>, both of the WordPress security team, and later reported by <a href=\"http://klikki.fi/\">Jouko Pynnönen</a>.</p>\n<p>We also fixed an issue where it was possible for a user with Subscriber permissions to create a draft through Quick Draft. Reported by Netanel Rubin from <a href=\"https://www.checkpoint.com/\">Check Point Software Technologies</a>.</p>\n<p>Our thanks to those who have practiced <a href=\"https://make.wordpress.org/core/handbook/reporting-security-vulnerabilities/\">responsible disclosure</a> of security issues.</p>\n<p>WordPress 4.2.3 also contains fixes for 20 bugs from 4.2. For more information, see the <a href=\"https://codex.wordpress.org/Version_4.2.3\">release notes</a> or consult the <a href=\"https://core.trac.wordpress.org/log/branches/4.2?rev=33382&amp;stop_rev=32430\">list of changes</a>.</p>\n<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.2.3</a> or venture over to Dashboard → Updates and simply click “Update Now.” Sites that support automatic background updates are already beginning to update to WordPress 4.2.3.</p>\n<p>Thanks to everyone who contributed to 4.2.3:</p>\n<p><a href=\"https://profiles.wordpress.org/jorbin\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/nacin\">Andrew Nacin</a>, <a href=\"https://profiles.wordpress.org/azaozz\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/boonebgorges\">Boone Gorges</a>, <a href=\"https://profiles.wordpress.org/chriscct7\">Chris Christoff</a>, <a href=\"https://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/ocean90\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/iseulde\">Ella Iseulde Van Dorpe</a>, <a href=\"https://profiles.wordpress.org/gabrielperezs\">Gabriel Pérez</a>, <a href=\"https://profiles.wordpress.org/pento\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/mdawaffe\">Mike Adams</a>, <a href=\"https://profiles.wordpress.org/miqrogroove\">Robert Chapin</a>, <a href=\"https://profiles.wordpress.org/nbachiyski\">Nikolay Bachiyski</a>, <a href=\"https://profiles.wordpress.org/magicroundabout\">Ross Wintle</a>, and <a href=\"https://profiles.wordpress.org/wonderboymusic\">Scott Taylor</a>.</p>\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:39:\"\n		\n		\n		\n		\n				\n		\n		\n\n		\n		\n				\n			\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 4.3 Beta 4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-4/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 22 Jul 2015 21:55:25 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3796\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:337:\"WordPress 4.3 Beta 4 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the WordPress Beta Tester plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Konstantin Obenland\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2212:\"<p>WordPress 4.3 Beta 4 is now available!</p>\n<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href=\"https://wordpress.org/wordpress-4.3-beta4.zip\">download the beta here</a> (zip).</p>\n<p>For more information about what’s new in version 4.3, check out the <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/\">Beta 1</a>, <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/\">Beta 2</a>, and <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/\">Beta 3</a> blog posts. Some of the changes in Beta 4 include:</p>\n<ul>\n<li><span class=\"s1\">Fixed several bugs and broken flows in the </span><span class=\"s1\"><strong>publish box </strong></span><span class=\"s1\">in the edit screen.</span></li>\n<li>Addressed a number of edge cases for word count in the <strong>editor</strong>.</li>\n<li><span class=\"s1\"><strong>Site icons</strong> </span><span class=\"s1\">can now be previewed within the customizer. The feature has been removed from general settings.</span></li>\n<li><strong>Various bug fixes</strong>. We&#8217;ve made <a href=\"https://core.trac.wordpress.org/log/trunk?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=33369&amp;stop_rev=33289\">more than 60 changes</a> in the last week.</li>\n</ul>\n<p>If you think you’ve found a bug, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href=\"https://core.trac.wordpress.org/\">file one on the WordPress Trac</a>. There, you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a> and <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.3\">everything we’ve fixed</a>.</p>\n<p><em>Few Tickets Remain</em><br />\n<em>Edge Cases Disappearing</em><br />\n<em>You Must Test Today</em></p>\n\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:32:\"https://wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"hourly\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";a:9:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Sat, 14 Nov 2015 10:57:09 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:10:\"connection\";s:5:\"close\";s:25:\"strict-transport-security\";s:11:\"max-age=360\";s:13:\"last-modified\";s:29:\"Thu, 12 Nov 2015 00:04:51 GMT\";s:4:\"link\";s:77:\"<https://wordpress.org/news/wp-json/>; rel=\"https://github.com/WP-API/WP-API\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:11:\"HIT lax 250\";}s:5:\"build\";s:14:\"20130911080210\";}','no');
INSERT INTO `wp_options` VALUES (6031,'_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca','1447541830','no');
INSERT INTO `wp_options` VALUES (6032,'_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca','1447498630','no');
INSERT INTO `wp_options` VALUES (6033,'_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9','1447541830','no');
INSERT INTO `wp_options` VALUES (6034,'_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9','1447541830','no');
INSERT INTO `wp_options` VALUES (6035,'_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9','1447498630','no');
INSERT INTO `wp_options` VALUES (6036,'_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109','1447541831','no');
INSERT INTO `wp_options` VALUES (6037,'_transient_feed_b9388c83948825c1edaef0d856b7b109','a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"\n	\n\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:117:\"\n		\n		\n		\n		\n		\n		\n				\n\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n		\n\n	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"WordPress Plugins » View: Popular\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"https://wordpress.org/plugins/browse/popular/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"WordPress Plugins » View: Popular\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 14 Nov 2015 10:27:47 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"http://bbpress.org/?v=1.1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:30:{i:0;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Google XML Sitemaps\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"https://wordpress.org/plugins/google-sitemap-generator/#post-132\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 22:31:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"132@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:105:\"This plugin will generate a special XML sitemap which will help search engines to better index your blog.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Arne Brachhold\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WP Super Cache\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://wordpress.org/plugins/wp-super-cache/#post-2572\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 05 Nov 2007 11:40:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2572@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"A very fast caching engine for WordPress that produces static html files.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Donncha O Caoimh\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"Really Simple CAPTCHA\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"https://wordpress.org/plugins/really-simple-captcha/#post-9542\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 09 Mar 2009 02:17:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"9542@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:138:\"Really Simple CAPTCHA is a CAPTCHA module intended to be called from other plugins. It is originally created for my Contact Form 7 plugin.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Takayuki Miyoshi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Google Analytics by Yoast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/plugins/google-analytics-for-wordpress/#post-2316\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 14 Sep 2007 12:15:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2316@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:124:\"Track your WordPress site easily with the latest tracking codes and lots added data for search result pages and error pages.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Joost de Valk\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Wordfence Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/plugins/wordfence/#post-29832\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 04 Sep 2011 03:13:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"29832@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:138:\"The Wordfence WordPress security plugin provides free enterprise-class WordPress security, protecting your website from hacks and malware.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Wordfence\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Yoast SEO\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://wordpress.org/plugins/wordpress-seo/#post-8321\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 01 Jan 2009 20:34:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"8321@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:114:\"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using Yoast SEO plugin.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Joost de Valk\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"Advanced Custom Fields\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"https://wordpress.org/plugins/advanced-custom-fields/#post-25254\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 17 Mar 2011 04:07:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"25254@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"Customise WordPress with powerful, professional and intuitive fields\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"elliotcondon\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"Jetpack by WordPress.com\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"https://wordpress.org/plugins/jetpack/#post-23862\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 Jan 2011 02:21:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"23862@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"Your WordPress, Simplified.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Tim Moore\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"WP-PageNavi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/plugins/wp-pagenavi/#post-363\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 23:17:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"363@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"Adds a more advanced paging navigation interface.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Lester Chan\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"All in One SEO Pack\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wordpress.org/plugins/all-in-one-seo-pack/#post-753\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 30 Mar 2007 20:08:18 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"753@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:126:\"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"uberdose\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"Regenerate Thumbnails\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"https://wordpress.org/plugins/regenerate-thumbnails/#post-6743\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 23 Aug 2008 14:38:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"6743@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"Allows you to regenerate your thumbnails after changing the thumbnail sizes.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Alex Mills (Viper007Bond)\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Contact Form 7\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://wordpress.org/plugins/contact-form-7/#post-2141\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Aug 2007 12:45:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2141@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"Just another contact form plugin. Simple but flexible.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Takayuki Miyoshi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"WooCommerce - excelling eCommerce\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/plugins/woocommerce/#post-29860\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 05 Sep 2011 08:13:36 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"29860@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:97:\"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"WooThemes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Hello Dolly\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"https://wordpress.org/plugins/hello-dolly/#post-5790\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 29 May 2008 22:11:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"5790@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:150:\"This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in two words sung most famously by Louis Armstrong.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"WordPress Importer\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://wordpress.org/plugins/wordpress-importer/#post-18101\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 May 2010 17:42:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"18101@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Brian Colinger\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"W3 Total Cache\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/plugins/w3-total-cache/#post-12073\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 29 Jul 2009 18:46:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"12073@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:132:\"Easy Web Performance Optimization (WPO) using caching: browser, page, object, database, minify and content delivery network support.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Frederick Townes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"NextGEN Gallery\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/plugins/nextgen-gallery/#post-1169\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 23 Apr 2007 20:08:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"1169@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:121:\"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 13 million downloads.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Alex Rabe\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Akismet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"https://wordpress.org/plugins/akismet/#post-15\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 22:11:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"15@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"Akismet checks your comments against the Akismet Web service to see if they look like spam or not.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"TinyMCE Advanced\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://wordpress.org/plugins/tinymce-advanced/#post-2082\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 27 Jun 2007 15:00:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2082@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Andrew Ozz\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Duplicate Post\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://wordpress.org/plugins/duplicate-post/#post-2646\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 05 Dec 2007 17:40:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2646@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"Clone posts and pages.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Lopo\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Disable Comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wordpress.org/plugins/disable-comments/#post-26907\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 27 May 2011 04:42:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"26907@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:134:\"Allows administrators to globally disable comments on their site. Comments can be disabled according to post type. Multisite friendly.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Samir Shah\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"WP Multibyte Patch\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://wordpress.org/plugins/wp-multibyte-patch/#post-28395\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 14 Jul 2011 12:22:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"28395@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"Multibyte functionality enhancement for the WordPress Japanese package.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"plugin-master\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"Black Studio TinyMCE Widget\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://wordpress.org/plugins/black-studio-tinymce-widget/#post-31973\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 10 Nov 2011 15:06:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"31973@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"The visual editor widget for Wordpress.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Marco Chiesi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"iThemes Security (formerly Better WP Security)\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://wordpress.org/plugins/better-wp-security/#post-21738\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 22 Oct 2010 22:06:05 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"21738@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:150:\"Protect your WordPress site by hiding vital areas of your site, protecting access to important files, preventing brute-force login attempts, detecting\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Chris Wiegman\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"Page Builder by SiteOrigin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wordpress.org/plugins/siteorigin-panels/#post-51888\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 11 Apr 2013 10:36:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"51888@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:111:\"Build responsive page layouts using the widgets you know and love using this simple drag and drop page builder.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Greg Priday\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"Google Analytics Dashboard for WP\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"https://wordpress.org/plugins/google-analytics-dashboard-for-wp/#post-50539\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 10 Mar 2013 17:07:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"50539@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:127:\"Displays Google Analytics reports in your WordPress Dashboard. Inserts the latest Google Analytics tracking code in your pages.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Alin Marcu\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Meta Slider\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/plugins/ml-slider/#post-49521\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 14 Feb 2013 16:56:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"49521@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:145:\"Easy to use WordPress slider plugin. Create SEO optimised responsive slideshows with Nivo Slider, Flex Slider, Coin Slider and Responsive Slides.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Matcha Labs\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"UpdraftPlus Backup and Restoration\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/plugins/updraftplus/#post-38058\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 21 May 2012 15:14:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"38058@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:148:\"Backup and restoration made easy. Complete backups; manual or scheduled (backup to S3, Dropbox, Google Drive, Rackspace, FTP, SFTP, email + others).\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"David Anderson\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"Clef Two-Factor Authentication\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"https://wordpress.org/plugins/wpclef/#post-47509\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 27 Dec 2012 01:25:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"47509@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:138:\"Modern two-factor that people love to use: strong authentication without passwords or tokens; single sign on/off; magical user experience.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Dave Ross\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:30:\"\n			\n			\n			\n			\n			\n			\n					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Duplicator\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"https://wordpress.org/plugins/duplicator/#post-26607\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 16 May 2011 12:15:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"26607@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:88:\"Duplicate, clone, backup, move and transfer an entire site from one location to another.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Cory Lamle\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:46:\"https://wordpress.org/plugins/rss/view/popular\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";a:12:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Sat, 14 Nov 2015 10:57:11 GMT\";s:12:\"content-type\";s:23:\"text/xml; charset=UTF-8\";s:10:\"connection\";s:5:\"close\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:25:\"strict-transport-security\";s:11:\"max-age=360\";s:7:\"expires\";s:29:\"Sat, 14 Nov 2015 11:02:47 GMT\";s:13:\"cache-control\";s:0:\"\";s:6:\"pragma\";s:0:\"\";s:13:\"last-modified\";s:31:\"Sat, 14 Nov 2015 10:27:47 +0000\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:11:\"HIT lax 250\";}s:5:\"build\";s:14:\"20130911080210\";}','no');
INSERT INTO `wp_options` VALUES (6038,'_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109','1447541831','no');
INSERT INTO `wp_options` VALUES (6039,'_transient_feed_mod_b9388c83948825c1edaef0d856b7b109','1447498631','no');
INSERT INTO `wp_options` VALUES (6040,'_transient_timeout_plugin_slugs','1447585060','no');
INSERT INTO `wp_options` VALUES (6041,'_transient_plugin_slugs','a:5:{i:0;s:19:\"akismet/akismet.php\";i:1;s:41:\"dw-question-answer/dw-question-answer.php\";i:2;s:19:\"iwp-client/init.php\";i:3;s:37:\"iq-block-country/iq-block-country.php\";i:4;s:23:\"wordfence/wordfence.php\";}','no');
INSERT INTO `wp_options` VALUES (6042,'_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51','1447541831','no');
INSERT INTO `wp_options` VALUES (6043,'_transient_dash_4077549d03da2e451c8b5f002294ff51','<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2015/11/wordpress-4-4-beta-4/\'>WordPress 4.4 Beta 4</a> <span class=\"rss-date\">November 12, 2015</span><div class=\"rssSummary\">WordPress 4.4 Beta 4 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.4, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can [&hellip;]</div></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'http://wptavern.com/aesop-interactive-llc-acquired-by-anonymous-buyer\'>WPTavern: Aesop Interactive LLC Acquired by Anonymous Buyer</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/tickets-on-sale-for-wordcamp-europe-2016\'>WPTavern: Tickets on Sale for WordCamp Europe 2016</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/buddypress-2-4-0-pietro-contains-major-improvements-to-accessibility\'>WPTavern: BuddyPress 2.4.0 “Pietro” Contains Major Improvements to Accessibility</a></li></ul></div><div class=\"rss-widget\"><ul><li class=\'dashboard-news-plugin\'><span>Popular Plugin:</span> <a href=\'https://wordpress.org/plugins/ml-slider/\' class=\'dashboard-news-plugin-link\'>Meta Slider</a>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=ml-slider&amp;_wpnonce=d8eefcd8b1&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Meta Slider\'>Install</a>)</span></li></ul></div>','no');
INSERT INTO `wp_options` VALUES (6044,'_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a','1447509445','yes');
INSERT INTO `wp_options` VALUES (6045,'_site_transient_poptags_40cd750bba9870f18aada2478b24840a','a:100:{s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";s:4:\"5550\";}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"Post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";s:4:\"3478\";}s:6:\"plugin\";a:3:{s:4:\"name\";s:6:\"plugin\";s:4:\"slug\";s:6:\"plugin\";s:5:\"count\";s:4:\"3435\";}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";s:4:\"2930\";}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";s:4:\"2674\";}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";s:4:\"2131\";}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";s:4:\"2122\";}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";s:4:\"1951\";}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";s:4:\"1918\";}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";s:4:\"1901\";}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";s:4:\"1896\";}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";s:4:\"1842\";}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";s:4:\"1751\";}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"Facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";s:4:\"1552\";}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";s:4:\"1474\";}s:9:\"wordpress\";a:3:{s:4:\"name\";s:9:\"wordpress\";s:4:\"slug\";s:9:\"wordpress\";s:5:\"count\";s:4:\"1434\";}s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";s:4:\"1286\";}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";s:4:\"1264\";}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";s:4:\"1249\";}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";s:4:\"1213\";}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";s:4:\"1105\";}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";s:4:\"1044\";}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";s:4:\"1009\";}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";s:3:\"959\";}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";s:3:\"926\";}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";s:3:\"893\";}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"AJAX\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";s:3:\"861\";}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";s:3:\"852\";}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";s:3:\"844\";}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";s:3:\"841\";}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";s:3:\"821\";}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";s:3:\"786\";}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";s:3:\"752\";}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";s:3:\"719\";}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";s:3:\"713\";}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";s:3:\"712\";}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";s:3:\"710\";}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";s:3:\"709\";}s:10:\"responsive\";a:3:{s:4:\"name\";s:10:\"responsive\";s:4:\"slug\";s:10:\"responsive\";s:5:\"count\";s:3:\"692\";}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";s:3:\"689\";}s:5:\"share\";a:3:{s:4:\"name\";s:5:\"Share\";s:4:\"slug\";s:5:\"share\";s:5:\"count\";s:3:\"687\";}s:10:\"e-commerce\";a:3:{s:4:\"name\";s:10:\"e-commerce\";s:4:\"slug\";s:10:\"e-commerce\";s:5:\"count\";s:3:\"667\";}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";s:3:\"665\";}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";s:3:\"660\";}s:5:\"embed\";a:3:{s:4:\"name\";s:5:\"embed\";s:4:\"slug\";s:5:\"embed\";s:5:\"count\";s:3:\"636\";}s:9:\"analytics\";a:3:{s:4:\"name\";s:9:\"analytics\";s:4:\"slug\";s:9:\"analytics\";s:5:\"count\";s:3:\"624\";}s:3:\"css\";a:3:{s:4:\"name\";s:3:\"CSS\";s:4:\"slug\";s:3:\"css\";s:5:\"count\";s:3:\"618\";}s:6:\"search\";a:3:{s:4:\"name\";s:6:\"search\";s:4:\"slug\";s:6:\"search\";s:5:\"count\";s:3:\"617\";}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:4:\"slug\";s:4:\"form\";s:5:\"count\";s:3:\"611\";}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:4:\"slug\";s:9:\"slideshow\";s:5:\"count\";s:3:\"609\";}s:6:\"custom\";a:3:{s:4:\"name\";s:6:\"custom\";s:4:\"slug\";s:6:\"custom\";s:5:\"count\";s:3:\"589\";}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";s:3:\"587\";}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";s:3:\"572\";}s:6:\"slider\";a:3:{s:4:\"name\";s:6:\"slider\";s:4:\"slug\";s:6:\"slider\";s:5:\"count\";s:3:\"572\";}s:6:\"button\";a:3:{s:4:\"name\";s:6:\"button\";s:4:\"slug\";s:6:\"button\";s:5:\"count\";s:3:\"563\";}s:5:\"theme\";a:3:{s:4:\"name\";s:5:\"theme\";s:4:\"slug\";s:5:\"theme\";s:5:\"count\";s:3:\"562\";}s:4:\"menu\";a:3:{s:4:\"name\";s:4:\"menu\";s:4:\"slug\";s:4:\"menu\";s:5:\"count\";s:3:\"560\";}s:4:\"tags\";a:3:{s:4:\"name\";s:4:\"tags\";s:4:\"slug\";s:4:\"tags\";s:5:\"count\";s:3:\"558\";}s:9:\"dashboard\";a:3:{s:4:\"name\";s:9:\"dashboard\";s:4:\"slug\";s:9:\"dashboard\";s:5:\"count\";s:3:\"551\";}s:10:\"categories\";a:3:{s:4:\"name\";s:10:\"categories\";s:4:\"slug\";s:10:\"categories\";s:5:\"count\";s:3:\"545\";}s:10:\"statistics\";a:3:{s:4:\"name\";s:10:\"statistics\";s:4:\"slug\";s:10:\"statistics\";s:5:\"count\";s:3:\"535\";}s:3:\"ads\";a:3:{s:4:\"name\";s:3:\"ads\";s:4:\"slug\";s:3:\"ads\";s:5:\"count\";s:3:\"514\";}s:6:\"mobile\";a:3:{s:4:\"name\";s:6:\"mobile\";s:4:\"slug\";s:6:\"mobile\";s:5:\"count\";s:3:\"513\";}s:4:\"user\";a:3:{s:4:\"name\";s:4:\"user\";s:4:\"slug\";s:4:\"user\";s:5:\"count\";s:3:\"509\";}s:6:\"editor\";a:3:{s:4:\"name\";s:6:\"editor\";s:4:\"slug\";s:6:\"editor\";s:5:\"count\";s:3:\"507\";}s:7:\"picture\";a:3:{s:4:\"name\";s:7:\"picture\";s:4:\"slug\";s:7:\"picture\";s:5:\"count\";s:3:\"498\";}s:5:\"users\";a:3:{s:4:\"name\";s:5:\"users\";s:4:\"slug\";s:5:\"users\";s:5:\"count\";s:3:\"495\";}s:4:\"list\";a:3:{s:4:\"name\";s:4:\"list\";s:4:\"slug\";s:4:\"list\";s:5:\"count\";s:3:\"491\";}s:7:\"plugins\";a:3:{s:4:\"name\";s:7:\"plugins\";s:4:\"slug\";s:7:\"plugins\";s:5:\"count\";s:3:\"488\";}s:9:\"affiliate\";a:3:{s:4:\"name\";s:9:\"affiliate\";s:4:\"slug\";s:9:\"affiliate\";s:5:\"count\";s:3:\"485\";}s:9:\"multisite\";a:3:{s:4:\"name\";s:9:\"multisite\";s:4:\"slug\";s:9:\"multisite\";s:5:\"count\";s:3:\"466\";}s:6:\"simple\";a:3:{s:4:\"name\";s:6:\"simple\";s:4:\"slug\";s:6:\"simple\";s:5:\"count\";s:3:\"462\";}s:8:\"pictures\";a:3:{s:4:\"name\";s:8:\"pictures\";s:4:\"slug\";s:8:\"pictures\";s:5:\"count\";s:3:\"449\";}s:12:\"contact-form\";a:3:{s:4:\"name\";s:12:\"contact form\";s:4:\"slug\";s:12:\"contact-form\";s:5:\"count\";s:3:\"443\";}s:12:\"social-media\";a:3:{s:4:\"name\";s:12:\"social media\";s:4:\"slug\";s:12:\"social-media\";s:5:\"count\";s:3:\"438\";}s:7:\"contact\";a:3:{s:4:\"name\";s:7:\"contact\";s:4:\"slug\";s:7:\"contact\";s:5:\"count\";s:3:\"437\";}s:10:\"navigation\";a:3:{s:4:\"name\";s:10:\"navigation\";s:4:\"slug\";s:10:\"navigation\";s:5:\"count\";s:3:\"425\";}s:5:\"flash\";a:3:{s:4:\"name\";s:5:\"flash\";s:4:\"slug\";s:5:\"flash\";s:5:\"count\";s:3:\"419\";}s:3:\"url\";a:3:{s:4:\"name\";s:3:\"url\";s:4:\"slug\";s:3:\"url\";s:5:\"count\";s:3:\"415\";}s:4:\"html\";a:3:{s:4:\"name\";s:4:\"html\";s:4:\"slug\";s:4:\"html\";s:5:\"count\";s:3:\"411\";}s:10:\"newsletter\";a:3:{s:4:\"name\";s:10:\"newsletter\";s:4:\"slug\";s:10:\"newsletter\";s:5:\"count\";s:3:\"400\";}s:3:\"api\";a:3:{s:4:\"name\";s:3:\"api\";s:4:\"slug\";s:3:\"api\";s:5:\"count\";s:3:\"397\";}s:4:\"news\";a:3:{s:4:\"name\";s:4:\"News\";s:4:\"slug\";s:4:\"news\";s:5:\"count\";s:3:\"394\";}s:4:\"shop\";a:3:{s:4:\"name\";s:4:\"shop\";s:4:\"slug\";s:4:\"shop\";s:5:\"count\";s:3:\"393\";}s:4:\"meta\";a:3:{s:4:\"name\";s:4:\"meta\";s:4:\"slug\";s:4:\"meta\";s:5:\"count\";s:3:\"391\";}s:9:\"marketing\";a:3:{s:4:\"name\";s:9:\"marketing\";s:4:\"slug\";s:9:\"marketing\";s:5:\"count\";s:3:\"387\";}s:3:\"tag\";a:3:{s:4:\"name\";s:3:\"tag\";s:4:\"slug\";s:3:\"tag\";s:5:\"count\";s:3:\"386\";}s:6:\"events\";a:3:{s:4:\"name\";s:6:\"events\";s:4:\"slug\";s:6:\"events\";s:5:\"count\";s:3:\"382\";}s:9:\"thumbnail\";a:3:{s:4:\"name\";s:9:\"thumbnail\";s:4:\"slug\";s:9:\"thumbnail\";s:5:\"count\";s:3:\"379\";}s:8:\"tracking\";a:3:{s:4:\"name\";s:8:\"tracking\";s:4:\"slug\";s:8:\"tracking\";s:5:\"count\";s:3:\"375\";}s:4:\"text\";a:3:{s:4:\"name\";s:4:\"text\";s:4:\"slug\";s:4:\"text\";s:5:\"count\";s:3:\"375\";}s:8:\"calendar\";a:3:{s:4:\"name\";s:8:\"calendar\";s:4:\"slug\";s:8:\"calendar\";s:5:\"count\";s:3:\"373\";}s:11:\"advertising\";a:3:{s:4:\"name\";s:11:\"advertising\";s:4:\"slug\";s:11:\"advertising\";s:5:\"count\";s:3:\"372\";}s:4:\"code\";a:3:{s:4:\"name\";s:4:\"code\";s:4:\"slug\";s:4:\"code\";s:5:\"count\";s:3:\"372\";}s:6:\"upload\";a:3:{s:4:\"name\";s:6:\"upload\";s:4:\"slug\";s:6:\"upload\";s:5:\"count\";s:3:\"366\";}s:9:\"automatic\";a:3:{s:4:\"name\";s:9:\"automatic\";s:4:\"slug\";s:9:\"automatic\";s:5:\"count\";s:3:\"364\";}s:7:\"sharing\";a:3:{s:4:\"name\";s:7:\"sharing\";s:4:\"slug\";s:7:\"sharing\";s:5:\"count\";s:3:\"363\";}s:8:\"lightbox\";a:3:{s:4:\"name\";s:8:\"lightbox\";s:4:\"slug\";s:8:\"lightbox\";s:5:\"count\";s:3:\"363\";}s:7:\"profile\";a:3:{s:4:\"name\";s:7:\"profile\";s:4:\"slug\";s:7:\"profile\";s:5:\"count\";s:3:\"362\";}s:14:\"administration\";a:3:{s:4:\"name\";s:14:\"administration\";s:4:\"slug\";s:14:\"administration\";s:5:\"count\";s:3:\"360\";}}','yes');
INSERT INTO `wp_options` VALUES (6047,'manage-multiple-blogs','a:2:{s:5:\"blogs\";a:0:{}s:12:\"current_blog\";a:1:{s:4:\"type\";N;}}','yes');
INSERT INTO `wp_options` VALUES (6048,'iwp_client_activate_key','b6a93f63a8c06582769ebaa49763ef2a313b17d6','yes');
INSERT INTO `wp_options` VALUES (6050,'iwp_backup_table_version','1.1','yes');
INSERT INTO `wp_options` VALUES (6051,'iwp_client_replaced_old_hash_backup_files','1','yes');
INSERT INTO `wp_options` VALUES (6052,'iwp_client_public_key','LS0tLS1CRUdJTiBQVUJMSUMgS0VZLS0tLS0KTUlJQklqQU5CZ2txaGtpRzl3MEJBUUVGQUFPQ0FROEFNSUlCQ2dLQ0FRRUF4V1VhTHJqb01NZzRwUitPSGdBNgpZaFVKbHQ5Q0FzcERPcVJ0V3F5VHFtanp6Yk16SFd4RHpCeVlEUG5keXdldThhbXdaMFVjQ1hHOVk5d0xBcEozClJ4OTJ6K2FuZGo3eVZBTmI5MjBPS3hrZXV0djl1aUZBSmZPemczbkREWWdHL2xSelNuZDF6QUl3MmVTVE1PVjEKUVVQS3YrRkc2cXNVY1pwQzdXRFJBcXUvQ2NWU1RXRkR1TmxicVN2VlprVmdKZkllVXdUU1Fxb3ltaUFDV256RgpBbExObHg4aElLaGhrbVVxcjdqRmwwQnJkOWw4VEJ6RzMxN3dNQUkxL01HbGZLejM3T0svemF4N2JjRlR5YiszCnZNdG9pZW9idlFRZEFmYUh1U3FURXdYMHhGcEswWlgwbk80MkRKSmFEaWM4YUtFcWtvYk9Ma0dRU0lqNytZSEkKandJREFRQUIKLS0tLS1FTkQgUFVCTElDIEtFWS0tLS0tCg==','yes');
INSERT INTO `wp_options` VALUES (6053,'iwp_client_action_message_id','5','yes');
INSERT INTO `wp_options` VALUES (6054,'_transient_is_multi_author','0','yes');
INSERT INTO `wp_options` VALUES (6055,'_transient_all_the_cool_cats','1','yes');
INSERT INTO `wp_options` VALUES (6056,'finished_splitting_shared_terms','1','yes');
INSERT INTO `wp_options` VALUES (6061,'_site_transient_update_plugins','O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1447498710;s:7:\"checked\";a:5:{s:19:\"akismet/akismet.php\";s:5:\"3.1.5\";s:41:\"dw-question-answer/dw-question-answer.php\";s:5:\"1.3.3\";s:19:\"iwp-client/init.php\";s:7:\"1.4.2.2\";s:37:\"iq-block-country/iq-block-country.php\";s:6:\"1.1.23\";s:23:\"wordfence/wordfence.php\";s:6:\"6.0.20\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:5:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:2:\"15\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"3.1.5\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.3.1.5.zip\";}s:41:\"dw-question-answer/dw-question-answer.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"45382\";s:4:\"slug\";s:18:\"dw-question-answer\";s:6:\"plugin\";s:41:\"dw-question-answer/dw-question-answer.php\";s:11:\"new_version\";s:5:\"1.3.3\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/dw-question-answer/\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/plugin/dw-question-answer.1.3.3.zip\";}s:19:\"iwp-client/init.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"30314\";s:4:\"slug\";s:10:\"iwp-client\";s:6:\"plugin\";s:19:\"iwp-client/init.php\";s:11:\"new_version\";s:7:\"1.4.2.2\";s:3:\"url\";s:41:\"https://wordpress.org/plugins/iwp-client/\";s:7:\"package\";s:53:\"https://downloads.wordpress.org/plugin/iwp-client.zip\";}s:37:\"iq-block-country/iq-block-country.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"13579\";s:4:\"slug\";s:16:\"iq-block-country\";s:6:\"plugin\";s:37:\"iq-block-country/iq-block-country.php\";s:11:\"new_version\";s:6:\"1.1.23\";s:3:\"url\";s:47:\"https://wordpress.org/plugins/iq-block-country/\";s:7:\"package\";s:66:\"https://downloads.wordpress.org/plugin/iq-block-country.1.1.23.zip\";}s:23:\"wordfence/wordfence.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"25305\";s:4:\"slug\";s:9:\"wordfence\";s:6:\"plugin\";s:23:\"wordfence/wordfence.php\";s:11:\"new_version\";s:6:\"6.0.20\";s:3:\"url\";s:40:\"https://wordpress.org/plugins/wordfence/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/plugin/wordfence.6.0.20.zip\";}}}','yes');
INSERT INTO `wp_options` VALUES (6062,'_site_transient_update_themes','O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1447498701;s:7:\"checked\";a:4:{s:13:\"gridster-lite\";s:7:\"1.0.6.3\";s:13:\"twentyfifteen\";s:3:\"1.3\";s:14:\"twentyfourteen\";s:3:\"1.5\";s:14:\"twentythirteen\";s:3:\"1.6\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}','yes');
INSERT INTO `wp_options` VALUES (6063,'_site_transient_update_core','O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.3.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.3.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.3.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.3.1-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.3.1\";s:7:\"version\";s:5:\"4.3.1\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.1\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1447498702;s:15:\"version_checked\";s:5:\"4.3.1\";s:12:\"translations\";a:0:{}}','yes');
INSERT INTO `wp_options` VALUES (6064,'can_compress_scripts','1','yes');
INSERT INTO `wp_options` VALUES (6068,'iwp_client_backup_tasks','a:1:{s:15:\"backhack_status\";a:2:{s:14:\"adminHistoryID\";i:5;s:7:\"db_dump\";a:1:{s:5:\"start\";d:1447498767.0809180736541748046875;}}}','yes');
/*!40000 ALTER TABLE `wp_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_postmeta`
--

DROP TABLE IF EXISTS `wp_postmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_postmeta`
--

LOCK TABLES `wp_postmeta` WRITE;
/*!40000 ALTER TABLE `wp_postmeta` DISABLE KEYS */;
INSERT INTO `wp_postmeta` VALUES (2,1,'_edit_lock','1429117910:1');
INSERT INTO `wp_postmeta` VALUES (3,1,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (8,7,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (9,7,'_edit_lock','1429155305:1');
INSERT INTO `wp_postmeta` VALUES (10,9,'_menu_item_type','custom');
INSERT INTO `wp_postmeta` VALUES (11,9,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (12,9,'_menu_item_object_id','9');
INSERT INTO `wp_postmeta` VALUES (13,9,'_menu_item_object','custom');
INSERT INTO `wp_postmeta` VALUES (14,9,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (15,9,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (16,9,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (17,9,'_menu_item_url','http://gmagigolo.com/');
INSERT INTO `wp_postmeta` VALUES (19,10,'_menu_item_type','post_type');
INSERT INTO `wp_postmeta` VALUES (20,10,'_menu_item_menu_item_parent','0');
INSERT INTO `wp_postmeta` VALUES (21,10,'_menu_item_object_id','7');
INSERT INTO `wp_postmeta` VALUES (22,10,'_menu_item_object','page');
INSERT INTO `wp_postmeta` VALUES (23,10,'_menu_item_target','');
INSERT INTO `wp_postmeta` VALUES (24,10,'_menu_item_classes','a:1:{i:0;s:0:\"\";}');
INSERT INTO `wp_postmeta` VALUES (25,10,'_menu_item_xfn','');
INSERT INTO `wp_postmeta` VALUES (26,10,'_menu_item_url','');
INSERT INTO `wp_postmeta` VALUES (28,11,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (29,11,'_edit_lock','1429289085:1');
INSERT INTO `wp_postmeta` VALUES (30,11,'_pingme','1');
INSERT INTO `wp_postmeta` VALUES (31,11,'_encloseme','1');
INSERT INTO `wp_postmeta` VALUES (32,16,'_edit_last','1');
INSERT INTO `wp_postmeta` VALUES (33,16,'_edit_lock','1433527519:1');
INSERT INTO `wp_postmeta` VALUES (34,16,'_dwqa_views','8');
INSERT INTO `wp_postmeta` VALUES (35,16,'_dwqa_votes_log','s:14:\"a:1:{i:1;i:1;}\";');
INSERT INTO `wp_postmeta` VALUES (36,16,'_dwqa_votes','1');
INSERT INTO `wp_postmeta` VALUES (37,16,'_dwqa_status','re-open');
/*!40000 ALTER TABLE `wp_postmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_posts`
--

DROP TABLE IF EXISTS `wp_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`),
  KEY `post_name` (`post_name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_posts`
--

LOCK TABLES `wp_posts` WRITE;
/*!40000 ALTER TABLE `wp_posts` DISABLE KEYS */;
INSERT INTO `wp_posts` VALUES (1,1,'2015-04-15 16:46:45','2015-04-15 16:46:45','Nothing to see here, carry on. OR help me test things. See something broken email 0fsgiven@gmagigolo.com','This site is for testing purposes','','publish','open','open','','hello-world','','','2015-04-15 17:14:10','2015-04-15 17:14:10','',0,'http://gmagigolo.com/?p=1',0,'post','',0);
INSERT INTO `wp_posts` VALUES (4,1,'2015-04-15 17:12:42','2015-04-15 17:12:42','Nothing to see here, carry on. OR help me test things. See something broken email 0fsgiven@gmagigolo.com','This site is for testing purposes','','inherit','open','open','','1-autosave-v1','','','2015-04-15 17:12:42','2015-04-15 17:12:42','',1,'http://gmagigolo.com/?p=4',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (5,1,'2015-04-15 17:14:10','2015-04-15 17:14:10','Nothing to see here, carry on. OR help me test things. See something broken email 0fsgiven@gmagigolo.com','This site is for testing purposes','','inherit','open','open','','1-revision-v1','','','2015-04-15 17:14:10','2015-04-15 17:14:10','',1,'http://gmagigolo.com/?p=5',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (7,1,'2015-04-16 03:37:24','2015-04-16 03:37:24','The power of a voice. Crying out over the electronic wilderness without a care about malware or viruses thanks to their trusty hero, the patient Geek.','nothing brings more joy than seeing generations share the internet.','','publish','open','open','','nothing-brings-more-joy-than-seeing-generations-share-the-internet','','','2015-04-16 03:37:24','2015-04-16 03:37:24','',0,'http://gmagigolo.com/?page_id=7',0,'page','',0);
INSERT INTO `wp_posts` VALUES (8,1,'2015-04-16 03:37:24','2015-04-16 03:37:24','The power of a voice. Crying out over the electronic wilderness without a care about malware or viruses thanks to their trusty hero, the patient Geek.','nothing brings more joy than seeing generations share the internet.','','inherit','open','open','','7-revision-v1','','','2015-04-16 03:37:24','2015-04-16 03:37:24','',7,'http://gmagigolo.com/?p=8',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (9,1,'2015-04-16 00:09:13','2015-04-16 04:09:13','','Home','','publish','closed','closed','','home','','','2015-04-16 00:09:23','2015-04-16 04:09:23','',0,'http://gmagigolo.com/?p=9',1,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (10,1,'2015-04-16 00:09:13','2015-04-16 04:09:13','','Internet Ageism.','','publish','closed','closed','','internet-ageism','','','2015-04-16 00:09:23','2015-04-16 04:09:23','',0,'http://gmagigolo.com/?p=10',2,'nav_menu_item','',0);
INSERT INTO `wp_posts` VALUES (11,1,'2015-04-17 12:47:05','2015-04-17 16:47:05','It\'s good for us to go back and learn things we know, again.','Training is fun','','publish','closed','closed','','training-is-fun','','','2015-04-17 12:47:05','2015-04-17 16:47:05','',0,'http://gmagigolo.com/?p=11',0,'post','',0);
INSERT INTO `wp_posts` VALUES (12,1,'2015-04-17 12:47:05','2015-04-17 16:47:05','It\'s good for us to go back and learn things we know, again.','Training is fun','','inherit','closed','closed','','11-revision-v1','','','2015-04-17 12:47:05','2015-04-17 16:47:05','',11,'http://gmagigolo.com/?p=12',0,'revision','',0);
INSERT INTO `wp_posts` VALUES (14,1,'2015-06-05 01:20:00','2015-06-05 05:20:00','[dwqa-list-questions]','DWQA Questions','','publish','closed','closed','','dwqa-questions','','','2015-06-05 01:20:00','2015-06-05 05:20:00','',0,'http://gmagigolo.com/?page_id=14',0,'page','',0);
INSERT INTO `wp_posts` VALUES (15,1,'2015-06-05 01:20:01','2015-06-05 05:20:01','[dwqa-submit-question-form]','DWQA Ask Question','','publish','closed','closed','','dwqa-ask-question','','','2015-06-05 01:20:01','2015-06-05 05:20:01','',0,'http://gmagigolo.com/?page_id=15',0,'page','',0);
INSERT INTO `wp_posts` VALUES (16,1,'2015-06-05 01:21:43','0000-00-00 00:00:00','','What should a Nub Never Do?','','draft','closed','closed','','','','','2015-06-05 01:21:43','2015-06-05 05:21:43','',0,'http://gmagigolo.com/?post_type=dwqa-question&#038;p=16',0,'dwqa-question','',0);
INSERT INTO `wp_posts` VALUES (17,1,'2015-11-14 06:57:08','0000-00-00 00:00:00','','Auto Draft','','auto-draft','closed','closed','','','','','2015-11-14 06:57:08','0000-00-00 00:00:00','',0,'http://gmagigolo.com/?p=17',0,'post','',0);
/*!40000 ALTER TABLE `wp_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_term_relationships`
--

DROP TABLE IF EXISTS `wp_term_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_relationships`
--

LOCK TABLES `wp_term_relationships` WRITE;
/*!40000 ALTER TABLE `wp_term_relationships` DISABLE KEYS */;
INSERT INTO `wp_term_relationships` VALUES (1,1,0);
INSERT INTO `wp_term_relationships` VALUES (9,2,0);
INSERT INTO `wp_term_relationships` VALUES (10,2,0);
INSERT INTO `wp_term_relationships` VALUES (11,1,0);
/*!40000 ALTER TABLE `wp_term_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_term_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_taxonomy`
--

LOCK TABLES `wp_term_taxonomy` WRITE;
/*!40000 ALTER TABLE `wp_term_taxonomy` DISABLE KEYS */;
INSERT INTO `wp_term_taxonomy` VALUES (1,1,'category','',0,2);
INSERT INTO `wp_term_taxonomy` VALUES (2,2,'nav_menu','',0,2);
INSERT INTO `wp_term_taxonomy` VALUES (3,3,'dwqa-question_category','',0,0);
INSERT INTO `wp_term_taxonomy` VALUES (4,4,'dwqa-question_category','',0,0);
INSERT INTO `wp_term_taxonomy` VALUES (5,5,'dwqa-question_category','',0,0);
/*!40000 ALTER TABLE `wp_term_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_terms`
--

DROP TABLE IF EXISTS `wp_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_terms`
--

LOCK TABLES `wp_terms` WRITE;
/*!40000 ALTER TABLE `wp_terms` DISABLE KEYS */;
INSERT INTO `wp_terms` VALUES (1,'Uncategorized','uncategorized',0);
INSERT INTO `wp_terms` VALUES (2,'Menu 1','menu-1',0);
INSERT INTO `wp_terms` VALUES (3,'Questions','questions',0);
INSERT INTO `wp_terms` VALUES (4,'NEVER','never',0);
INSERT INTO `wp_terms` VALUES (5,'ALWAYS','always',0);
/*!40000 ALTER TABLE `wp_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_usermeta`
--

DROP TABLE IF EXISTS `wp_usermeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_usermeta`
--

LOCK TABLES `wp_usermeta` WRITE;
/*!40000 ALTER TABLE `wp_usermeta` DISABLE KEYS */;
INSERT INTO `wp_usermeta` VALUES (1,1,'nickname','trideon');
INSERT INTO `wp_usermeta` VALUES (2,1,'first_name','');
INSERT INTO `wp_usermeta` VALUES (3,1,'last_name','');
INSERT INTO `wp_usermeta` VALUES (4,1,'description','');
INSERT INTO `wp_usermeta` VALUES (5,1,'rich_editing','true');
INSERT INTO `wp_usermeta` VALUES (6,1,'comment_shortcuts','false');
INSERT INTO `wp_usermeta` VALUES (7,1,'admin_color','fresh');
INSERT INTO `wp_usermeta` VALUES (8,1,'use_ssl','0');
INSERT INTO `wp_usermeta` VALUES (9,1,'show_admin_bar_front','true');
INSERT INTO `wp_usermeta` VALUES (10,1,'wp_capabilities','a:1:{s:13:\"administrator\";b:1;}');
INSERT INTO `wp_usermeta` VALUES (11,1,'wp_user_level','10');
INSERT INTO `wp_usermeta` VALUES (12,1,'dismissed_wp_pointers','wp360_locks,wp390_widgets,wp410_dfw,document,settings');
INSERT INTO `wp_usermeta` VALUES (13,1,'show_welcome_panel','0');
INSERT INTO `wp_usermeta` VALUES (15,1,'wp_dashboard_quick_press_last_post_id','17');
INSERT INTO `wp_usermeta` VALUES (16,1,'closedpostboxes_dashboard','a:1:{i:0;s:32:\"wordfence_activity_report_widget\";}');
INSERT INTO `wp_usermeta` VALUES (17,1,'metaboxhidden_dashboard','a:0:{}');
INSERT INTO `wp_usermeta` VALUES (18,1,'managenav-menuscolumnshidden','a:4:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";}');
INSERT INTO `wp_usermeta` VALUES (19,1,'metaboxhidden_nav-menus','a:2:{i:0;s:8:\"add-post\";i:1;s:12:\"add-post_tag\";}');
INSERT INTO `wp_usermeta` VALUES (20,1,'nav_menu_recently_edited','2');
INSERT INTO `wp_usermeta` VALUES (21,1,'closedpostboxes_dwqa-question','a:1:{i:0;s:12:\"dwqa-answers\";}');
INSERT INTO `wp_usermeta` VALUES (22,1,'metaboxhidden_dwqa-question','a:1:{i:0;s:7:\"slugdiv\";}');
INSERT INTO `wp_usermeta` VALUES (23,1,'wp_user-settings','hidetb=1');
INSERT INTO `wp_usermeta` VALUES (24,1,'wp_user-settings-time','1433482959');
INSERT INTO `wp_usermeta` VALUES (25,1,'session_tokens','a:5:{s:64:\"8a801006f615085327c2e8e30f6322373a69c9651c66b352fdc189b1b69c056d\";a:4:{s:10:\"expiration\";i:1447671427;s:2:\"ip\";s:14:\"67.227.228.181\";s:2:\"ua\";s:73:\"Mozilla/5.0 (Windows NT 10.0; WOW64; rv:41.0) Gecko/20100101 Firefox/41.0\";s:5:\"login\";i:1447498627;}s:64:\"902089bc6eb81125001574bcad4ea37cc52374bb7a78cc392d70b47fda5f6ca1\";a:4:{s:10:\"expiration\";i:1448708284;s:2:\"ip\";s:14:\"67.227.228.181\";s:2:\"ua\";s:120:\"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.124 Safari/537.36 InfiniteWP\";s:5:\"login\";i:1447498684;}s:64:\"edadf58dbcd07cf0f45573d572a67c29b99642f9bdadfb41238d9ac9bc257fc0\";a:4:{s:10:\"expiration\";i:1448708289;s:2:\"ip\";s:14:\"67.227.228.181\";s:2:\"ua\";s:120:\"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.124 Safari/537.36 InfiniteWP\";s:5:\"login\";i:1447498689;}s:64:\"370f11bdf2b6d684b8debd4ea67305d21c2f6cfb725a1c05788cd7440cb3234e\";a:4:{s:10:\"expiration\";i:1448708301;s:2:\"ip\";s:14:\"67.227.228.181\";s:2:\"ua\";s:120:\"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.124 Safari/537.36 InfiniteWP\";s:5:\"login\";i:1447498701;}s:64:\"72f0b34b0eb2b573d7e18a52cbe6b2cea03cdb8a6688d851f1663e8f045419a0\";a:4:{s:10:\"expiration\";i:1448708366;s:2:\"ip\";s:14:\"67.227.228.181\";s:2:\"ua\";s:120:\"Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.124 Safari/537.36 InfiniteWP\";s:5:\"login\";i:1447498766;}}');
/*!40000 ALTER TABLE `wp_usermeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_users`
--

DROP TABLE IF EXISTS `wp_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_users`
--

LOCK TABLES `wp_users` WRITE;
/*!40000 ALTER TABLE `wp_users` DISABLE KEYS */;
INSERT INTO `wp_users` VALUES (1,'trideon','$P$Bm43PIBctZELPKzf3Ozkg2cxU44U77.','trideon','trideon@gmail.com','','2015-04-15 16:46:45','',0,'trideon');
/*!40000 ALTER TABLE `wp_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wfBadLeechers`
--

DROP TABLE IF EXISTS `wp_wfBadLeechers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wfBadLeechers` (
  `eMin` int(10) unsigned NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hits` int(10) unsigned NOT NULL,
  PRIMARY KEY (`eMin`,`IP`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wfBadLeechers`
--

LOCK TABLES `wp_wfBadLeechers` WRITE;
/*!40000 ALTER TABLE `wp_wfBadLeechers` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wfBadLeechers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wfBlockedIPLog`
--

DROP TABLE IF EXISTS `wp_wfBlockedIPLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wfBlockedIPLog` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `countryCode` varchar(2) NOT NULL,
  `blockCount` int(10) unsigned NOT NULL DEFAULT '0',
  `unixday` int(10) unsigned NOT NULL,
  PRIMARY KEY (`IP`,`unixday`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wfBlockedIPLog`
--

LOCK TABLES `wp_wfBlockedIPLog` WRITE;
/*!40000 ALTER TABLE `wp_wfBlockedIPLog` DISABLE KEYS */;
INSERT INTO `wp_wfBlockedIPLog` VALUES ('\0\0\0\0\0\0\0\0\0\0��C��','US',1,16741);
INSERT INTO `wp_wfBlockedIPLog` VALUES ('\0\0\0\0\0\0\0\0\0\0��C��','US',5,16742);
INSERT INTO `wp_wfBlockedIPLog` VALUES ('\0\0\0\0\0\0\0\0\0\0��C��','US',4,16743);
INSERT INTO `wp_wfBlockedIPLog` VALUES ('\0\0\0\0\0\0\0\0\0\0��C��','US',4,16744);
INSERT INTO `wp_wfBlockedIPLog` VALUES ('\0\0\0\0\0\0\0\0\0\0��C��','US',4,16745);
INSERT INTO `wp_wfBlockedIPLog` VALUES ('\0\0\0\0\0\0\0\0\0\0��C��','US',3,16746);
/*!40000 ALTER TABLE `wp_wfBlockedIPLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wfBlocks`
--

DROP TABLE IF EXISTS `wp_wfBlocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wfBlocks` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `blockedTime` bigint(20) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `lastAttempt` int(10) unsigned DEFAULT '0',
  `blockedHits` int(10) unsigned DEFAULT '0',
  `wfsn` tinyint(3) unsigned DEFAULT '0',
  `permanent` tinyint(3) unsigned DEFAULT '0',
  PRIMARY KEY (`IP`),
  KEY `k1` (`wfsn`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wfBlocks`
--

LOCK TABLES `wp_wfBlocks` WRITE;
/*!40000 ALTER TABLE `wp_wfBlocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wfBlocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wfBlocksAdv`
--

DROP TABLE IF EXISTS `wp_wfBlocksAdv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wfBlocksAdv` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `blockType` char(2) NOT NULL,
  `blockString` varchar(255) NOT NULL,
  `ctime` int(10) unsigned NOT NULL,
  `reason` varchar(255) NOT NULL,
  `totalBlocked` int(10) unsigned DEFAULT '0',
  `lastBlocked` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wfBlocksAdv`
--

LOCK TABLES `wp_wfBlocksAdv` WRITE;
/*!40000 ALTER TABLE `wp_wfBlocksAdv` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wfBlocksAdv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wfConfig`
--

DROP TABLE IF EXISTS `wp_wfConfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wfConfig` (
  `name` varchar(100) NOT NULL,
  `val` longblob,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wfConfig`
--

LOCK TABLES `wp_wfConfig` WRITE;
/*!40000 ALTER TABLE `wp_wfConfig` DISABLE KEYS */;
INSERT INTO `wp_wfConfig` VALUES ('alertOn_critical','1');
INSERT INTO `wp_wfConfig` VALUES ('alertOn_update','0');
INSERT INTO `wp_wfConfig` VALUES ('alertOn_warnings','1');
INSERT INTO `wp_wfConfig` VALUES ('alertOn_throttle','0');
INSERT INTO `wp_wfConfig` VALUES ('alertOn_block','1');
INSERT INTO `wp_wfConfig` VALUES ('alertOn_loginLockout','1');
INSERT INTO `wp_wfConfig` VALUES ('alertOn_lostPasswdForm','1');
INSERT INTO `wp_wfConfig` VALUES ('alertOn_adminLogin','1');
INSERT INTO `wp_wfConfig` VALUES ('alertOn_nonAdminLogin','0');
INSERT INTO `wp_wfConfig` VALUES ('liveTrafficEnabled','1');
INSERT INTO `wp_wfConfig` VALUES ('advancedCommentScanning','0');
INSERT INTO `wp_wfConfig` VALUES ('checkSpamIP','0');
INSERT INTO `wp_wfConfig` VALUES ('spamvertizeCheck','0');
INSERT INTO `wp_wfConfig` VALUES ('liveTraf_ignorePublishers','1');
INSERT INTO `wp_wfConfig` VALUES ('scheduledScansEnabled','1');
INSERT INTO `wp_wfConfig` VALUES ('scansEnabled_public','0');
INSERT INTO `wp_wfConfig` VALUES ('scansEnabled_heartbleed','1');
INSERT INTO `wp_wfConfig` VALUES ('scansEnabled_core','1');
INSERT INTO `wp_wfConfig` VALUES ('scansEnabled_themes','0');
INSERT INTO `wp_wfConfig` VALUES ('scansEnabled_plugins','0');
INSERT INTO `wp_wfConfig` VALUES ('scansEnabled_malware','1');
INSERT INTO `wp_wfConfig` VALUES ('scansEnabled_fileContents','1');
INSERT INTO `wp_wfConfig` VALUES ('scansEnabled_posts','1');
INSERT INTO `wp_wfConfig` VALUES ('scansEnabled_comments','1');
INSERT INTO `wp_wfConfig` VALUES ('scansEnabled_passwds','1');
INSERT INTO `wp_wfConfig` VALUES ('scansEnabled_diskSpace','1');
INSERT INTO `wp_wfConfig` VALUES ('scansEnabled_options','1');
INSERT INTO `wp_wfConfig` VALUES ('scansEnabled_dns','1');
INSERT INTO `wp_wfConfig` VALUES ('scansEnabled_scanImages','0');
INSERT INTO `wp_wfConfig` VALUES ('scansEnabled_highSense','0');
INSERT INTO `wp_wfConfig` VALUES ('scansEnabled_oldVersions','1');
INSERT INTO `wp_wfConfig` VALUES ('firewallEnabled','1');
INSERT INTO `wp_wfConfig` VALUES ('blockFakeBots','0');
INSERT INTO `wp_wfConfig` VALUES ('autoBlockScanners','1');
INSERT INTO `wp_wfConfig` VALUES ('loginSecurityEnabled','1');
INSERT INTO `wp_wfConfig` VALUES ('loginSec_lockInvalidUsers','0');
INSERT INTO `wp_wfConfig` VALUES ('loginSec_maskLoginErrors','1');
INSERT INTO `wp_wfConfig` VALUES ('loginSec_blockAdminReg','1');
INSERT INTO `wp_wfConfig` VALUES ('loginSec_disableAuthorScan','1');
INSERT INTO `wp_wfConfig` VALUES ('other_hideWPVersion','1');
INSERT INTO `wp_wfConfig` VALUES ('other_noAnonMemberComments','1');
INSERT INTO `wp_wfConfig` VALUES ('other_blockBadPOST','0');
INSERT INTO `wp_wfConfig` VALUES ('other_scanComments','1');
INSERT INTO `wp_wfConfig` VALUES ('other_pwStrengthOnUpdate','1');
INSERT INTO `wp_wfConfig` VALUES ('other_WFNet','1');
INSERT INTO `wp_wfConfig` VALUES ('other_scanOutside','0');
INSERT INTO `wp_wfConfig` VALUES ('deleteTablesOnDeact','0');
INSERT INTO `wp_wfConfig` VALUES ('autoUpdate','1');
INSERT INTO `wp_wfConfig` VALUES ('disableCookies','0');
INSERT INTO `wp_wfConfig` VALUES ('startScansRemotely','0');
INSERT INTO `wp_wfConfig` VALUES ('addCacheComment','0');
INSERT INTO `wp_wfConfig` VALUES ('disableCodeExecutionUploads','0');
INSERT INTO `wp_wfConfig` VALUES ('allowHTTPSCaching','0');
INSERT INTO `wp_wfConfig` VALUES ('debugOn','0');
INSERT INTO `wp_wfConfig` VALUES ('email_summary_enabled','1');
INSERT INTO `wp_wfConfig` VALUES ('email_summary_dashboard_widget_enabled','1');
INSERT INTO `wp_wfConfig` VALUES ('securityLevel','2');
INSERT INTO `wp_wfConfig` VALUES ('alertEmails','trideon@gmail.com');
INSERT INTO `wp_wfConfig` VALUES ('liveTraf_ignoreUsers','');
INSERT INTO `wp_wfConfig` VALUES ('liveTraf_ignoreIPs','');
INSERT INTO `wp_wfConfig` VALUES ('liveTraf_ignoreUA','');
INSERT INTO `wp_wfConfig` VALUES ('apiKey','ed79e660cee1348dcd559643eb5adec0201ce51acbebab59cd85beeeb74ff56bda80dffcdfe9a85bba79a3717f33a96434fbd2fcfa71a2f15a2e332849302af2');
INSERT INTO `wp_wfConfig` VALUES ('maxMem','256');
INSERT INTO `wp_wfConfig` VALUES ('scan_exclude','');
INSERT INTO `wp_wfConfig` VALUES ('whitelisted','');
INSERT INTO `wp_wfConfig` VALUES ('bannedURLs','');
INSERT INTO `wp_wfConfig` VALUES ('maxExecutionTime','');
INSERT INTO `wp_wfConfig` VALUES ('howGetIPs','');
INSERT INTO `wp_wfConfig` VALUES ('actUpdateInterval','');
INSERT INTO `wp_wfConfig` VALUES ('alert_maxHourly','0');
INSERT INTO `wp_wfConfig` VALUES ('loginSec_userBlacklist','');
INSERT INTO `wp_wfConfig` VALUES ('neverBlockBG','neverBlockVerified');
INSERT INTO `wp_wfConfig` VALUES ('loginSec_countFailMins','240');
INSERT INTO `wp_wfConfig` VALUES ('loginSec_lockoutMins','240');
INSERT INTO `wp_wfConfig` VALUES ('loginSec_strongPasswds','pubs');
INSERT INTO `wp_wfConfig` VALUES ('loginSec_maxFailures','20');
INSERT INTO `wp_wfConfig` VALUES ('loginSec_maxForgotPasswd','20');
INSERT INTO `wp_wfConfig` VALUES ('maxGlobalRequests','DISABLED');
INSERT INTO `wp_wfConfig` VALUES ('maxGlobalRequests_action','throttle');
INSERT INTO `wp_wfConfig` VALUES ('maxRequestsCrawlers','DISABLED');
INSERT INTO `wp_wfConfig` VALUES ('maxRequestsCrawlers_action','throttle');
INSERT INTO `wp_wfConfig` VALUES ('maxRequestsHumans','DISABLED');
INSERT INTO `wp_wfConfig` VALUES ('maxRequestsHumans_action','throttle');
INSERT INTO `wp_wfConfig` VALUES ('max404Crawlers','DISABLED');
INSERT INTO `wp_wfConfig` VALUES ('max404Crawlers_action','throttle');
INSERT INTO `wp_wfConfig` VALUES ('max404Humans','DISABLED');
INSERT INTO `wp_wfConfig` VALUES ('max404Humans_action','throttle');
INSERT INTO `wp_wfConfig` VALUES ('maxScanHits','DISABLED');
INSERT INTO `wp_wfConfig` VALUES ('maxScanHits_action','throttle');
INSERT INTO `wp_wfConfig` VALUES ('blockedTime','300');
INSERT INTO `wp_wfConfig` VALUES ('email_summary_interval','biweekly');
INSERT INTO `wp_wfConfig` VALUES ('email_summary_excluded_directories','wp-content/cache,wp-content/wfcache,wp-content/plugins/wordfence/tmp');
INSERT INTO `wp_wfConfig` VALUES ('encKey','1a7ddbf662c27605');
INSERT INTO `wp_wfConfig` VALUES ('vulnRegex','/(?:wordfence_test_vuln_match|\\/timthumb\\.php|\\/thumb\\.php|\\/thumbs\\.php|\\/thumbnail\\.php|\\/thumbnails\\.php|\\/thumnails\\.php|\\/cropper\\.php|\\/picsize\\.php|\\/resizer\\.php|connectors\\/uploadtest\\.html|connectors\\/test\\.html|mingleforumaction|uploadify\\.php|allwebmenus-wordpress-menu-plugin|wp-cycle-playlist|count-per-day|wp-autoyoutube|pay-with-tweet|comment-rating\\/ck-processkarma\\.php)/i');
INSERT INTO `wp_wfConfig` VALUES ('welcomeClosed','1');
INSERT INTO `wp_wfConfig` VALUES ('wf_summaryItems','a:16:{s:10:\"totalUsers\";i:1;s:10:\"totalPages\";s:1:\"3\";s:10:\"totalPosts\";s:1:\"2\";s:13:\"totalComments\";s:1:\"1\";s:15:\"totalCategories\";s:1:\"1\";s:11:\"totalTables\";i:32;s:9:\"totalRows\";i:3850;s:12:\"totalPlugins\";i:4;s:10:\"lastUpdate\";i:1447498625;s:11:\"totalThemes\";i:4;s:9:\"totalData\";s:8:\"24.98 MB\";s:10:\"totalFiles\";i:1818;s:9:\"totalDirs\";i:174;s:10:\"linesOfPHP\";i:297378;s:10:\"linesOfJCH\";i:161041;s:8:\"scanTime\";d:1447498625.2613189220428466796875;}');
INSERT INTO `wp_wfConfig` VALUES ('tourClosed','1');
INSERT INTO `wp_wfConfig` VALUES ('totalScansRun','348');
INSERT INTO `wp_wfConfig` VALUES ('wfKillRequested','0');
INSERT INTO `wp_wfConfig` VALUES ('currentCronKey','');
INSERT INTO `wp_wfConfig` VALUES ('wf_scanRunning','');
INSERT INTO `wp_wfConfig` VALUES ('wfStatusStartMsgs','a:14:{i:0;s:0:\"\";i:1;s:0:\"\";i:2;s:0:\"\";i:3;s:0:\"\";i:4;s:0:\"\";i:5;s:0:\"\";i:6;s:0:\"\";i:7;s:0:\"\";i:8;s:0:\"\";i:9;s:0:\"\";i:10;s:0:\"\";i:11;s:0:\"\";i:12;s:0:\"\";i:13;s:0:\"\";}');
INSERT INTO `wp_wfConfig` VALUES ('wfPeakMemory','45767528');
INSERT INTO `wp_wfConfig` VALUES ('lastScheduledScanStart','1447498611');
INSERT INTO `wp_wfConfig` VALUES ('totalLoginHits','1069');
INSERT INTO `wp_wfConfig` VALUES ('totalLogins','7');
INSERT INTO `wp_wfConfig` VALUES ('lastAdminLogin','a:6:{s:6:\"userID\";i:1;s:8:\"username\";s:7:\"trideon\";s:9:\"firstName\";s:0:\"\";s:8:\"lastName\";s:0:\"\";s:4:\"time\";s:30:\"Sat 14th November @ 06:57:07AM\";s:2:\"IP\";s:14:\"67.227.228.181\";}');
INSERT INTO `wp_wfConfig` VALUES ('totalAlertsSent','34');
INSERT INTO `wp_wfConfig` VALUES ('lastEmailHash','1447498627:3ddb82de1b9e273df1a2f2cab3d4c275');
INSERT INTO `wp_wfConfig` VALUES ('cacheType','php');
INSERT INTO `wp_wfConfig` VALUES ('autoUpdateChoice','1');
INSERT INTO `wp_wfConfig` VALUES ('emailedIssuesList','a:35:{i:0;a:2:{s:7:\"ignoreC\";s:32:\"a8afc692fe6e44151b1bc730b3781a58\";s:7:\"ignoreP\";s:32:\"a8afc692fe6e44151b1bc730b3781a58\";}i:1;a:2:{s:7:\"ignoreC\";s:32:\"45e4638937ef337ea956a65563d59a03\";s:7:\"ignoreP\";s:32:\"45e4638937ef337ea956a65563d59a03\";}i:2;a:2:{s:7:\"ignoreC\";s:32:\"5026b41e509e835fcdd421c51940c8ed\";s:7:\"ignoreP\";s:32:\"5026b41e509e835fcdd421c51940c8ed\";}i:3;a:2:{s:7:\"ignoreC\";s:32:\"b69ccef52ac07b6a4ca7aa0233238f0e\";s:7:\"ignoreP\";s:32:\"b69ccef52ac07b6a4ca7aa0233238f0e\";}i:4;a:2:{s:7:\"ignoreC\";s:32:\"153e6272ed62fb7d20d7195d1e166404\";s:7:\"ignoreP\";s:32:\"153e6272ed62fb7d20d7195d1e166404\";}i:5;a:2:{s:7:\"ignoreC\";s:32:\"d72cf557c3d98b8fac94e951730e90dc\";s:7:\"ignoreP\";s:32:\"d72cf557c3d98b8fac94e951730e90dc\";}i:6;a:2:{s:7:\"ignoreC\";s:32:\"f47c68d66b120f055d762b38eaec4ed0\";s:7:\"ignoreP\";s:32:\"f47c68d66b120f055d762b38eaec4ed0\";}i:7;a:2:{s:7:\"ignoreC\";s:32:\"aea34fe600ac5f87d801d4fd8e2992ec\";s:7:\"ignoreP\";s:32:\"aea34fe600ac5f87d801d4fd8e2992ec\";}i:8;a:2:{s:7:\"ignoreC\";s:32:\"0e80650d7726d91902c96f699399a56d\";s:7:\"ignoreP\";s:32:\"0e80650d7726d91902c96f699399a56d\";}i:9;a:2:{s:7:\"ignoreC\";s:32:\"3ba8b3de68697834104e4c01ca634ed5\";s:7:\"ignoreP\";s:32:\"3ba8b3de68697834104e4c01ca634ed5\";}i:10;a:2:{s:7:\"ignoreC\";s:32:\"31120b2477d73c661b6abc49d5841059\";s:7:\"ignoreP\";s:32:\"31120b2477d73c661b6abc49d5841059\";}i:11;a:2:{s:7:\"ignoreC\";s:32:\"00ca63c53855fc213bc031d5af3143f1\";s:7:\"ignoreP\";s:32:\"00ca63c53855fc213bc031d5af3143f1\";}i:12;a:2:{s:7:\"ignoreC\";s:32:\"6b8725044ea410cf57da8bc60bae6cb1\";s:7:\"ignoreP\";s:32:\"6b8725044ea410cf57da8bc60bae6cb1\";}i:13;a:2:{s:7:\"ignoreC\";s:32:\"d8ed88c4e1edfe442cf6442a45ed2c15\";s:7:\"ignoreP\";s:32:\"d8ed88c4e1edfe442cf6442a45ed2c15\";}i:14;a:2:{s:7:\"ignoreC\";s:32:\"4b853b87d7b3f869b40d15f4b077555e\";s:7:\"ignoreP\";s:32:\"4b853b87d7b3f869b40d15f4b077555e\";}i:15;a:2:{s:7:\"ignoreC\";s:32:\"d8b22638a3a658b0ee686d073602e4cd\";s:7:\"ignoreP\";s:32:\"d8b22638a3a658b0ee686d073602e4cd\";}i:16;a:2:{s:7:\"ignoreC\";s:32:\"82ccb3d1b4e04b9e5440121b42d26268\";s:7:\"ignoreP\";s:32:\"82ccb3d1b4e04b9e5440121b42d26268\";}i:17;a:2:{s:7:\"ignoreC\";s:32:\"b78cbaf0d816adb99ec003149b774d62\";s:7:\"ignoreP\";s:32:\"b78cbaf0d816adb99ec003149b774d62\";}i:18;a:2:{s:7:\"ignoreC\";s:32:\"93e56d9dd2cd0d85ee4e56414d5408bc\";s:7:\"ignoreP\";s:32:\"93e56d9dd2cd0d85ee4e56414d5408bc\";}i:19;a:2:{s:7:\"ignoreC\";s:32:\"aa057ef8600efb1865f3431316f2d673\";s:7:\"ignoreP\";s:32:\"aa057ef8600efb1865f3431316f2d673\";}i:20;a:2:{s:7:\"ignoreC\";s:32:\"db15da3f99491e6f68d635b0a10f3797\";s:7:\"ignoreP\";s:32:\"db15da3f99491e6f68d635b0a10f3797\";}i:21;a:2:{s:7:\"ignoreC\";s:32:\"7fc350ff850a7bbb523d15ee7c98f004\";s:7:\"ignoreP\";s:32:\"7fc350ff850a7bbb523d15ee7c98f004\";}i:22;a:2:{s:7:\"ignoreC\";s:32:\"51760651d9c159657045dbef3a1c781f\";s:7:\"ignoreP\";s:32:\"51760651d9c159657045dbef3a1c781f\";}i:23;a:2:{s:7:\"ignoreC\";s:32:\"927155500e44699b03182c3286f9e0ac\";s:7:\"ignoreP\";s:32:\"927155500e44699b03182c3286f9e0ac\";}i:24;a:2:{s:7:\"ignoreC\";s:32:\"1a9e8e264c2c05e50ab40526af689200\";s:7:\"ignoreP\";s:32:\"1a9e8e264c2c05e50ab40526af689200\";}i:25;a:2:{s:7:\"ignoreC\";s:32:\"b805f38490f7438c43c011efd9821cff\";s:7:\"ignoreP\";s:32:\"b805f38490f7438c43c011efd9821cff\";}i:26;a:2:{s:7:\"ignoreC\";s:32:\"fc16fb414a97cf1b7bd66a8c74e1f4b9\";s:7:\"ignoreP\";s:32:\"fc16fb414a97cf1b7bd66a8c74e1f4b9\";}i:27;a:2:{s:7:\"ignoreC\";s:32:\"60af2fec6425c0fe0851686502c0bf83\";s:7:\"ignoreP\";s:32:\"60af2fec6425c0fe0851686502c0bf83\";}i:28;a:2:{s:7:\"ignoreC\";s:32:\"21fa0be0338b3c2b7d423f560e4af236\";s:7:\"ignoreP\";s:32:\"21fa0be0338b3c2b7d423f560e4af236\";}i:29;a:2:{s:7:\"ignoreC\";s:32:\"44c872f9ab52ec3a537edff1bd10747e\";s:7:\"ignoreP\";s:32:\"44c872f9ab52ec3a537edff1bd10747e\";}i:30;a:2:{s:7:\"ignoreC\";s:32:\"cfe94ed519429751d1f862dbaaef3182\";s:7:\"ignoreP\";s:32:\"cfe94ed519429751d1f862dbaaef3182\";}i:31;a:2:{s:7:\"ignoreC\";s:32:\"a7fb00e6948be623baee30ca38f8fb5e\";s:7:\"ignoreP\";s:32:\"a7fb00e6948be623baee30ca38f8fb5e\";}i:32;a:2:{s:7:\"ignoreC\";s:32:\"ca2e7fbbde76ce2229bd93ba312d7367\";s:7:\"ignoreP\";s:32:\"ca2e7fbbde76ce2229bd93ba312d7367\";}i:33;a:2:{s:7:\"ignoreC\";s:32:\"85fe99c915b23097f0096f8188056ba0\";s:7:\"ignoreP\";s:32:\"85fe99c915b23097f0096f8188056ba0\";}i:34;a:2:{s:7:\"ignoreC\";s:32:\"750ce549e231dceb44fe5add66086d7f\";s:7:\"ignoreP\";s:32:\"750ce549e231dceb44fe5add66086d7f\";}}');
INSERT INTO `wp_wfConfig` VALUES ('wf_dnsCNAME','');
INSERT INTO `wp_wfConfig` VALUES ('wf_dnsA','gmagigolo.com points to 67.227.228.181');
INSERT INTO `wp_wfConfig` VALUES ('wf_dnsMX','gmagigolo.com');
INSERT INTO `wp_wfConfig` VALUES ('wf_dnsLogged','1');
INSERT INTO `wp_wfConfig` VALUES ('lastScanCompleted','ok');
INSERT INTO `wp_wfConfig` VALUES ('scansEnabled_database','1');
INSERT INTO `wp_wfConfig` VALUES ('ssl_verify','1');
INSERT INTO `wp_wfConfig` VALUES ('cbl_restOfSiteBlocked','1');
INSERT INTO `wp_wfConfig` VALUES ('totalIPsBlocked','1');
INSERT INTO `wp_wfConfig` VALUES ('totalIPsLocked','27');
INSERT INTO `wp_wfConfig` VALUES ('allowed404s','/favicon.ico\n/apple-touch-icon*.png\n/*@2x.png');
INSERT INTO `wp_wfConfig` VALUES ('scanFileProcessing','');
INSERT INTO `wp_wfConfig` VALUES ('totalCommentsFiltered','1');
/*!40000 ALTER TABLE `wp_wfConfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wfCrawlers`
--

DROP TABLE IF EXISTS `wp_wfCrawlers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wfCrawlers` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `patternSig` binary(16) NOT NULL,
  `status` char(8) NOT NULL,
  `lastUpdate` int(10) unsigned NOT NULL,
  `PTR` varchar(255) DEFAULT '',
  PRIMARY KEY (`IP`,`patternSig`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wfCrawlers`
--

LOCK TABLES `wp_wfCrawlers` WRITE;
/*!40000 ALTER TABLE `wp_wfCrawlers` DISABLE KEYS */;
INSERT INTO `wp_wfCrawlers` VALUES ('\0\0\0\0\0\0\0\0\0\0��C��','�����>�b0�oQ1��','badPTR',1447438324,'host.gmagigolo.com');
/*!40000 ALTER TABLE `wp_wfCrawlers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wfFileMods`
--

DROP TABLE IF EXISTS `wp_wfFileMods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wfFileMods` (
  `filenameMD5` binary(16) NOT NULL,
  `filename` varchar(1000) NOT NULL,
  `knownFile` tinyint(3) unsigned NOT NULL,
  `oldMD5` binary(16) NOT NULL,
  `newMD5` binary(16) NOT NULL,
  PRIMARY KEY (`filenameMD5`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wfFileMods`
--

LOCK TABLES `wp_wfFileMods` WRITE;
/*!40000 ALTER TABLE `wp_wfFileMods` DISABLE KEYS */;
INSERT INTO `wp_wfFileMods` VALUES ('�R�*�����������','.htaccess',0,'B��E�#~!J�ף���','B��E�#~!J�ף���');
INSERT INTO `wp_wfFileMods` VALUES ('�:���\0�*�!�qx�','__db.001',0,'����Ǘ���5�ڜ','����Ǘ���5�ڜ');
INSERT INTO `wp_wfFileMods` VALUES ('5hன��>�ṗv��','error_log',0,'e�R �S��yWz','e�R �S��yWz');
INSERT INTO `wp_wfFileMods` VALUES ('��\0���+OW+�','index.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�%0;��s��Dm\\�:[');
INSERT INTO `wp_wfFileMods` VALUES ('���[�/�9}�`:w�P','license.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','98��v���h\ZP֡�>q');
INSERT INTO `wp_wfFileMods` VALUES ('ɑ6lN�sQ{&�9}�~','readme.d6c103dd056a8359c0822ffea030f9ab.html',0,'��O��ڂs�B��','��O��ڂs�B��');
INSERT INTO `wp_wfFileMods` VALUES ('���K�g���o#�0','wp-activate.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','pUȪ�N�ੌ�{eG�');
INSERT INTO `wp_wfFileMods` VALUES ('��ht��>3&ܝ^U\n��','wp-admin/.htaccess',0,'����<��|�����]a','����<��|�����]a');
INSERT INTO `wp_wfFileMods` VALUES ('-��)7�5y�8c��Wv�','wp-admin/about.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Xc�拇��Z<j����');
INSERT INTO `wp_wfFileMods` VALUES ('X��H奥(�:�Z��','wp-admin/admin-ajax.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','W����:��em�\r-XL$');
INSERT INTO `wp_wfFileMods` VALUES ('!1b݅9��*���\\��','wp-admin/admin-footer.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','bKtvoC��Nwjv�A�');
INSERT INTO `wp_wfFileMods` VALUES ('�KU�g0MU�/��ʇ','wp-admin/admin-functions.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��ga���c�3�aq�');
INSERT INTO `wp_wfFileMods` VALUES ('@�m����O��W','wp-admin/admin-header.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��I�:s,Ί���');
INSERT INTO `wp_wfFileMods` VALUES ('�]��@�\n��>ĺ�Yn','wp-admin/admin-post.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��\"�l�E�)�E�A');
INSERT INTO `wp_wfFileMods` VALUES ('���,H(b�_F�O','wp-admin/admin.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','4�G𿤂X�ΗN��');
INSERT INTO `wp_wfFileMods` VALUES ('	X�t\\4vNI5��j��','wp-admin/async-upload.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�<Br?d�T\'��Z�0X');
INSERT INTO `wp_wfFileMods` VALUES ('\"��6\r+K{�\Z!a','wp-admin/comment.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�҅yE�F\r@$�D9�');
INSERT INTO `wp_wfFileMods` VALUES ('kM�������̙Ysp','wp-admin/credits.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','m`$�����Y�J');
INSERT INTO `wp_wfFileMods` VALUES ('�*O-�Lτ���\r[�u','wp-admin/css/about-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��/��v�R)�\Z`�E!Y');
INSERT INTO `wp_wfFileMods` VALUES ('�A7�\'�C#�w�S�s�','wp-admin/css/about.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Ɵ���^Xl�|��\rV�');
INSERT INTO `wp_wfFileMods` VALUES ('�m��n9�F�6�','wp-admin/css/admin-menu-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����S�0Wi�Qκ~�');
INSERT INTO `wp_wfFileMods` VALUES ('��\"�Z0\0ؿe�Ԧp�','wp-admin/css/admin-menu.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�>d�\0?�h��/���!');
INSERT INTO `wp_wfFileMods` VALUES ('���P��a`Xu','wp-admin/css/color-picker-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��[��q4G։��a');
INSERT INTO `wp_wfFileMods` VALUES ('�r�W�3���᥾V','wp-admin/css/color-picker-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Z4w��l�e�$��');
INSERT INTO `wp_wfFileMods` VALUES ('F���?�C;$��H\r\r','wp-admin/css/color-picker.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','-\rM�_�h���lf/');
INSERT INTO `wp_wfFileMods` VALUES ('��ܡ9�u_\\\n�9�\'','wp-admin/css/color-picker.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����}��U��F��\'�');
INSERT INTO `wp_wfFileMods` VALUES ('�J|6}�P�,\rٛ','wp-admin/css/colors/_admin.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����W耢��hL��%');
INSERT INTO `wp_wfFileMods` VALUES ('ue�,\"\n	�h�g.','wp-admin/css/colors/_mixins.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','S�_���|�\'4.o\'6�');
INSERT INTO `wp_wfFileMods` VALUES ('��=CѠ��*TX���4','wp-admin/css/colors/_variables.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',':�	k\Z	r�L���Z');
INSERT INTO `wp_wfFileMods` VALUES ('58�d�`S61K>ۮ�v','wp-admin/css/colors/blue/colors-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','4\n��`C��9�Ĉ�');
INSERT INTO `wp_wfFileMods` VALUES ('D�8hFޛBViR�','wp-admin/css/colors/blue/colors-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��A�\n��`trk');
INSERT INTO `wp_wfFileMods` VALUES ('��F�ZY��C8��3E','wp-admin/css/colors/blue/colors.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','5ѱ�^pJ��G�����');
INSERT INTO `wp_wfFileMods` VALUES ('tm6ۗ�q���.��=j','wp-admin/css/colors/blue/colors.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��-K�e��:8�');
INSERT INTO `wp_wfFileMods` VALUES ('L�>t���N�����','wp-admin/css/colors/blue/colors.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��5Iה�g,)Z�YM�');
INSERT INTO `wp_wfFileMods` VALUES ('�����juGCtO����','wp-admin/css/colors/coffee/colors-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\"rü�+��w����\'');
INSERT INTO `wp_wfFileMods` VALUES ('��q?%��rp��0�7�q','wp-admin/css/colors/coffee/colors-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�H<�S�-�g�����');
INSERT INTO `wp_wfFileMods` VALUES ('ϴ 3P`#8^��Z','wp-admin/css/colors/coffee/colors.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��2���#6��`τ}L');
INSERT INTO `wp_wfFileMods` VALUES ('���eC����Di!��','wp-admin/css/colors/coffee/colors.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�yb)�O�](�a�r��z');
INSERT INTO `wp_wfFileMods` VALUES ('xIH�.�9�Y��BO','wp-admin/css/colors/coffee/colors.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','9~8 �z#C0�^%a�');
INSERT INTO `wp_wfFileMods` VALUES ('jmE��AX�uw�>܆','wp-admin/css/colors/ectoplasm/colors-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','X�Ѳ��E��ϡuI�');
INSERT INTO `wp_wfFileMods` VALUES ('Dչ������$Oa����','wp-admin/css/colors/ectoplasm/colors-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','o�qjGY|\rUI���\'');
INSERT INTO `wp_wfFileMods` VALUES ('�����H\0ۙ��h�C��','wp-admin/css/colors/ectoplasm/colors.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�8�K���࿬8��b�');
INSERT INTO `wp_wfFileMods` VALUES ('[��#ܧ\Z>]��<�','wp-admin/css/colors/ectoplasm/colors.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Ӓ�J�׺��S�b�H');
INSERT INTO `wp_wfFileMods` VALUES ('�M�Tq&[?��>칊�\n','wp-admin/css/colors/ectoplasm/colors.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�q�9+�\"��+��');
INSERT INTO `wp_wfFileMods` VALUES ('�q����%ű� m+','wp-admin/css/colors/light/colors-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ʘ_�\nJT�¹���J');
INSERT INTO `wp_wfFileMods` VALUES ('-�f��4]�#\"u��l','wp-admin/css/colors/light/colors-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��R�[Ƴ�O�I\\');
INSERT INTO `wp_wfFileMods` VALUES ('v�{#��l��b\0}��B','wp-admin/css/colors/light/colors.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','%��ʒw�����^�`�');
INSERT INTO `wp_wfFileMods` VALUES ('�9(F�Rj2�n6]��','wp-admin/css/colors/light/colors.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Cxڄx43�*Cn��/y');
INSERT INTO `wp_wfFileMods` VALUES ('��KS+�e׎A�@��','wp-admin/css/colors/light/colors.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',' �V{��)\\_~��q�');
INSERT INTO `wp_wfFileMods` VALUES ('�����L?@��.~O�','wp-admin/css/colors/midnight/colors-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','s���^�r\'\'8��n�I');
INSERT INTO `wp_wfFileMods` VALUES ('���ᗏ�3�-��4�','wp-admin/css/colors/midnight/colors-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','FӍ���W�����&%�');
INSERT INTO `wp_wfFileMods` VALUES (';�b�fȖ0����x','wp-admin/css/colors/midnight/colors.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','x(���V�?OD�{��`');
INSERT INTO `wp_wfFileMods` VALUES ('��_\r�JL�#�@B��','wp-admin/css/colors/midnight/colors.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�H�]�Q�T�kܤc');
INSERT INTO `wp_wfFileMods` VALUES ('��w�=Ţ�O�&�F�','wp-admin/css/colors/midnight/colors.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','&܍���|DW��!E�4');
INSERT INTO `wp_wfFileMods` VALUES ('�<��(����*A]�O��','wp-admin/css/colors/ocean/colors-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�2Pjģ�$��f�V');
INSERT INTO `wp_wfFileMods` VALUES ('����{^��W����C�','wp-admin/css/colors/ocean/colors-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�lv,|����\"��O');
INSERT INTO `wp_wfFileMods` VALUES ('�Ê5ff�;,G!\'��\'-','wp-admin/css/colors/ocean/colors.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','X�Oe����\"&�����~');
INSERT INTO `wp_wfFileMods` VALUES ('�*T�u\r�����~�m','wp-admin/css/colors/ocean/colors.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','� 8��J4Z�Jf{\n');
INSERT INTO `wp_wfFileMods` VALUES ('-����Ǹ�%w=��','wp-admin/css/colors/ocean/colors.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\Z|[���l�|ٱf%h');
INSERT INTO `wp_wfFileMods` VALUES ('j׻���q.�*;��2','wp-admin/css/colors/sunrise/colors-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','y�N�^�&R\"�6�a�');
INSERT INTO `wp_wfFileMods` VALUES ('2j�L,���W\r��W$��','wp-admin/css/colors/sunrise/colors-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�2�$\n�`��5H��');
INSERT INTO `wp_wfFileMods` VALUES ('�����y85���æb�','wp-admin/css/colors/sunrise/colors.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Cp��L�I��tv}���T');
INSERT INTO `wp_wfFileMods` VALUES ('�-�+�e���m�u\"��x','wp-admin/css/colors/sunrise/colors.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�E6G�QSU�E�a�B�8');
INSERT INTO `wp_wfFileMods` VALUES ('��S�CRC��l��','wp-admin/css/colors/sunrise/colors.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','V��\Z�z�	h���=�');
INSERT INTO `wp_wfFileMods` VALUES ('��W2��D��G�7�V','wp-admin/css/common-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��������J<��');
INSERT INTO `wp_wfFileMods` VALUES ('��p��9�6è�R�','wp-admin/css/common.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','iB���D�&�8Y���');
INSERT INTO `wp_wfFileMods` VALUES ('��V��k9۴�s���ֿ','wp-admin/css/customize-controls-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',']����m�`$�M');
INSERT INTO `wp_wfFileMods` VALUES ('����p�j֛`��w','wp-admin/css/customize-controls-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\'���-��k��;!�');
INSERT INTO `wp_wfFileMods` VALUES ('�?�\n5��H�?������','wp-admin/css/customize-controls.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','4��ٻF���$4���<');
INSERT INTO `wp_wfFileMods` VALUES ('�.ն���Zg{�=��','wp-admin/css/customize-controls.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�J�|`����(���4');
INSERT INTO `wp_wfFileMods` VALUES ('N���HV����}�4G','wp-admin/css/customize-widgets-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','z�Aʹ]����j9�');
INSERT INTO `wp_wfFileMods` VALUES ('��4T�(�\\9\'��3�)','wp-admin/css/customize-widgets-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��PO?$�L�~�U��j�');
INSERT INTO `wp_wfFileMods` VALUES ('�������6$[���O�','wp-admin/css/customize-widgets.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','|�?�!�`���j��\Zx');
INSERT INTO `wp_wfFileMods` VALUES ('��b�������|e~�','wp-admin/css/customize-widgets.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��2�����?[���<�');
INSERT INTO `wp_wfFileMods` VALUES ('5�?��y��<�2�','wp-admin/css/dashboard-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�a��l�*���li&j');
INSERT INTO `wp_wfFileMods` VALUES ('����KqM���{���','wp-admin/css/dashboard.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�x����p�0��ۃ�');
INSERT INTO `wp_wfFileMods` VALUES ('8�@)��6yg[y�sQR','wp-admin/css/deprecated-media-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','U��R�ڹy\r��C���');
INSERT INTO `wp_wfFileMods` VALUES ('�pt_ Y����7L�Kt','wp-admin/css/deprecated-media-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','{aPt�X?�A���IY');
INSERT INTO `wp_wfFileMods` VALUES ('���X\"�-{��$48sx','wp-admin/css/deprecated-media.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\nڌe�6|�����\ZƦ');
INSERT INTO `wp_wfFileMods` VALUES ('4a��[I�}���H�m)','wp-admin/css/deprecated-media.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','bR\'�5�Y��t�S6');
INSERT INTO `wp_wfFileMods` VALUES (']�����\"}[�Y�R�','wp-admin/css/edit-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���s������3g�$');
INSERT INTO `wp_wfFileMods` VALUES ('\r��:�:���HH�:d','wp-admin/css/edit.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ܡ�ɵI��[\'�\'��B');
INSERT INTO `wp_wfFileMods` VALUES ('6;I(�H�m�%��f�','wp-admin/css/farbtastic-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����q�@!!�Ek�');
INSERT INTO `wp_wfFileMods` VALUES ('�«��-j=�u�N\\q\'','wp-admin/css/farbtastic.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��8)���}{��C�h2U');
INSERT INTO `wp_wfFileMods` VALUES ('OlqCcێ���������','wp-admin/css/forms-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ShAe��{\0�\0�>�');
INSERT INTO `wp_wfFileMods` VALUES ('����(���%�#�9yn','wp-admin/css/forms.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','������Eoa��)&��I');
INSERT INTO `wp_wfFileMods` VALUES ('�������kM��?�uX','wp-admin/css/ie-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�	wʢ���5յSl��');
INSERT INTO `wp_wfFileMods` VALUES ('vs�%�z�����F�','wp-admin/css/ie-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Fܣ��sȶ��?��\0�');
INSERT INTO `wp_wfFileMods` VALUES ('E�&��VN���\"N','wp-admin/css/ie.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�F�Y\0��g�H�0��');
INSERT INTO `wp_wfFileMods` VALUES ('ѧ�_�4a!�F��','wp-admin/css/ie.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','IBT�\'�n�i�)P�');
INSERT INTO `wp_wfFileMods` VALUES ('�w�9=�_\"h%��v','wp-admin/css/install-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','*��CM:�������');
INSERT INTO `wp_wfFileMods` VALUES ('i�-��X�8V[~E�','wp-admin/css/install-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���5�n���J� ');
INSERT INTO `wp_wfFileMods` VALUES ('<��9�u�j����!�$','wp-admin/css/install.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','B��$\0���D��9j�');
INSERT INTO `wp_wfFileMods` VALUES ('���ʆ��n�D㮖�(','wp-admin/css/install.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','3?�zP��&O�<R�9`�');
INSERT INTO `wp_wfFileMods` VALUES ('��\'-�p�-���f�','wp-admin/css/l10n-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��:8σH57cM��G');
INSERT INTO `wp_wfFileMods` VALUES ('�����2D�i�e�','wp-admin/css/l10n.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',']�T�����=�!�T');
INSERT INTO `wp_wfFileMods` VALUES ('�y%���Ǻ~�ne\"V','wp-admin/css/list-tables-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�K �@���W�<');
INSERT INTO `wp_wfFileMods` VALUES ('|j��x7�(Q}�0�\'�','wp-admin/css/list-tables.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�D�J�$���e벚�');
INSERT INTO `wp_wfFileMods` VALUES ('A{&� ��V>��Νs','wp-admin/css/login-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','5�?�(6�zү��sz');
INSERT INTO `wp_wfFileMods` VALUES ('h@Z�%�R�F�;ti\\m','wp-admin/css/login-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','V<���/(�{�z�ݨQ');
INSERT INTO `wp_wfFileMods` VALUES ('���|�jX����|�fb','wp-admin/css/login.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����HtU���R��');
INSERT INTO `wp_wfFileMods` VALUES ('`�&��锥~K3/d','wp-admin/css/login.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�f\Z�Ad�a��FðB5');
INSERT INTO `wp_wfFileMods` VALUES ('r��\n��b��#��','wp-admin/css/media-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��?ً�./+#S�G_�');
INSERT INTO `wp_wfFileMods` VALUES ('����T��D��F�K1�','wp-admin/css/media.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�x��{�%���U�');
INSERT INTO `wp_wfFileMods` VALUES ('\Z�y��8R#O�y��','wp-admin/css/nav-menus-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��@�2��Ҏb4�V_�');
INSERT INTO `wp_wfFileMods` VALUES ('���qh�n�J�j�','wp-admin/css/nav-menus.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�&cDݱ��t�q��a');
INSERT INTO `wp_wfFileMods` VALUES ('�.�B�|xӳ��E�','wp-admin/css/press-this-editor-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��P`d�L�-#wM!�_');
INSERT INTO `wp_wfFileMods` VALUES ('�\"j�ǧ`�����1�','wp-admin/css/press-this-editor.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�?�V���\"��\'ŝ');
INSERT INTO `wp_wfFileMods` VALUES ('��H�Mz�@�A��','wp-admin/css/press-this-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','+(y�*�@���p���');
INSERT INTO `wp_wfFileMods` VALUES ('� �(T5!��h�u','wp-admin/css/press-this-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���~�+� \"<�bj');
INSERT INTO `wp_wfFileMods` VALUES ('�F|\n�MN,8�ݪ�\'�','wp-admin/css/press-this.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ܡ�����{�d�>S');
INSERT INTO `wp_wfFileMods` VALUES ('.Z{=U�uߩAJ��*','wp-admin/css/press-this.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','H\n{R�`���z\n�&');
INSERT INTO `wp_wfFileMods` VALUES ('�Ph�����rV�','wp-admin/css/revisions-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�2����.�ĕx`x�a*');
INSERT INTO `wp_wfFileMods` VALUES ('� a\"KwT�bc1S','wp-admin/css/revisions.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�f��tp��p��P�');
INSERT INTO `wp_wfFileMods` VALUES ('����g�~�w\Z�hh','wp-admin/css/themes-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\0�wE�i�O�!�\r�}');
INSERT INTO `wp_wfFileMods` VALUES ('�R���ш�޿�0','wp-admin/css/themes.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',',�7�Ջ�b�LI�+w�');
INSERT INTO `wp_wfFileMods` VALUES ('���3v�U�\Z3�P�^O ','wp-admin/css/widgets-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�c�}�q�)\\ZB��\n�');
INSERT INTO `wp_wfFileMods` VALUES ('�!HUN&�\"����z��','wp-admin/css/widgets.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','MǛ��H����3�\r');
INSERT INTO `wp_wfFileMods` VALUES ('��֗]NR���S{qv?�','wp-admin/css/wp-admin-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\"�ew@3�u��|˻');
INSERT INTO `wp_wfFileMods` VALUES ('���$(�g�(���P��/','wp-admin/css/wp-admin-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�6`2��f����:*');
INSERT INTO `wp_wfFileMods` VALUES ('d�4�j�2U�V��$�P','wp-admin/css/wp-admin.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��\Z��S�RF��)�m');
INSERT INTO `wp_wfFileMods` VALUES ('��j0���w�E}®R�','wp-admin/css/wp-admin.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\"]��Z���ӕ)g�&�');
INSERT INTO `wp_wfFileMods` VALUES ('��?�0|���5uơ��','wp-admin/custom-background.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�إO��\0Q�-��');
INSERT INTO `wp_wfFileMods` VALUES ('u�qg\Z\0�8�hԭ�\0�','wp-admin/custom-header.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','T��.��08�#�\Zz&�');
INSERT INTO `wp_wfFileMods` VALUES ('�;?2��S��\0��p','wp-admin/customize.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','T���xv9|5H3x ');
INSERT INTO `wp_wfFileMods` VALUES ('��p?E^�@�\'��PE�','wp-admin/edit-comments.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',')O��I=4�]VyK�');
INSERT INTO `wp_wfFileMods` VALUES ('�\r�b\\��ɍ�\Z��','wp-admin/edit-form-advanced.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�:���?�k�b6;��');
INSERT INTO `wp_wfFileMods` VALUES ('G�7\Z��I&:�x','wp-admin/edit-form-comment.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�%��8H�p�?H2�x�');
INSERT INTO `wp_wfFileMods` VALUES ('\n���b-�V�:��|m��','wp-admin/edit-link-form.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�7����d�G�G�\0�G%');
INSERT INTO `wp_wfFileMods` VALUES ('%����8^�V<�t�','wp-admin/edit-tag-form.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','F?��E���/)w%�');
INSERT INTO `wp_wfFileMods` VALUES ('��h���)UG@�x��v	','wp-admin/edit-tags.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','M�{#kb����ao�~');
INSERT INTO `wp_wfFileMods` VALUES ('Y�La���h�(','wp-admin/edit.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ၢ�8�\Zq�}u���');
INSERT INTO `wp_wfFileMods` VALUES ('pVYa�\0צּ=���','wp-admin/error_log',0,'+�ŏ��J@\\q��','+�ŏ��J@\\q��');
INSERT INTO `wp_wfFileMods` VALUES ('��1���|�}���dQ','wp-admin/export.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�-s�t���?_�_J');
INSERT INTO `wp_wfFileMods` VALUES ('O����&�r�蓏�� ','wp-admin/freedoms.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','e������SvLXy¸');
INSERT INTO `wp_wfFileMods` VALUES ('��W���\"���Sk:�','wp-admin/images/align-center-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���-�r�5*J7�If');
INSERT INTO `wp_wfFileMods` VALUES ('&*���dĆָ�	�H5','wp-admin/images/align-center.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','	�\Zݶ�4y�dY1�e�');
INSERT INTO `wp_wfFileMods` VALUES ('�V9��K���goX��7�','wp-admin/images/align-left-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','i�8�O�����^��c');
INSERT INTO `wp_wfFileMods` VALUES ('��m�Mt���W�B','wp-admin/images/align-left.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\\�y0��d�Z�o.h��');
INSERT INTO `wp_wfFileMods` VALUES ('�].�oo�ȦM-n	�','wp-admin/images/align-none-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�XC�)[���-�4�');
INSERT INTO `wp_wfFileMods` VALUES ('MW�	���:��ي','wp-admin/images/align-none.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�eqd2���u����\r');
INSERT INTO `wp_wfFileMods` VALUES ('v�G�.�g�A��#�r�','wp-admin/images/align-right-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','h�l�>r�]�lW��x');
INSERT INTO `wp_wfFileMods` VALUES ('��tnR�ؔ����%^�','wp-admin/images/align-right.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','B���Oe#�l@:P+\"v');
INSERT INTO `wp_wfFileMods` VALUES ('�[���QH\"pS1Ȫ�c','wp-admin/images/arrows-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','� Q��}��ydb#6�');
INSERT INTO `wp_wfFileMods` VALUES ('�E#l��L��_&ܪ���','wp-admin/images/arrows.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�v�$�>����>�Y');
INSERT INTO `wp_wfFileMods` VALUES ('G�9q���=ʥ[3?a�','wp-admin/images/bubble_bg-2x.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','R=[����;��c��');
INSERT INTO `wp_wfFileMods` VALUES ('QuoPX��\0��Sڞ','wp-admin/images/bubble_bg.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','=,����(��\Z2cV� 8');
INSERT INTO `wp_wfFileMods` VALUES ('��Lt593�u^���)��','wp-admin/images/comment-grey-bubble-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�TY�ŝ2�s,\r�m��');
INSERT INTO `wp_wfFileMods` VALUES ('���e�bW�A0�d','wp-admin/images/comment-grey-bubble.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Y�*\'����t���F');
INSERT INTO `wp_wfFileMods` VALUES ('�I��\\j���x���g','wp-admin/images/date-button-2x.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',')R�,$k���)6C��c');
INSERT INTO `wp_wfFileMods` VALUES ('��a��\'@T瑓����','wp-admin/images/date-button.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���.��I��V�ď�');
INSERT INTO `wp_wfFileMods` VALUES ('�j%M�ɍ��p)Z��','wp-admin/images/generic.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����\'�[#98!�');
INSERT INTO `wp_wfFileMods` VALUES ('�\Z{g��?�3gڢ\Z�','wp-admin/images/icons32-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�%�*�����g����');
INSERT INTO `wp_wfFileMods` VALUES ('���&��N�,���6P','wp-admin/images/icons32-vs-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�*04�G4F�	&Z�i}\"');
INSERT INTO `wp_wfFileMods` VALUES ('��L �U����f��u�<','wp-admin/images/icons32-vs.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',',�P*���{>v��Uf');
INSERT INTO `wp_wfFileMods` VALUES ('�1��WV(2��6����','wp-admin/images/icons32.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�۬[�m9��J�4�\Z�');
INSERT INTO `wp_wfFileMods` VALUES ('L����8���\\�ݼ+','wp-admin/images/imgedit-icons-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',',��\'��6U�������t');
INSERT INTO `wp_wfFileMods` VALUES ('{���?����\r��\n\'','wp-admin/images/imgedit-icons.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','K�\\2���}�G�i;O');
INSERT INTO `wp_wfFileMods` VALUES ('�4g��e���>���ߝ','wp-admin/images/list-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','hջIS�2��i�g�');
INSERT INTO `wp_wfFileMods` VALUES ('��Z\nu�oK� ��T;e','wp-admin/images/list.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','>��*��ӳ�S��');
INSERT INTO `wp_wfFileMods` VALUES (')�M��^�ûoz�','wp-admin/images/loading.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','-[��t�P���d�');
INSERT INTO `wp_wfFileMods` VALUES ('�\0��%3[$x\0��.��(','wp-admin/images/marker.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','3�*O2/�3I2���');
INSERT INTO `wp_wfFileMods` VALUES ('@�;5�X��V��O�Z','wp-admin/images/mask.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���g~�\"��J��䩎�');
INSERT INTO `wp_wfFileMods` VALUES ('@�s�Z��^����q�v','wp-admin/images/media-button-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','#�WI��\\��?��');
INSERT INTO `wp_wfFileMods` VALUES ('1�EfQ�v#)�\n�0EkQ','wp-admin/images/media-button-image.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','~���WÎ�@��b�rճ');
INSERT INTO `wp_wfFileMods` VALUES ('a\\c,I\"5T��#̋�','wp-admin/images/media-button-music.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��]�2\\Z�/��ޕ');
INSERT INTO `wp_wfFileMods` VALUES ('NQ�\"*hz�r�w|\Z�','wp-admin/images/media-button-other.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ƴk�|��,O�\"�');
INSERT INTO `wp_wfFileMods` VALUES ('�����)z]!?��a�','wp-admin/images/media-button-video.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','������r�x�4Q���');
INSERT INTO `wp_wfFileMods` VALUES ('a)�TMW�Oo��Q�|�','wp-admin/images/media-button.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����6@p�z^ye��');
INSERT INTO `wp_wfFileMods` VALUES ('\"��N߬jj)��\0��N','wp-admin/images/menu-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','jG�����{�>�^;$��');
INSERT INTO `wp_wfFileMods` VALUES ('* a�F���4��u�vU','wp-admin/images/menu-vs-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','J�ZY<�i�Y��b�');
INSERT INTO `wp_wfFileMods` VALUES ('t]�ٟu��u���j�','wp-admin/images/menu-vs.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','q���L�,_�;1/�E�');
INSERT INTO `wp_wfFileMods` VALUES ('@�XD\n�\nRN��t���','wp-admin/images/menu.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\r�9#�d�Y`	���');
INSERT INTO `wp_wfFileMods` VALUES ('�F �8�+�)��r�P�','wp-admin/images/no.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�k�d�$��ܟV7���');
INSERT INTO `wp_wfFileMods` VALUES ('��+D�FܿTZ[H7','wp-admin/images/post-formats-vs.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��S�l��H\\�������');
INSERT INTO `wp_wfFileMods` VALUES ('�\0��וoxi3%\r+]kg','wp-admin/images/post-formats.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�K���\0���%3���');
INSERT INTO `wp_wfFileMods` VALUES ('n]�j7<3ISsQ�','wp-admin/images/post-formats32-vs.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�t.E���5G�N\Z��v');
INSERT INTO `wp_wfFileMods` VALUES ('�œ���ϔ�=��#6','wp-admin/images/post-formats32.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','WY~�O��{�+_L�kE;');
INSERT INTO `wp_wfFileMods` VALUES ('�?{o_���\'�n�','wp-admin/images/resize-2x.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��e?�&h.��\n��');
INSERT INTO `wp_wfFileMods` VALUES ('�3!9�=�6�ݡ','wp-admin/images/resize-rtl-2x.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ɞ�@��T0:��}');
INSERT INTO `wp_wfFileMods` VALUES ('�I�{�?��r�]��7','wp-admin/images/resize-rtl.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ےc�ZY�6��');
INSERT INTO `wp_wfFileMods` VALUES ('~?�J�I�b*׺�e�C','wp-admin/images/resize.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','?�D�$�\r�Xv����a');
INSERT INTO `wp_wfFileMods` VALUES ('\nf���Y��4&�L�','wp-admin/images/se.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ȔB�`��.}\'7:');
INSERT INTO `wp_wfFileMods` VALUES ('X�:8+˓2>V]��8�','wp-admin/images/sort-2x.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','nQ&�] �0�-����');
INSERT INTO `wp_wfFileMods` VALUES ('�[6�5��+�	�n9�','wp-admin/images/sort.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','.�ˍ���lHj�]');
INSERT INTO `wp_wfFileMods` VALUES ('�J�&_#��3S�q���','wp-admin/images/spinner-2x.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\\q��9)hdxR���]l');
INSERT INTO `wp_wfFileMods` VALUES ('�f�i�`�=@T��o�','wp-admin/images/spinner.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����1c~\'�dv�vHq');
INSERT INTO `wp_wfFileMods` VALUES ('P�1$���\\*�C','wp-admin/images/stars-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��A���#�S�Me.^');
INSERT INTO `wp_wfFileMods` VALUES ('�F�j!Y�{.J=,��','wp-admin/images/stars.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','[����><�k�{��(�');
INSERT INTO `wp_wfFileMods` VALUES ('Vrm�KE�p�j��6�','wp-admin/images/w-logo-blue.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�[N�W��_p�w�0');
INSERT INTO `wp_wfFileMods` VALUES ('Jf�3?���_r�C�','wp-admin/images/w-logo-white.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�*�,K��i�l��<�');
INSERT INTO `wp_wfFileMods` VALUES ('�+���g���q6�^\0�','wp-admin/images/wheel.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','E0� q0m��\ZY%V�X�');
INSERT INTO `wp_wfFileMods` VALUES ('�%��\\��MA�����','wp-admin/images/wordpress-logo-white.svg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�c=Yܵ����s����');
INSERT INTO `wp_wfFileMods` VALUES ('tZQ��Yz0����跫','wp-admin/images/wordpress-logo.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ư�y��o�8��8S�`�');
INSERT INTO `wp_wfFileMods` VALUES ('�c\"ml� �Ǟ>o','wp-admin/images/wordpress-logo.svg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�N�%�d���g���p');
INSERT INTO `wp_wfFileMods` VALUES ('��ں�u���M���[\r','wp-admin/images/wpspin_light-2x.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','}�3��Y�(�I��m');
INSERT INTO `wp_wfFileMods` VALUES ('\"w%�_��K\\��u�','wp-admin/images/wpspin_light.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Nm�h����;\Z@��');
INSERT INTO `wp_wfFileMods` VALUES ('��<l�a��,�bX,��','wp-admin/images/xit-2x.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��r�T��`��?J�/�');
INSERT INTO `wp_wfFileMods` VALUES ('��m���z4�L��K','wp-admin/images/xit.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�)�X��`1���H��');
INSERT INTO `wp_wfFileMods` VALUES ('�M&�3\r��3CMaQ{','wp-admin/images/yes.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�+��7܉�\rqZ�Qk');
INSERT INTO `wp_wfFileMods` VALUES ('��T��V�����\\��','wp-admin/import.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','n8�]<�Ĕr��W7�@W');
INSERT INTO `wp_wfFileMods` VALUES ('D����)ba�k��{��','wp-admin/includes/admin.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�T\"AR��hy�ۺCQ)');
INSERT INTO `wp_wfFileMods` VALUES ('Ҫ*���H���\n;t��','wp-admin/includes/ajax-actions.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�&,s$y$E?��$u�');
INSERT INTO `wp_wfFileMods` VALUES ('��ΝH�*��*.ځS','wp-admin/includes/bookmark.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','V��._%B)�j�A��\Za');
INSERT INTO `wp_wfFileMods` VALUES ('�:8�Ia��øl�m','wp-admin/includes/class-ftp-pure.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',',�\\.B���������');
INSERT INTO `wp_wfFileMods` VALUES ('�afh=F���T�:��6�','wp-admin/includes/class-ftp-sockets.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','T��[���6��+��\'<');
INSERT INTO `wp_wfFileMods` VALUES ('���rp.u�3zx�','wp-admin/includes/class-ftp.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���2V�u�\\I�L��');
INSERT INTO `wp_wfFileMods` VALUES ('�\"�ơ���7vs+�','wp-admin/includes/class-pclzip.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','67(�C���ki��8�');
INSERT INTO `wp_wfFileMods` VALUES ('���Ye�.�0s��','wp-admin/includes/class-wp-comments-list-table.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��A�NGA��R��<�');
INSERT INTO `wp_wfFileMods` VALUES ('�%�f\\+,���\0\\Y','wp-admin/includes/class-wp-filesystem-base.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','=>q��$����_�p');
INSERT INTO `wp_wfFileMods` VALUES ('�hFM<@`%q-��','wp-admin/includes/class-wp-filesystem-direct.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','|h@{Q}5�c!�K0Y');
INSERT INTO `wp_wfFileMods` VALUES ('6̠,��_���q���u�','wp-admin/includes/class-wp-filesystem-ftpext.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��4��P�?~$\r�e4~');
INSERT INTO `wp_wfFileMods` VALUES ('����PQ�E|E}7+','wp-admin/includes/class-wp-filesystem-ftpsockets.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','N�<Rр��D�Fv���');
INSERT INTO `wp_wfFileMods` VALUES ('����j(g��~jU#��','wp-admin/includes/class-wp-filesystem-ssh2.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�=酅�\rc�o��<�2');
INSERT INTO `wp_wfFileMods` VALUES ('v]�z������3�tB','wp-admin/includes/class-wp-importer.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Ky�lCK��W.���5');
INSERT INTO `wp_wfFileMods` VALUES ('_�(�C���M6�9�','wp-admin/includes/class-wp-links-list-table.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','pP�����{4W�EW');
INSERT INTO `wp_wfFileMods` VALUES ('O	��S����#��Yi�v','wp-admin/includes/class-wp-list-table.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','������>�[L�shB');
INSERT INTO `wp_wfFileMods` VALUES ('�Vb(kt�W\"�6(;ƴ�','wp-admin/includes/class-wp-media-list-table.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','^�K��]$��V����');
INSERT INTO `wp_wfFileMods` VALUES ('�������sp���e�','wp-admin/includes/class-wp-ms-sites-list-table.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�i�6���|�K�{h');
INSERT INTO `wp_wfFileMods` VALUES ('�w����V���!�','wp-admin/includes/class-wp-ms-themes-list-table.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����&��ʠ��|�z�');
INSERT INTO `wp_wfFileMods` VALUES ('��i)33ܥ��s�*','wp-admin/includes/class-wp-ms-users-list-table.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��&�+�zĘ�}�İ#');
INSERT INTO `wp_wfFileMods` VALUES ('e.PȴNB�Sx[�&��','wp-admin/includes/class-wp-plugin-install-list-table.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�i1*\\\rE�`r����C');
INSERT INTO `wp_wfFileMods` VALUES ('�����[��:�����q','wp-admin/includes/class-wp-plugins-list-table.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','R�m[ދ���`\njܸ');
INSERT INTO `wp_wfFileMods` VALUES ('�Gȩ��6����\0Y','wp-admin/includes/class-wp-posts-list-table.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��La��FH[��a\'��');
INSERT INTO `wp_wfFileMods` VALUES ('���<��p\Zo@S�q��','wp-admin/includes/class-wp-press-this.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���ī��MJ�(6Q');
INSERT INTO `wp_wfFileMods` VALUES ('L#��/۰*��3���\r','wp-admin/includes/class-wp-terms-list-table.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','^�<&y�!�A���\\');
INSERT INTO `wp_wfFileMods` VALUES ('�\"ڕK[@�G����9�','wp-admin/includes/class-wp-theme-install-list-table.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��u�g��������4');
INSERT INTO `wp_wfFileMods` VALUES ('\"IFn����@�a�}�9','wp-admin/includes/class-wp-themes-list-table.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','@̔m��`b���TyTH5');
INSERT INTO `wp_wfFileMods` VALUES ('z����JX�w{!\rF���','wp-admin/includes/class-wp-upgrader-skins.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','<]��:�PGV5]f�');
INSERT INTO `wp_wfFileMods` VALUES ('X���G������z�X','wp-admin/includes/class-wp-upgrader.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ݏ2e�q���\n��');
INSERT INTO `wp_wfFileMods` VALUES ('����x8[!>�X','wp-admin/includes/class-wp-users-list-table.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�o���z��\Z4�@');
INSERT INTO `wp_wfFileMods` VALUES ('|�&;�r�Ls5��','wp-admin/includes/comment.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���\\�����\'3�)ާQ');
INSERT INTO `wp_wfFileMods` VALUES ('3k��oW�5	k[mq','wp-admin/includes/continents-cities.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','KWٛ���3��ǝ');
INSERT INTO `wp_wfFileMods` VALUES ('\\�т�?$�̈́8����','wp-admin/includes/dashboard.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','wU�s��dĂۯG');
INSERT INTO `wp_wfFileMods` VALUES ('�?��E_�)�xڅ$��','wp-admin/includes/deprecated.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','f[A���˷xg�K');
INSERT INTO `wp_wfFileMods` VALUES ('��>�A�B�7�Sz!�e','wp-admin/includes/export.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','x�o=a�*A���Td�');
INSERT INTO `wp_wfFileMods` VALUES ('QT���*�f�P��.�','wp-admin/includes/file.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��D�|#_x5�Y�Wh�');
INSERT INTO `wp_wfFileMods` VALUES ('��7��E#�wŧj���','wp-admin/includes/image-edit.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�o	z�*����R����');
INSERT INTO `wp_wfFileMods` VALUES ('\0�|9��u�e���@��','wp-admin/includes/image.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�3q��.����О���');
INSERT INTO `wp_wfFileMods` VALUES ('�A�h)I�\Z]Gr���E','wp-admin/includes/import.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ޱ�wCrݩA�\\�');
INSERT INTO `wp_wfFileMods` VALUES ('�c��wk�(���4�3�','wp-admin/includes/list-table.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����T8��>��_߂');
INSERT INTO `wp_wfFileMods` VALUES ('�R��=��*�d��n�','wp-admin/includes/media.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�RI\"��u�}��[da');
INSERT INTO `wp_wfFileMods` VALUES ('�\n�qo�qZVyX��9','wp-admin/includes/menu.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','X&Jʅ�q.�����');
INSERT INTO `wp_wfFileMods` VALUES ('Hý��i�Z�U,H�L','wp-admin/includes/meta-boxes.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�w>��+%+�%��_ڟ');
INSERT INTO `wp_wfFileMods` VALUES ('�1�eU��MV��^��','wp-admin/includes/misc.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','҆F�T���?�;�Հ�');
INSERT INTO `wp_wfFileMods` VALUES ('�7*���\"{��\n�K<','wp-admin/includes/ms-deprecated.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','/bmO��dNL	i��X');
INSERT INTO `wp_wfFileMods` VALUES ('f�霰f؟|h��U�L','wp-admin/includes/ms.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���2�*H[�s@��');
INSERT INTO `wp_wfFileMods` VALUES ('(���љ����\0H<_','wp-admin/includes/nav-menu.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�J물�@��Y�OS�p');
INSERT INTO `wp_wfFileMods` VALUES ('R��|Rx/�bzn9\0*�J','wp-admin/includes/plugin-install.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','>�8��aK�M\Z�P�O�');
INSERT INTO `wp_wfFileMods` VALUES ('q\"�co���>�2Rh�]','wp-admin/includes/plugin.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��e�\\y����:�8');
INSERT INTO `wp_wfFileMods` VALUES ('���5�V\"�$$�_��','wp-admin/includes/post.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','؉�,\'����wKt');
INSERT INTO `wp_wfFileMods` VALUES ('x�^m�]̲�/��L4vU','wp-admin/includes/revision.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��ǒU�+zm��\\�');
INSERT INTO `wp_wfFileMods` VALUES ('ǫ�=��m�/���^','wp-admin/includes/schema.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��W��y�$��G��m�@');
INSERT INTO `wp_wfFileMods` VALUES ('(���v|T�— ¥�','wp-admin/includes/screen.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�B<Y����N��&ȼ�>');
INSERT INTO `wp_wfFileMods` VALUES ('Z����� %/�Z�z9��','wp-admin/includes/taxonomy.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�E���6��|J��Ჵ');
INSERT INTO `wp_wfFileMods` VALUES ('2@�j�j\0�kӲ��Ә','wp-admin/includes/template.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','f���*�4�d��V�');
INSERT INTO `wp_wfFileMods` VALUES ('�~��L��*�,�<:�','wp-admin/includes/theme-install.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�at{V��Qƅ�*քU');
INSERT INTO `wp_wfFileMods` VALUES ('�]�W/>�}<8� VF�','wp-admin/includes/theme.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���/��k�Tb�Kx�Z');
INSERT INTO `wp_wfFileMods` VALUES ('8�R6�DH��q�-{�:`','wp-admin/includes/translation-install.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��a�\n]��r6�o�e�');
INSERT INTO `wp_wfFileMods` VALUES ('���Uy/�*%���;','wp-admin/includes/update-core.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��|*�\'�UC��a��c');
INSERT INTO `wp_wfFileMods` VALUES ('�]�.�1\rPXL�','wp-admin/includes/update.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�D\n��mz/��:���');
INSERT INTO `wp_wfFileMods` VALUES ('����=��c�ه���','wp-admin/includes/upgrade.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����裡 �����zh');
INSERT INTO `wp_wfFileMods` VALUES ('Q� ��(;ؠ|~R8�b','wp-admin/includes/user.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��_���zd��BO�V');
INSERT INTO `wp_wfFileMods` VALUES ('��I����.$U0]\'�S_','wp-admin/includes/widgets.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�J#�%sժ��ka.R�');
INSERT INTO `wp_wfFileMods` VALUES ('��Ѻ�\"�P5��^U�\Zi','wp-admin/index.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',',u��J�%yZ.�');
INSERT INTO `wp_wfFileMods` VALUES ('B��j�)��q�D�S','wp-admin/install-helper.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','T����R�~����R3Z');
INSERT INTO `wp_wfFileMods` VALUES ('�6�|;�;8�Q�4�k��','wp-admin/install.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','jH��H�.�Ӧ��%��');
INSERT INTO `wp_wfFileMods` VALUES ('z;j2WD�6��[�V','wp-admin/js/accordion.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�^V�\n�8.7p�Ct�7:');
INSERT INTO `wp_wfFileMods` VALUES ('�^.�jT}�<��I��','wp-admin/js/accordion.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Ϡ�M\0���GÁ]��');
INSERT INTO `wp_wfFileMods` VALUES ('���T����Ç=w���','wp-admin/js/bookmarklet.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Y��ἿvoFg\"��k');
INSERT INTO `wp_wfFileMods` VALUES ('~79�h�g$+�=���\\0','wp-admin/js/bookmarklet.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','`8����#���\03');
INSERT INTO `wp_wfFileMods` VALUES ('�5����\r��k��','wp-admin/js/color-picker.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����2dMM��T���');
INSERT INTO `wp_wfFileMods` VALUES ('��H���l��{!D#�!','wp-admin/js/color-picker.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\Z�}\"[}����P-�)');
INSERT INTO `wp_wfFileMods` VALUES ('C�/�;)��ّ�o','wp-admin/js/comment.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���I���4�D�O#]');
INSERT INTO `wp_wfFileMods` VALUES ('Q������l��g�-��','wp-admin/js/comment.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','8�i/y��}��*�C��');
INSERT INTO `wp_wfFileMods` VALUES ('w������:}V��P','wp-admin/js/common.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ܞ/���X�FoH2.2');
INSERT INTO `wp_wfFileMods` VALUES ('���_f $�O<o','wp-admin/js/common.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ӣ�؆p���KoR?g�(');
INSERT INTO `wp_wfFileMods` VALUES ('d��1�쵓-�;O��','wp-admin/js/custom-background.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�j�)N���ˈ¨iv#');
INSERT INTO `wp_wfFileMods` VALUES ('�} �yT��Z�H�cDJ','wp-admin/js/custom-background.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��#Y>W� �����e�');
INSERT INTO `wp_wfFileMods` VALUES ('���C\n���U���','wp-admin/js/custom-header.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','2�\0X���`o���uf�');
INSERT INTO `wp_wfFileMods` VALUES ('���nvp�e������}�','wp-admin/js/customize-controls.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','|�T�ח\n�%��c');
INSERT INTO `wp_wfFileMods` VALUES ('��dA#���*�Źo7','wp-admin/js/customize-controls.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��B�؏�f��@��.');
INSERT INTO `wp_wfFileMods` VALUES ('�)[\"J�H��|�jk��$','wp-admin/js/customize-widgets.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Q�*N��>�˘�');
INSERT INTO `wp_wfFileMods` VALUES ('fMx�����	�+9�U�','wp-admin/js/customize-widgets.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���B\0��$�A쟠');
INSERT INTO `wp_wfFileMods` VALUES ('��ĸ:�,p�1��Hr','wp-admin/js/dashboard.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ܯOh|lR<���QR4��');
INSERT INTO `wp_wfFileMods` VALUES ('����zpKC�{\\>��','wp-admin/js/dashboard.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','9�sE�/�\Z<S�(�ş�');
INSERT INTO `wp_wfFileMods` VALUES ('`%�ֽ�j��\'��P��','wp-admin/js/edit-comments.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��{(Æ�c|�љģ*3');
INSERT INTO `wp_wfFileMods` VALUES ('F�\'�B�/�4{J�{w','wp-admin/js/edit-comments.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��h�������u��');
INSERT INTO `wp_wfFileMods` VALUES ('�R��5?�- S�^H��','wp-admin/js/editor-expand.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\0�2���=��Z�');
INSERT INTO `wp_wfFileMods` VALUES ('I�V/��6�s���','wp-admin/js/editor-expand.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','x��]p1(� bΎP');
INSERT INTO `wp_wfFileMods` VALUES ('8=�I��a�%��k�~�','wp-admin/js/editor.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','3�#�h�\Z3;��q�Fq');
INSERT INTO `wp_wfFileMods` VALUES ('�⣣�M�O����U�','wp-admin/js/editor.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Aı��P��������');
INSERT INTO `wp_wfFileMods` VALUES (';R�yh���RxK�\r','wp-admin/js/farbtastic.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�:�T�2Aq]����4�');
INSERT INTO `wp_wfFileMods` VALUES ('��/GΞӶ[�ǜ��C','wp-admin/js/gallery.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�K~�l��\Z�');
INSERT INTO `wp_wfFileMods` VALUES ('� �I�_X�����?','wp-admin/js/gallery.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�o����m���dOo');
INSERT INTO `wp_wfFileMods` VALUES ('G_bc�.,]&���','wp-admin/js/image-edit.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�1���l2���z�^');
INSERT INTO `wp_wfFileMods` VALUES ('��-Z���:E�:','wp-admin/js/image-edit.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','@ɡ�mz���4n�/GX');
INSERT INTO `wp_wfFileMods` VALUES ('�%n��Tߒ	^�gXΰ','wp-admin/js/inline-edit-post.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Vӎ���}�_��\n�)�');
INSERT INTO `wp_wfFileMods` VALUES ('�1�o%��q�A��','wp-admin/js/inline-edit-post.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','~{&�di�Y�0�\\�*z');
INSERT INTO `wp_wfFileMods` VALUES ('�(�q�4P�}�5Oz�k','wp-admin/js/inline-edit-tax.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','� q�8^uၓ�)?��<');
INSERT INTO `wp_wfFileMods` VALUES ('����p�l4[���e���','wp-admin/js/inline-edit-tax.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','J����`$?\0=>�G���');
INSERT INTO `wp_wfFileMods` VALUES ('�lF����c뒕�L���','wp-admin/js/iris.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','u�5`�@Ħ�Ue߰�');
INSERT INTO `wp_wfFileMods` VALUES ('i�\\����=X�h$','wp-admin/js/language-chooser.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','	�P�V0��tJ�J');
INSERT INTO `wp_wfFileMods` VALUES ('����Z�\Zxcy�d��\'','wp-admin/js/language-chooser.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','h\"8Jq	t���F��');
INSERT INTO `wp_wfFileMods` VALUES ('��QR\"��@3��v�S','wp-admin/js/link.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�u��5ϳt�{��z�');
INSERT INTO `wp_wfFileMods` VALUES ('�|�#�԰#�{�����','wp-admin/js/link.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��F��0�;���3�%-');
INSERT INTO `wp_wfFileMods` VALUES ('nZ/1T:{&^�/n���','wp-admin/js/media-gallery.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','|��f����8�}+&');
INSERT INTO `wp_wfFileMods` VALUES (':���%H`!���\r�Z','wp-admin/js/media-gallery.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','2��� Ғ�����n');
INSERT INTO `wp_wfFileMods` VALUES ('��^�\\�X�PvS�\\�{','wp-admin/js/media-upload.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','_f����b�f��\n��');
INSERT INTO `wp_wfFileMods` VALUES ('�el�5�s��E�úQ�','wp-admin/js/media-upload.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','a�p�3� \n�^$e&z�');
INSERT INTO `wp_wfFileMods` VALUES ('r�(n՞���j��b\"','wp-admin/js/media.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','υ�^p0LB�uSŅ');
INSERT INTO `wp_wfFileMods` VALUES ('מ�y�7mE5���O_�','wp-admin/js/media.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','.���$!&��^$�Y');
INSERT INTO `wp_wfFileMods` VALUES ('�� ��It13&','wp-admin/js/nav-menu.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��ˊ������@��*');
INSERT INTO `wp_wfFileMods` VALUES ('�f��y���ħ�*!','wp-admin/js/nav-menu.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�������.g;u��+#');
INSERT INTO `wp_wfFileMods` VALUES ('��\"\rJ\04��\'i�','wp-admin/js/password-strength-meter.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','M�(F�Vp��#*�{�');
INSERT INTO `wp_wfFileMods` VALUES ('���Ȁ�~_q�I��S�','wp-admin/js/password-strength-meter.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','1��|��=��m�U��');
INSERT INTO `wp_wfFileMods` VALUES ('t6��O�\ra��Ȇ�f','wp-admin/js/plugin-install.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�XR7�5�1:]��S�');
INSERT INTO `wp_wfFileMods` VALUES ('!����Y0-z1�dm>�','wp-admin/js/plugin-install.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','zb�\n�d�&�o�f�>�');
INSERT INTO `wp_wfFileMods` VALUES ('V�����댏$�x','wp-admin/js/post.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�_��K�g�{=q�rbI�');
INSERT INTO `wp_wfFileMods` VALUES ('M?,5�*�����K*�f','wp-admin/js/post.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�}���N�CR���Yp�');
INSERT INTO `wp_wfFileMods` VALUES ('P\'�(���?+�z��$�','wp-admin/js/postbox.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����o%�zb|䨎�Y');
INSERT INTO `wp_wfFileMods` VALUES ('O����R�r����D�?�','wp-admin/js/postbox.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��#��$�-�!i>');
INSERT INTO `wp_wfFileMods` VALUES ('@b�Hf�Q�\"$��S','wp-admin/js/press-this.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��:�q��⭊%�sR~');
INSERT INTO `wp_wfFileMods` VALUES ('Ր(������@��','wp-admin/js/press-this.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','h.[t�y\Z�	��1��J');
INSERT INTO `wp_wfFileMods` VALUES ('���\\��9�ѕ�F�w�','wp-admin/js/revisions.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','A�F�{�~�\r�\'Y�i');
INSERT INTO `wp_wfFileMods` VALUES ('�k����e<F��4','wp-admin/js/revisions.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','2S�l��R;�]2�Lj�');
INSERT INTO `wp_wfFileMods` VALUES ('K��W�&\0\0K�\06�G�','wp-admin/js/set-post-thumbnail.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','+QSWm�@�~��Q');
INSERT INTO `wp_wfFileMods` VALUES ('T�gslF���ʞ��Ly','wp-admin/js/set-post-thumbnail.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����8�կ!�1z[');
INSERT INTO `wp_wfFileMods` VALUES ('�Z/���{Lt�ծF$�','wp-admin/js/svg-painter.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�����/�|ĩ���z�');
INSERT INTO `wp_wfFileMods` VALUES ('�U<�?Y,����ػ(','wp-admin/js/svg-painter.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�����fu���');
INSERT INTO `wp_wfFileMods` VALUES ('�G�|$p֠+(�','wp-admin/js/tags-box.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','t��f����  ��#�');
INSERT INTO `wp_wfFileMods` VALUES ('���J1��M�F��<�','wp-admin/js/tags-box.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Kn���<ס�x٩');
INSERT INTO `wp_wfFileMods` VALUES ('{t�E~��P�A�1��','wp-admin/js/tags.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','L�Bf�Z��<���/s');
INSERT INTO `wp_wfFileMods` VALUES ('�fkj��N�Uei4=%�','wp-admin/js/tags.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','/I�@�!{�hL�R\Z�');
INSERT INTO `wp_wfFileMods` VALUES ('�#\\���/�vXR','wp-admin/js/theme.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��b���\n]]��\"0');
INSERT INTO `wp_wfFileMods` VALUES ('G6U�2\01R������J','wp-admin/js/theme.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',';���q���S���$�b�');
INSERT INTO `wp_wfFileMods` VALUES ('+9���[BU�E�e','wp-admin/js/updates.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','y��f����\0|�o�');
INSERT INTO `wp_wfFileMods` VALUES ('([d��������BQ��','wp-admin/js/updates.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Z[i�j(�N��h�\\!�');
INSERT INTO `wp_wfFileMods` VALUES ('�����\'>�[��·�','wp-admin/js/user-profile.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','(		!�{��*�=�&�\0');
INSERT INTO `wp_wfFileMods` VALUES ('������H�S!;� �','wp-admin/js/user-profile.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','j@#�wP<Pw��2�');
INSERT INTO `wp_wfFileMods` VALUES ('R¥�����Le�q	�&�','wp-admin/js/user-suggest.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','3)��()ݰ4}\n�');
INSERT INTO `wp_wfFileMods` VALUES ('�X��$�a��B��^','wp-admin/js/user-suggest.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��T\\���\\|�\r�9�');
INSERT INTO `wp_wfFileMods` VALUES ('RQ�b7f�� |~ۓ�(','wp-admin/js/widgets.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','H]�mH�W9H\'�����');
INSERT INTO `wp_wfFileMods` VALUES ('�Sx��4�@o�w�N','wp-admin/js/widgets.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','L,3�%�q���	���Ӑ');
INSERT INTO `wp_wfFileMods` VALUES ('P73o�	��\0�=��','wp-admin/js/word-count.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','f%i�@Q��1��N');
INSERT INTO `wp_wfFileMods` VALUES ('��Cg����}|�E��','wp-admin/js/word-count.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�̮�E��^�:��/_�');
INSERT INTO `wp_wfFileMods` VALUES ('iAh{���M(�|J,��','wp-admin/js/wp-fullscreen.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','f��A�o��\0)`�o�');
INSERT INTO `wp_wfFileMods` VALUES ('}���>/\Z���+i�V','wp-admin/js/wp-fullscreen.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','֨���9�Z%�S=2�');
INSERT INTO `wp_wfFileMods` VALUES ('v����4�|>�<����','wp-admin/js/xfn.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�����t�+��n�(k');
INSERT INTO `wp_wfFileMods` VALUES ('頻�yN<���9�o\Z<','wp-admin/js/xfn.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','f�\'�(�.�J9\r^');
INSERT INTO `wp_wfFileMods` VALUES ('|��Y�>���	�Ɔ�','wp-admin/link-add.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','u�G�D�/�ϥ�W��');
INSERT INTO `wp_wfFileMods` VALUES ('�B%v6�I\"Jb��4ӡT','wp-admin/link-manager.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','AlN.���+Qc��и�');
INSERT INTO `wp_wfFileMods` VALUES ('��~������r�C��','wp-admin/link-parse-opml.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Dm����䁐�f�8��');
INSERT INTO `wp_wfFileMods` VALUES (':{���{7�9����','wp-admin/link.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','c���Na�b���d');
INSERT INTO `wp_wfFileMods` VALUES ('6�]j�v�W�k\r3-�','wp-admin/load-scripts.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','>7�q�\0�}�0[��0');
INSERT INTO `wp_wfFileMods` VALUES ('W})Ӗ7���e�}5�9,','wp-admin/load-styles.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��E��0VO��r����');
INSERT INTO `wp_wfFileMods` VALUES ('��K���OȖ9�3|<�','wp-admin/maint/repair.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',';�#\0�24P2�pe�4');
INSERT INTO `wp_wfFileMods` VALUES ('J{�ֹZi^ùx�I','wp-admin/media-new.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���x�\"������[��');
INSERT INTO `wp_wfFileMods` VALUES ('���������}��','wp-admin/media-upload.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','T��J@�����!���');
INSERT INTO `wp_wfFileMods` VALUES ('�ÏuL�,�&Ǒ�\r1','wp-admin/media.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�2=KB������H��B');
INSERT INTO `wp_wfFileMods` VALUES ('�$�ī�I�^��3���','wp-admin/menu-header.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','w\"\0R�|YrI��ׂR�');
INSERT INTO `wp_wfFileMods` VALUES ('���\\�D �>�F,���','wp-admin/menu.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��F��z�ehV��\n�� ');
INSERT INTO `wp_wfFileMods` VALUES ('W{�g- X���\'=n8','wp-admin/moderation.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','TB���YR��\"4�o�');
INSERT INTO `wp_wfFileMods` VALUES ('vw��@�H��z�F�','wp-admin/ms-admin.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���@�ͯE�b6�');
INSERT INTO `wp_wfFileMods` VALUES ('&ee�\n3K���vZ��','wp-admin/ms-delete-site.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��A��;t�?OaQvQ�');
INSERT INTO `wp_wfFileMods` VALUES ('E�V���,�%��,SM=','wp-admin/ms-edit.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�/�Ħý��:E�');
INSERT INTO `wp_wfFileMods` VALUES ('\"(}G��r�	0��V(','wp-admin/ms-options.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\'�\0�}��:��ㆯ�');
INSERT INTO `wp_wfFileMods` VALUES ('�-1�8�;�T�/X�]','wp-admin/ms-sites.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',']b$�����q����h');
INSERT INTO `wp_wfFileMods` VALUES ('��=b�6��hs���t','wp-admin/ms-themes.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','R�K��$�IZ1�i%�');
INSERT INTO `wp_wfFileMods` VALUES ('\\�����9������','wp-admin/ms-upgrade-network.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','|��&\"�S�m��8h�m');
INSERT INTO `wp_wfFileMods` VALUES ('�k�UL��ǡ�$���','wp-admin/ms-users.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','H#�f{#ʃ��	6G�');
INSERT INTO `wp_wfFileMods` VALUES ('\rxݍ�^���\Z���<;','wp-admin/my-sites.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','W_H�3��8	����j�');
INSERT INTO `wp_wfFileMods` VALUES ('���Clo�������','wp-admin/nav-menus.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','x������\Z͉���');
INSERT INTO `wp_wfFileMods` VALUES ('�o����l>��x~I� �','wp-admin/network/about.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��=���SV��V���');
INSERT INTO `wp_wfFileMods` VALUES ('���ZQ4��\\(�܇','wp-admin/network/admin.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','N��5Cs��	�');
INSERT INTO `wp_wfFileMods` VALUES ('+���t�%R?������','wp-admin/network/credits.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','8,�4,���X���u�');
INSERT INTO `wp_wfFileMods` VALUES ('\'ڞ\0;��?�+VҪ�','wp-admin/network/edit.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\r�^�Y�&��;^���\Z');
INSERT INTO `wp_wfFileMods` VALUES ('�uF��^G��E+��c','wp-admin/network/freedoms.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����p�O~+�~�1');
INSERT INTO `wp_wfFileMods` VALUES ('\0C_\n��jD��@k','wp-admin/network/index.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�V1�r/���.���J');
INSERT INTO `wp_wfFileMods` VALUES (']��P���Tkvt��8A','wp-admin/network/menu.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\Z�=S[�fx�������');
INSERT INTO `wp_wfFileMods` VALUES ('��[ixT�q��~Wv�e','wp-admin/network/plugin-editor.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','?�͚�GM�XZ\ri=�');
INSERT INTO `wp_wfFileMods` VALUES ('��p�$^���d�Z','wp-admin/network/plugin-install.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','k��Oy_��4�)�\Z���');
INSERT INTO `wp_wfFileMods` VALUES ('�����\"Sέ`t@','wp-admin/network/plugins.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','A��|��MM0\0���');
INSERT INTO `wp_wfFileMods` VALUES ('�=�}C���i��HT','wp-admin/network/profile.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�i&�Q\\Ӣ�綨');
INSERT INTO `wp_wfFileMods` VALUES ('��\Za�]]�A��\'h���','wp-admin/network/settings.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��Y����{D=l�e');
INSERT INTO `wp_wfFileMods` VALUES ('/�s��C4��������','wp-admin/network/setup.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��Bm>n9z]�њ�');
INSERT INTO `wp_wfFileMods` VALUES ('+��G*#�������f�','wp-admin/network/site-info.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�|�P�|�N�F\nΎm6');
INSERT INTO `wp_wfFileMods` VALUES ('y���G�\\`����MR�','wp-admin/network/site-new.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','q��y����(�l�#nK');
INSERT INTO `wp_wfFileMods` VALUES ('��yc�0O�g)ρ�Mf�','wp-admin/network/site-settings.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�j@�~%�����xs');
INSERT INTO `wp_wfFileMods` VALUES ('�q�h���Bc�92��','wp-admin/network/site-themes.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�!l|�2��V_��');
INSERT INTO `wp_wfFileMods` VALUES ('�q�@/��ꦑٞ-M�','wp-admin/network/site-users.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ڄ\"�\'��\r.���');
INSERT INTO `wp_wfFileMods` VALUES ('n����@��A��F�','wp-admin/network/sites.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��bd�Y.|��K�');
INSERT INTO `wp_wfFileMods` VALUES ('{N���2�Q�u��=	�','wp-admin/network/theme-editor.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�O�F��dm����j');
INSERT INTO `wp_wfFileMods` VALUES ('h|hE��f:Ʊ2��~','wp-admin/network/theme-install.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','&շ�1Up�%��1=$�');
INSERT INTO `wp_wfFileMods` VALUES ('��!}�=�`*�gZ=','wp-admin/network/themes.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�x����y|��C');
INSERT INTO `wp_wfFileMods` VALUES ('7|oOU���z\0Ef���','wp-admin/network/update-core.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\"?}R2{8\\��?R�');
INSERT INTO `wp_wfFileMods` VALUES ('��\\�(��wB��I�','wp-admin/network/update.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�E�^�!��u��)�u�');
INSERT INTO `wp_wfFileMods` VALUES ('r��h��v��Lk/��','wp-admin/network/upgrade.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�#9091N���d�H');
INSERT INTO `wp_wfFileMods` VALUES ('\00��#�9���Z4�j$','wp-admin/network/user-edit.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','1�s�̶>��Ѕc��');
INSERT INTO `wp_wfFileMods` VALUES ('��6K1���(���}/AX','wp-admin/network/user-new.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���6�\'G��g$�');
INSERT INTO `wp_wfFileMods` VALUES ('	����09��-b��ͩW','wp-admin/network/users.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Zv\\����ǝ{�g2');
INSERT INTO `wp_wfFileMods` VALUES ('�d���lP�O��I�','wp-admin/network.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','&��9�{e�,Yj��\n');
INSERT INTO `wp_wfFileMods` VALUES ('�JTV0D��oTA［@�','wp-admin/options-discussion.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','c{��7��ֺX��.tR�');
INSERT INTO `wp_wfFileMods` VALUES ('o�[��n3u��ʹ�P5','wp-admin/options-general.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����q�����7֔�');
INSERT INTO `wp_wfFileMods` VALUES ('\rѪ1s1=��`(�y','wp-admin/options-head.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�֕`^m�N@\nTof~�');
INSERT INTO `wp_wfFileMods` VALUES ('���\\��.1��-��:','wp-admin/options-media.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��7�3�1T�w&;��');
INSERT INTO `wp_wfFileMods` VALUES ('�)����t\r�,�Jڼ','wp-admin/options-permalink.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Kj�rU�54�Z�R�$');
INSERT INTO `wp_wfFileMods` VALUES ('ҲE5|�ѵ�C�d闼','wp-admin/options-reading.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','V�qu��}��-.�Ja');
INSERT INTO `wp_wfFileMods` VALUES ('�L�>�ٟ�#{6p}Y��','wp-admin/options-writing.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','_��H��J1dk����');
INSERT INTO `wp_wfFileMods` VALUES ('d�(��%J���@�G�','wp-admin/options.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',',�o�sn���]�T�\Z');
INSERT INTO `wp_wfFileMods` VALUES ('a�c�CH\r��=l@ĸ','wp-admin/plugin-editor.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\r~��`3\Z��}@�[V�P');
INSERT INTO `wp_wfFileMods` VALUES ('�xjP�����!c�x','wp-admin/plugin-install.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���/�Q�٩̪}5,\n');
INSERT INTO `wp_wfFileMods` VALUES ('O��\\���P5���{�R�','wp-admin/plugins.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��j������');
INSERT INTO `wp_wfFileMods` VALUES ('�k���zߣ����bo�R','wp-admin/post-new.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Z�6>!?~E����De�');
INSERT INTO `wp_wfFileMods` VALUES ('��vA�ds�����K�]','wp-admin/post.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','!hLy�:��\"E��');
INSERT INTO `wp_wfFileMods` VALUES ('Q�`���8�M�8','wp-admin/press-this.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�:U�/��vřc�K�J');
INSERT INTO `wp_wfFileMods` VALUES ('h4���#3�`�-݈�\"�','wp-admin/profile.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���?���>z�ͩ��z&');
INSERT INTO `wp_wfFileMods` VALUES ('\\�\0��>�+���Fb��','wp-admin/revision.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����f��#�=�|�B�');
INSERT INTO `wp_wfFileMods` VALUES ('�c�̎��$\n\'@�\r��','wp-admin/setup-config.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��2�K�[D+^����/');
INSERT INTO `wp_wfFileMods` VALUES ('&�`�O�Q5�Q�43�','wp-admin/theme-editor.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','NGQn�]/�A�E_��');
INSERT INTO `wp_wfFileMods` VALUES ('\n�\r�B��p̭','wp-admin/theme-install.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','jH���wY���');
INSERT INTO `wp_wfFileMods` VALUES ('����^[X��i�	�','wp-admin/themes.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Lg8pt.����ץn');
INSERT INTO `wp_wfFileMods` VALUES ('�7s�\\]�}�AA�we1�','wp-admin/tools.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','{�8�.�g���_\\+U');
INSERT INTO `wp_wfFileMods` VALUES ('�!�LT�3��i��x�','wp-admin/update-core.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','u�w�C�!_H�;D����');
INSERT INTO `wp_wfFileMods` VALUES ('!o�\r��A��v7��e','wp-admin/update.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��C�$B3FOl`�8');
INSERT INTO `wp_wfFileMods` VALUES ('^@ղ{\'��_���92','wp-admin/upgrade-functions.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','^����uP�qX\\e��');
INSERT INTO `wp_wfFileMods` VALUES ('���j7r[�,���Z��','wp-admin/upgrade.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','-&6��ۉ<g�k�6s�');
INSERT INTO `wp_wfFileMods` VALUES ('&t!0^g��bJ�c,>3','wp-admin/upload.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','2\'�w�%�M�Ǽ��');
INSERT INTO `wp_wfFileMods` VALUES ('^9(-(Ų�y ���0q*','wp-admin/user/about.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��\0ڍ�KN� ���N�-');
INSERT INTO `wp_wfFileMods` VALUES ('1s�)6�Ӷ���C��Η','wp-admin/user/admin.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��\'�$�U�m�x�Z');
INSERT INTO `wp_wfFileMods` VALUES ('�����~\r\ZK4(#��','wp-admin/user/credits.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','� ����ǀ[K}�Z');
INSERT INTO `wp_wfFileMods` VALUES ('�R;lzO�8m<3�Nie','wp-admin/user/freedoms.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�˹��޳H�t��i.');
INSERT INTO `wp_wfFileMods` VALUES ('[ꠏ�|K�o�یb7�','wp-admin/user/index.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','������-x���Nb��');
INSERT INTO `wp_wfFileMods` VALUES ('�����y��\0�\"��Q','wp-admin/user/menu.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�)��»�g��E�p�');
INSERT INTO `wp_wfFileMods` VALUES ('���`�&X<�aQ�Vh\\','wp-admin/user/profile.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','������\0yݤ�&-');
INSERT INTO `wp_wfFileMods` VALUES ('�=��q�\rljA+','wp-admin/user/user-edit.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','*zu�c���m	J��e�');
INSERT INTO `wp_wfFileMods` VALUES ('�Jh|��0�`Zp�E','wp-admin/user-edit.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�fϧ=�i\Zw�U���x�');
INSERT INTO `wp_wfFileMods` VALUES (' *@ADғ�=pu���E','wp-admin/user-new.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',':��P�>.����M^�');
INSERT INTO `wp_wfFileMods` VALUES ('P��iz�t�a�}�a','wp-admin/users.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','4�ep<\'��ݖ�?5��');
INSERT INTO `wp_wfFileMods` VALUES ('�T�h���zP��r�','wp-admin/widgets.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�˂�ב�_/\Zh�\n:');
INSERT INTO `wp_wfFileMods` VALUES ('I��:Bs�#����@�','wp-blog-header.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','_��n:�����5�S�5�');
INSERT INTO `wp_wfFileMods` VALUES ('S����p�>��Wr�YE','wp-comments-post.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�����Х�l��%�f�');
INSERT INTO `wp_wfFileMods` VALUES ('~ť�s\0�1y�$�L}h','wp-config-sample.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','o\"M�p��q��$vB');
INSERT INTO `wp_wfFileMods` VALUES ('vK;@�s�aU1;�	^�','wp-config.php',0,'��f��4�d��kQ��','��f��4�d��kQ��');
INSERT INTO `wp_wfFileMods` VALUES ('�-^g��̺@\0/���','wp-content/index.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','gD,V�=\\�bP');
INSERT INTO `wp_wfFileMods` VALUES ('��w��i.�w�(M;0D','wp-content/plugins/akismet/.htaccess',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��,\"�ڨwG�i���');
INSERT INTO `wp_wfFileMods` VALUES ('L�\r��Ȧ:��n�h\'','wp-content/plugins/akismet/_inc/akismet.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���\0\r�q�[���{');
INSERT INTO `wp_wfFileMods` VALUES ('̽� ���X�$oB�','wp-content/plugins/akismet/_inc/akismet.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','*h�\0N)!�Bc;\\��');
INSERT INTO `wp_wfFileMods` VALUES ('<B��ʱ�A51ӱ','wp-content/plugins/akismet/_inc/form.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\'�4�l*��&��i');
INSERT INTO `wp_wfFileMods` VALUES ('�\'P��T]�	�6�~�','wp-content/plugins/akismet/_inc/img/logo-full-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','!M�pP��`-6����');
INSERT INTO `wp_wfFileMods` VALUES (')̃�2�k�h���! ','wp-content/plugins/akismet/akismet.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Y,��g�}�Z�0�S�');
INSERT INTO `wp_wfFileMods` VALUES ('���jK�&����Y','wp-content/plugins/akismet/class.akismet-admin.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��Ζ7����8x���');
INSERT INTO `wp_wfFileMods` VALUES ('�l�g<���=�l�','wp-content/plugins/akismet/class.akismet-widget.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�/�\"�k<)��K� ��');
INSERT INTO `wp_wfFileMods` VALUES ('p����b�~�oBk�Z','wp-content/plugins/akismet/class.akismet.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','l�$da�&���4RI-ז');
INSERT INTO `wp_wfFileMods` VALUES ('A���$h��՝`Q�a','wp-content/plugins/akismet/index.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�h�� P�Z���ݢ`Ef');
INSERT INTO `wp_wfFileMods` VALUES ('�o�/�d��4x`��','wp-content/plugins/akismet/readme.txt',0,'���	l��������','���	l��������');
INSERT INTO `wp_wfFileMods` VALUES ('��>Zb�o&����','wp-content/plugins/akismet/views/config.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','kjސ�\ZD�_7���');
INSERT INTO `wp_wfFileMods` VALUES ('�b�E��3�g\'cZ (��','wp-content/plugins/akismet/views/get.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','-�ԓ$�T$x�#Z�<�c');
INSERT INTO `wp_wfFileMods` VALUES ('���Wd�;C\r���O�','wp-content/plugins/akismet/views/notice.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�����\n��;�8��&�');
INSERT INTO `wp_wfFileMods` VALUES ('��;�;/J�KmR��0�','wp-content/plugins/akismet/views/start.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','W��0Y��Hvַ�#');
INSERT INTO `wp_wfFileMods` VALUES ('s��ӣJ���~��k','wp-content/plugins/akismet/views/stats.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','D���E�ax�t/�ZT ');
INSERT INTO `wp_wfFileMods` VALUES ('�\r�`��� �7��x�','wp-content/plugins/akismet/views/strict.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','J�s�LU1Y��V�s��V');
INSERT INTO `wp_wfFileMods` VALUES ('dF=���j��Hc�����','wp-content/plugins/akismet/wrapper.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Z�&M\rL�B�E�#');
INSERT INTO `wp_wfFileMods` VALUES ('\Z�d��Vl���&�>mk','wp-content/plugins/dw-question-answer/.gitignore',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Cm1)��^�qQ8����');
INSERT INTO `wp_wfFileMods` VALUES ('�}��D��%�.1q�','wp-content/plugins/dw-question-answer/.travis.yml',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','&�v�d�\0G��gV�a��');
INSERT INTO `wp_wfFileMods` VALUES ('z��X\0�^t�;�ZKj��','wp-content/plugins/dw-question-answer/LICENSE',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','x;~@��JD�[p��f');
INSERT INTO `wp_wfFileMods` VALUES ('�;�O)F>�x�*\Z=��','wp-content/plugins/dw-question-answer/assets/banner-772x250.jpg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','MXR㔱x��F�n\'�');
INSERT INTO `wp_wfFileMods` VALUES ('zkly�\'j�hΡ,���','wp-content/plugins/dw-question-answer/assets/css/admin-style.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�5m�\'{�Ɂu��Z>�');
INSERT INTO `wp_wfFileMods` VALUES ('\Zo/\r��r�����8','wp-content/plugins/dw-question-answer/assets/css/email-template-editor.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','L9�����B+�9');
INSERT INTO `wp_wfFileMods` VALUES (')����Z}T/�ܰ�','wp-content/plugins/dw-question-answer/assets/css/prettify.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ԥ�����h��\0d�');
INSERT INTO `wp_wfFileMods` VALUES ('��0�r�x���6Ga��','wp-content/plugins/dw-question-answer/assets/css/style.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','=�A���;T\n�.+9s�');
INSERT INTO `wp_wfFileMods` VALUES ('\',�~\'��(+�v','wp-content/plugins/dw-question-answer/assets/css/tinymce.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�P5i ��ֹ\n�{�');
INSERT INTO `wp_wfFileMods` VALUES ('P���ܥ�i:J�{֑�','wp-content/plugins/dw-question-answer/assets/js/admin-pointer-helper.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','E�z��^CL>�d���');
INSERT INTO `wp_wfFileMods` VALUES ('4��\ZbF!e=','wp-content/plugins/dw-question-answer/assets/js/admin-settings-page.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�9�R���,xw���Ư');
INSERT INTO `wp_wfFileMods` VALUES ('��z�Ӥw��wp$�','wp-content/plugins/dw-question-answer/assets/js/code-edit-button.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','1��qҋ��˕9�9�\Z');
INSERT INTO `wp_wfFileMods` VALUES ('���_i$&��nd��','wp-content/plugins/dw-question-answer/assets/js/prettify.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','P��w\\`�J�ӳ{�g');
INSERT INTO `wp_wfFileMods` VALUES (',�/����p_�\n��S�','wp-content/plugins/dw-question-answer/assets/less/mixins.less',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�k�}FzB	��iT��&');
INSERT INTO `wp_wfFileMods` VALUES ('-�e�i@��_o��ӑ$','wp-content/plugins/dw-question-answer/assets/less/variables.less',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�J�U*�1Ȉc@��/C.');
INSERT INTO `wp_wfFileMods` VALUES ('����\0��a0��Y�w�','wp-content/plugins/dw-question-answer/bin/install-wp-tests.sh',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','_g�O9u���H5̩');
INSERT INTO `wp_wfFileMods` VALUES ('��a��:�o�A��0�','wp-content/plugins/dw-question-answer/codesniffer.ruleset.xml',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��~SW�j.��H֩');
INSERT INTO `wp_wfFileMods` VALUES ('w�bź��B:YD�1N�','wp-content/plugins/dw-question-answer/dw-question-answer.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','C�<���(*UW�#2');
INSERT INTO `wp_wfFileMods` VALUES ('�\"^��\Z���U\n�v','wp-content/plugins/dw-question-answer/inc/actions-question.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','}D�Y�.�\\r�C�$�');
INSERT INTO `wp_wfFileMods` VALUES ('#��R.�+2C�9Џz','wp-content/plugins/dw-question-answer/inc/actions-vote.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','_(�X\Z��:\Z-!V%�');
INSERT INTO `wp_wfFileMods` VALUES ('�u������>4\rF�','wp-content/plugins/dw-question-answer/inc/actions.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�$+��;$�sPc\\��');
INSERT INTO `wp_wfFileMods` VALUES ('���� `�ܡsE*C]','wp-content/plugins/dw-question-answer/inc/beta.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','|,C�bW��5�l�9P\Zd');
INSERT INTO `wp_wfFileMods` VALUES ('!8���yL��2!��','wp-content/plugins/dw-question-answer/inc/cache.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','lpAjlȜ�@μZ');
INSERT INTO `wp_wfFileMods` VALUES ('\0K��\"��03o����','wp-content/plugins/dw-question-answer/inc/class-answers-list-table.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��;\\�8�\n�������=');
INSERT INTO `wp_wfFileMods` VALUES ('����m .�S���}�','wp-content/plugins/dw-question-answer/inc/class-walker-category.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','{�!���A%6�');
INSERT INTO `wp_wfFileMods` VALUES ('���YV�ז�?1)�','wp-content/plugins/dw-question-answer/inc/class-walker-tag-dropdown.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','o�f���ѡ�b��');
INSERT INTO `wp_wfFileMods` VALUES ('�1a���[�O�r�g�','wp-content/plugins/dw-question-answer/inc/contextual-helper.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','9(4��EK췯u�nФ,');
INSERT INTO `wp_wfFileMods` VALUES ('DXc�\Z\Z�9E[����','wp-content/plugins/dw-question-answer/inc/database_upgrade.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','U�\'GD������JQI\n');
INSERT INTO `wp_wfFileMods` VALUES ('�r��o����aҬ^5','wp-content/plugins/dw-question-answer/inc/deprecated.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\0;�z�8l:���sf�');
INSERT INTO `wp_wfFileMods` VALUES ('��Y��7�����I��','wp-content/plugins/dw-question-answer/inc/filter.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Ǵ\0)r&̘��ih�z�');
INSERT INTO `wp_wfFileMods` VALUES ('�|��*\r��uӁ-np�','wp-content/plugins/dw-question-answer/inc/lib/recaptcha-php/LICENSE',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��=M�n�F#�A\'2');
INSERT INTO `wp_wfFileMods` VALUES ('@zdΠ��Fy��*[P','wp-content/plugins/dw-question-answer/inc/lib/recaptcha-php/README',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��{�)����(Y�$�');
INSERT INTO `wp_wfFileMods` VALUES ('������4e�!','wp-content/plugins/dw-question-answer/inc/lib/recaptcha-php/example-captcha.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\Z0Ib�ӹx�(q�<');
INSERT INTO `wp_wfFileMods` VALUES ('��TT���y��|�','wp-content/plugins/dw-question-answer/inc/lib/recaptcha-php/example-mailhide.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','<\r��Y�ǇN6�U7C	');
INSERT INTO `wp_wfFileMods` VALUES (' ��.�u�Zƭ��JZ�','wp-content/plugins/dw-question-answer/inc/lib/recaptcha-php/recaptchalib.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�V��sV1�z�[');
INSERT INTO `wp_wfFileMods` VALUES ('3��Y3W��,&���Q','wp-content/plugins/dw-question-answer/inc/metaboxes.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����B�^����M���');
INSERT INTO `wp_wfFileMods` VALUES ('7�Q�c�)\'���t�','wp-content/plugins/dw-question-answer/inc/notification.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\'�C�$^ϭ�A�r�');
INSERT INTO `wp_wfFileMods` VALUES ('�6BVM����he4��','wp-content/plugins/dw-question-answer/inc/pointer-helper.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��%T�u�,�+w%T');
INSERT INTO `wp_wfFileMods` VALUES (']Q��`0!vPQe�','wp-content/plugins/dw-question-answer/inc/roles.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','p��g�.B���\0�T');
INSERT INTO `wp_wfFileMods` VALUES ('��\0p}�zLF��U�','wp-content/plugins/dw-question-answer/inc/settings.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','S�;�*�2x����̵');
INSERT INTO `wp_wfFileMods` VALUES ('���Es@9�I��T�G�','wp-content/plugins/dw-question-answer/inc/shortcodes.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�{Z�y�b9r���uk');
INSERT INTO `wp_wfFileMods` VALUES ('R�u�����\n��x���.','wp-content/plugins/dw-question-answer/inc/status.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ۀ��O�`�ȺH3\\�>');
INSERT INTO `wp_wfFileMods` VALUES ('��ܞ�\ny���\Z��]','wp-content/plugins/dw-question-answer/inc/template-functions.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�/�\"R?�љѿz`�');
INSERT INTO `wp_wfFileMods` VALUES ('W��+��\"Z��G��','wp-content/plugins/dw-question-answer/inc/templates/default/answer-submit-form.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','^D�j�I��$���L�');
INSERT INTO `wp_wfFileMods` VALUES ('�����m��S�Z}�L5�','wp-content/plugins/dw-question-answer/inc/templates/default/answers.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�W�` �&�\\>�+\'�');
INSERT INTO `wp_wfFileMods` VALUES ('=*A��;I���ɖR4�','wp-content/plugins/dw-question-answer/inc/templates/default/archive-question-notfound.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��;Z�izpޢ1.}I�');
INSERT INTO `wp_wfFileMods` VALUES ('���&�6�\r�OA����','wp-content/plugins/dw-question-answer/inc/templates/default/archive-question.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\rظ������y�ܷ�');
INSERT INTO `wp_wfFileMods` VALUES ('�\nm��iո�,��','wp-content/plugins/dw-question-answer/inc/templates/default/assets/css/embed-question.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�&;:�r�.\r>Q�}�');
INSERT INTO `wp_wfFileMods` VALUES ('�T�V�z����p�0�','wp-content/plugins/dw-question-answer/inc/templates/default/assets/css/style.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','>6�˥��e=�#Vb�\n');
INSERT INTO `wp_wfFileMods` VALUES ('����LNB�k:�%�','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/css/font-awesome.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��\ZZ4}�^��r.�');
INSERT INTO `wp_wfFileMods` VALUES ('JC�Su]\"��+E���','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/css/font-awesome.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�hh�,��Q��%Ɗ��');
INSERT INTO `wp_wfFileMods` VALUES ('�����Ob(b�\'���b','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/fonts/FontAwesome.otf',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','?:b>��\\b�6q��g');
INSERT INTO `wp_wfFileMods` VALUES ('��n@�	h\'�ݻ��m�','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/fonts/fontawesome-webfont.eot',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\'��\\-$5\r	�C?');
INSERT INTO `wp_wfFileMods` VALUES ('o���i,d$k���','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/fonts/fontawesome-webfont.svg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\ny�H��,o8���uY');
INSERT INTO `wp_wfFileMods` VALUES ('���x��~��䥫}�','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/fonts/fontawesome-webfont.ttf',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ܲlr9�P&iA�p��');
INSERT INTO `wp_wfFileMods` VALUES ('?ζQ�ք��9�>�\0','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/fonts/fontawesome-webfont.woff',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','2�an�����%��\nP�');
INSERT INTO `wp_wfFileMods` VALUES ('Cv�������v���x','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/less/bordered-pulled.less',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','[?>S�z���Y��!K');
INSERT INTO `wp_wfFileMods` VALUES ('u�q��T[�y}�#��','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/less/core.less',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�B]���\rC��y�u�h');
INSERT INTO `wp_wfFileMods` VALUES ('�����j����It��','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/less/fixed-width.less',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','^�\0�!�\'��T(�');
INSERT INTO `wp_wfFileMods` VALUES ('�	Vx����/]���','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/less/font-awesome.less',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','B��,ǧ���\'��u');
INSERT INTO `wp_wfFileMods` VALUES ('Z���M���|Tn�I�','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/less/icons.less',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�� `%9�a��x%6�');
INSERT INTO `wp_wfFileMods` VALUES ('����u�fއvC��H�','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/less/larger.less',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��R������&&�\Z|�(');
INSERT INTO `wp_wfFileMods` VALUES ('�	��\0�U7a��IU','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/less/list.less',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',')��~�ar�8�w��');
INSERT INTO `wp_wfFileMods` VALUES ('���V�z�U�y&uQډ','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/less/mixins.less',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�gQf�\Z�\r�m�|\n�N');
INSERT INTO `wp_wfFileMods` VALUES ('BpC���p��#�C9�#�','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/less/path.less',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��P;h!��6�BD[�&�');
INSERT INTO `wp_wfFileMods` VALUES ('e�%��GA�	��ٶ/6�','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/less/rotated-flipped.less',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','	��q��� �zI�k��');
INSERT INTO `wp_wfFileMods` VALUES ('��$a�k�68\r��H�','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/less/spinning.less',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�-m��/��h?�y�');
INSERT INTO `wp_wfFileMods` VALUES ('m�\0����ᐁ�ҭ��','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/less/stacked.less',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Q�+-&9��ʡ�QKKN�');
INSERT INTO `wp_wfFileMods` VALUES ('�~��K_X���Y','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/less/variables.less',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�T�~B���ziM:��');
INSERT INTO `wp_wfFileMods` VALUES ('uG9A�\n�@�r�z��','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/scss/_bordered-pulled.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��Tr���#�s���q');
INSERT INTO `wp_wfFileMods` VALUES ('���6.��\Z������','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/scss/_core.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','F9s�$�bٕx7��N\"');
INSERT INTO `wp_wfFileMods` VALUES ('=�GQE����x\\_\"','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/scss/_fixed-width.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�w�id�4ԙ�6���');
INSERT INTO `wp_wfFileMods` VALUES ('���- �bS?S?��\"�!','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/scss/_icons.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','iS��Q<��G��+\'');
INSERT INTO `wp_wfFileMods` VALUES ('�g�}����t���\n','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/scss/_larger.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Y1VooƭV�����');
INSERT INTO `wp_wfFileMods` VALUES ('t����2�!�E���;_f','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/scss/_list.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','q�9(\'_�B-�');
INSERT INTO `wp_wfFileMods` VALUES ('����֌)H�Qe�','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/scss/_mixins.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����s�&�}����C*');
INSERT INTO `wp_wfFileMods` VALUES ('\"���4��e蓤0�V','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/scss/_path.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�*��h���(\'&��%\0');
INSERT INTO `wp_wfFileMods` VALUES ('�~f$߮����2�09��','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/scss/_rotated-flipped.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��B����e��Z���]');
INSERT INTO `wp_wfFileMods` VALUES ('��W�Y@�-x���&,�','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/scss/_spinning.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ly��:��jf�VX*');
INSERT INTO `wp_wfFileMods` VALUES ('�]�~,�g]%�a\r5Č','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/scss/_stacked.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','U�#r&�߼��F�');
INSERT INTO `wp_wfFileMods` VALUES ('���5�PUUbݿ��','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/scss/_variables.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�O#���i\n�@�BU[');
INSERT INTO `wp_wfFileMods` VALUES ('��68��f�T��4Z��','wp-content/plugins/dw-question-answer/inc/templates/default/assets/font/font-awesome/scss/font-awesome.scss',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','B��,ǧ���\'��u');
INSERT INTO `wp_wfFileMods` VALUES ('Qm���bp;�棜D','wp-content/plugins/dw-question-answer/inc/templates/default/assets/img/draft.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','pb�r�\n��[\0�W�');
INSERT INTO `wp_wfFileMods` VALUES ('�����\"�H\'�����','wp-content/plugins/dw-question-answer/inc/templates/default/assets/img/facebook-loading.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','H�xF�������ϒe�');
INSERT INTO `wp_wfFileMods` VALUES ('�:�f���a&S�6Ȋ','wp-content/plugins/dw-question-answer/inc/templates/default/assets/img/icon-code.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����h�B �z�d');
INSERT INTO `wp_wfFileMods` VALUES ('���������$�)g','wp-content/plugins/dw-question-answer/inc/templates/default/assets/img/loading.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�V�\Z�2�r�)�g�+');
INSERT INTO `wp_wfFileMods` VALUES ('Rz��-p��I��;�v.�','wp-content/plugins/dw-question-answer/inc/templates/default/assets/js/bootstrap-dropdown.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','sg��L�-����CO�{');
INSERT INTO `wp_wfFileMods` VALUES ('_ޱ�q�+�@U�9/','wp-content/plugins/dw-question-answer/inc/templates/default/assets/js/dwqa-questions-list.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Zl�r��H���Y�Ķ');
INSERT INTO `wp_wfFileMods` VALUES ('+|�j��/yL����','wp-content/plugins/dw-question-answer/inc/templates/default/assets/js/dwqa-single-question.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','>ᚵ*B6G{ ����N');
INSERT INTO `wp_wfFileMods` VALUES ('!;YN��b�=�� ','wp-content/plugins/dw-question-answer/inc/templates/default/assets/js/dwqa-submit-question.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�KC�7�\'9����K�');
INSERT INTO `wp_wfFileMods` VALUES ('��ݧ���ψ���GNr','wp-content/plugins/dw-question-answer/inc/templates/default/assets/js/prettify.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ֵ�]盪��4\\�[F\\');
INSERT INTO `wp_wfFileMods` VALUES ('�������[���<','wp-content/plugins/dw-question-answer/inc/templates/default/assets/less/button-groups.less',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��R1��[t��r��');
INSERT INTO `wp_wfFileMods` VALUES ('��J˫�͈f��[n�','wp-content/plugins/dw-question-answer/inc/templates/default/assets/less/buttons.less',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��Q���V΍ĤD{�<');
INSERT INTO `wp_wfFileMods` VALUES ('9:��+�蝰\r�?�v','wp-content/plugins/dw-question-answer/inc/templates/default/assets/less/dropdowns.less',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�A2A�H�مy��K��');
INSERT INTO `wp_wfFileMods` VALUES ('K� g[0� �b�(�','wp-content/plugins/dw-question-answer/inc/templates/default/assets/less/mixins.less',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�8�����O8����');
INSERT INTO `wp_wfFileMods` VALUES ('�m ia�#(������','wp-content/plugins/dw-question-answer/inc/templates/default/assets/less/style.less',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','w��C�7��&6Q�2�#.');
INSERT INTO `wp_wfFileMods` VALUES ('�$���ZU*!��㞫','wp-content/plugins/dw-question-answer/inc/templates/default/assets/less/variables.less',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�g��������=�');
INSERT INTO `wp_wfFileMods` VALUES ('\"	��:�W�q%���','wp-content/plugins/dw-question-answer/inc/templates/default/comments.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Q���꽀%��e��)');
INSERT INTO `wp_wfFileMods` VALUES ('OQ(@��g�HQ�|\r','wp-content/plugins/dw-question-answer/inc/templates/default/content-answer.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','L]�@K�a?�����');
INSERT INTO `wp_wfFileMods` VALUES ('�[�D��l���\r\"{','wp-content/plugins/dw-question-answer/inc/templates/default/content-comment.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Kx\r�$oT����E�');
INSERT INTO `wp_wfFileMods` VALUES (']�1(��y��I��b�g','wp-content/plugins/dw-question-answer/inc/templates/default/content-question.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��5e�����YX��');
INSERT INTO `wp_wfFileMods` VALUES ('�)0s�Q���$�','wp-content/plugins/dw-question-answer/inc/templates/default/navigation-archive.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','L�\'7i����!\0�	u�');
INSERT INTO `wp_wfFileMods` VALUES ('(Υׇ��|p��]��','wp-content/plugins/dw-question-answer/inc/templates/default/question-list.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','a�7�����X��)��');
INSERT INTO `wp_wfFileMods` VALUES ('��l�%�W�W��F�','wp-content/plugins/dw-question-answer/inc/templates/default/question-submit-form.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','nd���:�k����T��');
INSERT INTO `wp_wfFileMods` VALUES ('�0`\0ƥ�,G�ǇFߪ�','wp-content/plugins/dw-question-answer/inc/templates/default/question-submit-success.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�K�\'��(�����');
INSERT INTO `wp_wfFileMods` VALUES ('�M�K$����U��j��','wp-content/plugins/dw-question-answer/inc/templates/default/question-submit.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��׸��[�&6}]�');
INSERT INTO `wp_wfFileMods` VALUES ('��X#�؈9���]���','wp-content/plugins/dw-question-answer/inc/templates/default/search-question.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','u��]\Z>^C����\"');
INSERT INTO `wp_wfFileMods` VALUES ('r^\'�lV�r�\0�F?\r�','wp-content/plugins/dw-question-answer/inc/templates/default/single-question.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','&c����\r�(݆\n���');
INSERT INTO `wp_wfFileMods` VALUES ('h����vg�{�<���t','wp-content/plugins/dw-question-answer/inc/templates/email/new-answer-followers.html',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�􉐻G��@�S�_˞�');
INSERT INTO `wp_wfFileMods` VALUES ('XqӾ�	�;�D�����','wp-content/plugins/dw-question-answer/inc/templates/email/new-answer.html',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���,��~�b��$O�');
INSERT INTO `wp_wfFileMods` VALUES ('���L.����B,.','wp-content/plugins/dw-question-answer/inc/templates/email/new-comment-answer-followers.html',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�U#���Kn�]Y�p��');
INSERT INTO `wp_wfFileMods` VALUES ('��\0�e�}[H�F�C','wp-content/plugins/dw-question-answer/inc/templates/email/new-comment-answer.html',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�{��Wa]�~�S��R�y');
INSERT INTO `wp_wfFileMods` VALUES ('�>ٝ��|�������','wp-content/plugins/dw-question-answer/inc/templates/email/new-comment-question-followers.html',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�|�87�\"ά#�/M�');
INSERT INTO `wp_wfFileMods` VALUES ('�g�]\no�y(�q���\r','wp-content/plugins/dw-question-answer/inc/templates/email/new-comment-question.html',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','G���g�`9}ա�');
INSERT INTO `wp_wfFileMods` VALUES ('.���	Yw4\Zڹ$Q','wp-content/plugins/dw-question-answer/inc/templates/email/new-question.html',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ے�H�F<�=�\Z^c}');
INSERT INTO `wp_wfFileMods` VALUES ('�DʛIa�i_�VV','wp-content/plugins/dw-question-answer/inc/widgets/latest-question.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��]M�gah^���');
INSERT INTO `wp_wfFileMods` VALUES ('`��������ɺ\\','wp-content/plugins/dw-question-answer/inc/widgets/list-closed-question.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','[��jOQP�-N��');
INSERT INTO `wp_wfFileMods` VALUES ('?*Q������n����','wp-content/plugins/dw-question-answer/inc/widgets/popular-question.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Gy���J�%ا��');
INSERT INTO `wp_wfFileMods` VALUES ('&��H��,��8g&P�','wp-content/plugins/dw-question-answer/inc/widgets/related-question.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','a��d9\'4�r~O����');
INSERT INTO `wp_wfFileMods` VALUES ('@�����H��@�����','wp-content/plugins/dw-question-answer/languages/default.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��U��[�\'w\nݱ�h�');
INSERT INTO `wp_wfFileMods` VALUES ('i�����\'|����p�G','wp-content/plugins/dw-question-answer/languages/default.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���׵Ǌ�\\���j');
INSERT INTO `wp_wfFileMods` VALUES ('6���鮾��|�\"','wp-content/plugins/dw-question-answer/languages/dwqa-ar.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',' � �N9mtK��Z1�');
INSERT INTO `wp_wfFileMods` VALUES ('��`���{K�f����','wp-content/plugins/dw-question-answer/languages/dwqa-ar.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�`�9[��#��|���');
INSERT INTO `wp_wfFileMods` VALUES ('0�|���i��$f�Ml','wp-content/plugins/dw-question-answer/languages/dwqa-ca.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�̟>�z��v�$��');
INSERT INTO `wp_wfFileMods` VALUES ('�w��M6��`�2�܋','wp-content/plugins/dw-question-answer/languages/dwqa-ca.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','P׺-��W��k�wc�?');
INSERT INTO `wp_wfFileMods` VALUES ('�ک��X���X���k','wp-content/plugins/dw-question-answer/languages/dwqa-cs_CZ.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�݋q@�%\r���l��');
INSERT INTO `wp_wfFileMods` VALUES ('��,�n����[���ONY','wp-content/plugins/dw-question-answer/languages/dwqa-cs_CZ.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ag��*�0�f4�');
INSERT INTO `wp_wfFileMods` VALUES ('@+����^[p.��','wp-content/plugins/dw-question-answer/languages/dwqa-de_DE.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','/��`�\Z���Vr��oM�');
INSERT INTO `wp_wfFileMods` VALUES ('���!��,�C����-','wp-content/plugins/dw-question-answer/languages/dwqa-de_DE.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',' �	���x��C�m\r�');
INSERT INTO `wp_wfFileMods` VALUES ('#7�t4����0�]�Z','wp-content/plugins/dw-question-answer/languages/dwqa-es_ES.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Bq3GS�VėE��');
INSERT INTO `wp_wfFileMods` VALUES ('�&��{��B\Z��ND�','wp-content/plugins/dw-question-answer/languages/dwqa-es_ES.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�7��\Z�f��df:��\r');
INSERT INTO `wp_wfFileMods` VALUES ('A͊�ҐP�7a[��}','wp-content/plugins/dw-question-answer/languages/dwqa-fa_IR.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�4��\ZN�\r+�Éw��');
INSERT INTO `wp_wfFileMods` VALUES ('/9T�+�[G��ް�','wp-content/plugins/dw-question-answer/languages/dwqa-fa_IR.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���O�F��t�3n�p');
INSERT INTO `wp_wfFileMods` VALUES ('�@p�>�.�w����','wp-content/plugins/dw-question-answer/languages/dwqa-fr_FR.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���ja�-@���f��p�');
INSERT INTO `wp_wfFileMods` VALUES ('���)����Bi�̢D4�','wp-content/plugins/dw-question-answer/languages/dwqa-fr_FR.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�kR��5\\�o��');
INSERT INTO `wp_wfFileMods` VALUES ('�3���XA2��\'�','wp-content/plugins/dw-question-answer/languages/dwqa-hi_IN.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','X�ht@����i<�');
INSERT INTO `wp_wfFileMods` VALUES ('�#K�e���p��M�i','wp-content/plugins/dw-question-answer/languages/dwqa-hi_IN.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','b�g���N�C�/G{ǵb');
INSERT INTO `wp_wfFileMods` VALUES ('N�vvRG�8��G�\r;`','wp-content/plugins/dw-question-answer/languages/dwqa-hr.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','g�w��V���j�-y�_');
INSERT INTO `wp_wfFileMods` VALUES ('��嶆�?co,_,�FX','wp-content/plugins/dw-question-answer/languages/dwqa-hr.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���k�W�ڴ6�k*ԥ');
INSERT INTO `wp_wfFileMods` VALUES ('N/�!��&C�>�@]','wp-content/plugins/dw-question-answer/languages/dwqa-id_ID.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','v���p�拆( �4��');
INSERT INTO `wp_wfFileMods` VALUES ('�0J����_�cV�tb�','wp-content/plugins/dw-question-answer/languages/dwqa-id_ID.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','d�}���u��ݐ�\nL');
INSERT INTO `wp_wfFileMods` VALUES ('H:6W7��z��q�0�','wp-content/plugins/dw-question-answer/languages/dwqa-it_IT.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�l\"�b���3�k��');
INSERT INTO `wp_wfFileMods` VALUES ('���� �GX�����(','wp-content/plugins/dw-question-answer/languages/dwqa-it_IT.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���{�w��rM3�');
INSERT INTO `wp_wfFileMods` VALUES ('߾��/���y\n�5��X','wp-content/plugins/dw-question-answer/languages/dwqa-ko_KR.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\r���v�����,� &�');
INSERT INTO `wp_wfFileMods` VALUES ('���jtGh��FC,r�','wp-content/plugins/dw-question-answer/languages/dwqa-ko_KR.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','[���F�y��֑��ұ�');
INSERT INTO `wp_wfFileMods` VALUES ('�ڎ3�<��|IR����','wp-content/plugins/dw-question-answer/languages/dwqa-pl_PL.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',';|�y]�N����n�)');
INSERT INTO `wp_wfFileMods` VALUES ('!C�T�DC�|*��','wp-content/plugins/dw-question-answer/languages/dwqa-pl_PL.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ΦobĀ6��B3׎�F�');
INSERT INTO `wp_wfFileMods` VALUES ('�bB/F�����v�!/','wp-content/plugins/dw-question-answer/languages/dwqa-pt_BR.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�.��j+H(*�4��');
INSERT INTO `wp_wfFileMods` VALUES ('��%+�S8�	j�','wp-content/plugins/dw-question-answer/languages/dwqa-pt_BR.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','a�S�g��m�IA]Rݐ');
INSERT INTO `wp_wfFileMods` VALUES ('�GI��j��x��gh+f','wp-content/plugins/dw-question-answer/languages/dwqa-ro_RO.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�>��:�;���8�L)�');
INSERT INTO `wp_wfFileMods` VALUES ('���d��6u�IT����','wp-content/plugins/dw-question-answer/languages/dwqa-ro_RO.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ԇ+�U)-F���m�');
INSERT INTO `wp_wfFileMods` VALUES ('~��g��\"�*k�g��e','wp-content/plugins/dw-question-answer/languages/dwqa-ru_RU.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','s��a(��υ?e�');
INSERT INTO `wp_wfFileMods` VALUES ('8*���\n����ӶYS�','wp-content/plugins/dw-question-answer/languages/dwqa-ru_RU.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�⫲uN���_�����');
INSERT INTO `wp_wfFileMods` VALUES ('�?��M�)�lˉqM,','wp-content/plugins/dw-question-answer/languages/dwqa-sk_SK.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','R�v�bt��TQ\'�ͼ');
INSERT INTO `wp_wfFileMods` VALUES ('\'�∳ܐi�Be�ӄ','wp-content/plugins/dw-question-answer/languages/dwqa-sk_SK.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','c�&A�%(I��\\�B9\nE');
INSERT INTO `wp_wfFileMods` VALUES ('G�0i�%J���0�-!�','wp-content/plugins/dw-question-answer/languages/dwqa-sv_SE.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�X�L���c���>�&�');
INSERT INTO `wp_wfFileMods` VALUES ('���J�5�g��p�H�','wp-content/plugins/dw-question-answer/languages/dwqa-sv_SE.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�G����%!��ݭ{%o');
INSERT INTO `wp_wfFileMods` VALUES ('f��$P��;�r;�\n','wp-content/plugins/dw-question-answer/languages/dwqa-th.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ϝ�{�Ey*S����=');
INSERT INTO `wp_wfFileMods` VALUES ('B ���E+��xV	�','wp-content/plugins/dw-question-answer/languages/dwqa-th.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','K*�3�(�_��<�X');
INSERT INTO `wp_wfFileMods` VALUES ('\\9t%G0���\'�G�','wp-content/plugins/dw-question-answer/languages/dwqa-th_TH.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���H6���]�');
INSERT INTO `wp_wfFileMods` VALUES ('�a�L����L�E̘XY','wp-content/plugins/dw-question-answer/languages/dwqa-th_TH.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Z���Z��$�G/)��');
INSERT INTO `wp_wfFileMods` VALUES ('p���1eCv�l�;','wp-content/plugins/dw-question-answer/languages/dwqa-tr_TR.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\'҄;��&2��(���');
INSERT INTO `wp_wfFileMods` VALUES ('�QPǛq������B�','wp-content/plugins/dw-question-answer/languages/dwqa-tr_TR.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','L���_����u�S��');
INSERT INTO `wp_wfFileMods` VALUES ('?I\\(+��H�]ef�','wp-content/plugins/dw-question-answer/languages/dwqa-vi.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','bŁB�,���3V\rJ�Y�');
INSERT INTO `wp_wfFileMods` VALUES ('�2�j��,�9#��P','wp-content/plugins/dw-question-answer/languages/dwqa-vi.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�:\rA#�EmR��%��');
INSERT INTO `wp_wfFileMods` VALUES ('���Yȧ���(g�j8','wp-content/plugins/dw-question-answer/languages/dwqa-zh_CN.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','M�����6zE�9�');
INSERT INTO `wp_wfFileMods` VALUES ('�~�y�\"�<9:�ޙ�','wp-content/plugins/dw-question-answer/languages/dwqa-zh_CN.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\'��V��n��r$�E�');
INSERT INTO `wp_wfFileMods` VALUES ('�mY\',�g�@�M~�z','wp-content/plugins/dw-question-answer/phpunit.xml',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�d��5����]��y��');
INSERT INTO `wp_wfFileMods` VALUES ('�� �M��Ov��r','wp-content/plugins/dw-question-answer/readme.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Ъ{I�V&��{��%');
INSERT INTO `wp_wfFileMods` VALUES ('�o��\'�#x�{	��t�','wp-content/plugins/dw-question-answer/screenshot-1.jpg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��x��ku�Z���\rm');
INSERT INTO `wp_wfFileMods` VALUES ('��Т%��a?�;�3� ','wp-content/plugins/dw-question-answer/screenshot-2.jpg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�@�e��|2=�P�*');
INSERT INTO `wp_wfFileMods` VALUES ('C݄*$qO!n�F�Y','wp-content/plugins/dw-question-answer/screenshot-3.jpg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�&E����\Z>@�_');
INSERT INTO `wp_wfFileMods` VALUES ('��4b\n��9<�C⫶��','wp-content/plugins/dw-question-answer/screenshot-4.jpg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','B����}j}�g�A�QP');
INSERT INTO `wp_wfFileMods` VALUES ('����F�m��E���','wp-content/plugins/dw-question-answer/screenshot-5.jpg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','	\Z/|�Z62\"��2(Nj');
INSERT INTO `wp_wfFileMods` VALUES ('Q��.\nb��r{xҫ�','wp-content/plugins/dw-question-answer/tests/README.md',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��b�*!�Ӡ�<�C');
INSERT INTO `wp_wfFileMods` VALUES ('�Q�f&ʢ�\\6a��','wp-content/plugins/dw-question-answer/tests/bootstrap.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','L\r�!�V=w����');
INSERT INTO `wp_wfFileMods` VALUES ('kf���#�����\\G','wp-content/plugins/dw-question-answer/tests/index.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��{J!u?}��s�');
INSERT INTO `wp_wfFileMods` VALUES ('>�za�U=ӏAP�`','wp-content/plugins/dw-question-answer/tests/test-unit-tests.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','s�k�5�ex.Ȋk��\Z');
INSERT INTO `wp_wfFileMods` VALUES ('������0*�W��','wp-content/plugins/index.php',0,'gD,V�=\\�bP','gD,V�=\\�bP');
INSERT INTO `wp_wfFileMods` VALUES ('�S�P�\'�Ff�ʥ3','wp-content/plugins/iq-block-country/chosen-sprite.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','%�����\\k��9��1~');
INSERT INTO `wp_wfFileMods` VALUES ('ܷ��*����2��#��','wp-content/plugins/iq-block-country/chosen-sprite@2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\r	�;��ʶ��G����');
INSERT INTO `wp_wfFileMods` VALUES ('�uz���8�(n�TP_U','wp-content/plugins/iq-block-country/chosen.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ᝀy�O)В��sN0��');
INSERT INTO `wp_wfFileMods` VALUES ('��/T�}94r&p;��C','wp-content/plugins/iq-block-country/chosen.jquery.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�R��ׅu$�2��');
INSERT INTO `wp_wfFileMods` VALUES ('r��Wj�E���<A','wp-content/plugins/iq-block-country/icons/ad.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�uD!Z� ��\\�+\r');
INSERT INTO `wp_wfFileMods` VALUES ('}�M����~JNƘ�','wp-content/plugins/iq-block-country/icons/ae.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','s���{Q��*Zm{�');
INSERT INTO `wp_wfFileMods` VALUES ('N6��^\0A�\\�%fj','wp-content/plugins/iq-block-country/icons/af.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�|X\'*�lޔ\\�K�\0��');
INSERT INTO `wp_wfFileMods` VALUES ('ރ��m�_�|�\0���*','wp-content/plugins/iq-block-country/icons/ag.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','9\n��mF+�&\'�)F�Z');
INSERT INTO `wp_wfFileMods` VALUES ('a�3���\n{3jr+m�','wp-content/plugins/iq-block-country/icons/ai.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����q\0bi�s\0�');
INSERT INTO `wp_wfFileMods` VALUES ('�G4V3���U��C�lR','wp-content/plugins/iq-block-country/icons/al.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','|[� ��0G���\0�q��');
INSERT INTO `wp_wfFileMods` VALUES ('$��\n���	��:�T�','wp-content/plugins/iq-block-country/icons/am.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�]��N�d��^�c/');
INSERT INTO `wp_wfFileMods` VALUES ('\\��F���U�0Q�','wp-content/plugins/iq-block-country/icons/an.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','}}h*���jm�ۇ3O');
INSERT INTO `wp_wfFileMods` VALUES ('}��zQ3C��;�H7�&','wp-content/plugins/iq-block-country/icons/ao.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','A���m$�٧wh');
INSERT INTO `wp_wfFileMods` VALUES ('߀I0���p΃dW�;','wp-content/plugins/iq-block-country/icons/ar.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','/�W��f����#�E�');
INSERT INTO `wp_wfFileMods` VALUES ('��B	@*w���\'����}','wp-content/plugins/iq-block-country/icons/as.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���X\'{g XLM�N�');
INSERT INTO `wp_wfFileMods` VALUES ('US5g$�+�h��N�T','wp-content/plugins/iq-block-country/icons/at.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','b�\ZVSi+4��sJY�b');
INSERT INTO `wp_wfFileMods` VALUES ('c���{����XF�ݽ','wp-content/plugins/iq-block-country/icons/au.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','/�IȈ�����G\\���');
INSERT INTO `wp_wfFileMods` VALUES ('Wv�c4n�e�G��9�-','wp-content/plugins/iq-block-country/icons/aw.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','n�\'��G4_���>5');
INSERT INTO `wp_wfFileMods` VALUES ('�K�%e�	9��=�','wp-content/plugins/iq-block-country/icons/ax.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\'p�x��%�u�<0?���');
INSERT INTO `wp_wfFileMods` VALUES ('���ǯQO�[yQu�','wp-content/plugins/iq-block-country/icons/az.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�?\\��^ʝ�c8�');
INSERT INTO `wp_wfFileMods` VALUES ('�!��:(4�S�s','wp-content/plugins/iq-block-country/icons/ba.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','˶�Fƞ������h\r3');
INSERT INTO `wp_wfFileMods` VALUES ('��9�a!��O+.��','wp-content/plugins/iq-block-country/icons/bb.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','GȮ�f_N�Zzs��');
INSERT INTO `wp_wfFileMods` VALUES ('���2��s�����','wp-content/plugins/iq-block-country/icons/bd.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�-���q�$fF�\'��');
INSERT INTO `wp_wfFileMods` VALUES ('w��B��� AԷ\Z�','wp-content/plugins/iq-block-country/icons/be.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','$������R�����');
INSERT INTO `wp_wfFileMods` VALUES ('���Iimer�PCP��K','wp-content/plugins/iq-block-country/icons/bf.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�e�L�6y3��! K-');
INSERT INTO `wp_wfFileMods` VALUES ('�&$��M��7~�*A','wp-content/plugins/iq-block-country/icons/bg.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','w�:��n����+�!');
INSERT INTO `wp_wfFileMods` VALUES ('d���3�����','wp-content/plugins/iq-block-country/icons/bh.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','[�a��%�$��ٛA�');
INSERT INTO `wp_wfFileMods` VALUES ('W��6\'#!��^JM%','wp-content/plugins/iq-block-country/icons/bi.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','B|r�4(��b�5�Ǻ');
INSERT INTO `wp_wfFileMods` VALUES ('��̧��[ �}�L','wp-content/plugins/iq-block-country/icons/bj.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','g�.����[��!�8�');
INSERT INTO `wp_wfFileMods` VALUES ('��=�݋\rIx-T�','wp-content/plugins/iq-block-country/icons/bm.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�[�Y ,�����q�');
INSERT INTO `wp_wfFileMods` VALUES ('\'Ϙ�6H�=�g�t','wp-content/plugins/iq-block-country/icons/bn.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','I�*��H�/��$��<');
INSERT INTO `wp_wfFileMods` VALUES ('W�jߋ�X��0X�','wp-content/plugins/iq-block-country/icons/bo.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','T�a�zD�J7��s�c');
INSERT INTO `wp_wfFileMods` VALUES ('���6�[����','wp-content/plugins/iq-block-country/icons/br.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','T�����G�њ���');
INSERT INTO `wp_wfFileMods` VALUES ('bu�;�Б�K�\r�f�','wp-content/plugins/iq-block-country/icons/bs.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�E�L�@�$Hi!��*��');
INSERT INTO `wp_wfFileMods` VALUES ('e��\'d�[i�,2|�^','wp-content/plugins/iq-block-country/icons/bt.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','/�|h�;G��7�');
INSERT INTO `wp_wfFileMods` VALUES ('s�b�\"f��I@�P�\0,�','wp-content/plugins/iq-block-country/icons/bv.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','U�庮�sۍ�P�lb');
INSERT INTO `wp_wfFileMods` VALUES ('��2]13Z.Ƕo{��#','wp-content/plugins/iq-block-country/icons/bw.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Ւp�%��gէ0h,VD');
INSERT INTO `wp_wfFileMods` VALUES ('�zkN\0��{�ј�hx�','wp-content/plugins/iq-block-country/icons/by.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��FLI����\Z�W�');
INSERT INTO `wp_wfFileMods` VALUES ('\Z�b��M\'��\"^t_/�','wp-content/plugins/iq-block-country/icons/bz.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','n���2�6t	AUE�~s');
INSERT INTO `wp_wfFileMods` VALUES ('�7�]I�?�2�n�','wp-content/plugins/iq-block-country/icons/ca.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�p�E�����T��)�');
INSERT INTO `wp_wfFileMods` VALUES ('�b�F*��PL�[�','wp-content/plugins/iq-block-country/icons/catalonia.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','v�=����`?�o�$');
INSERT INTO `wp_wfFileMods` VALUES ('�6����j\r|􀫌9�\r','wp-content/plugins/iq-block-country/icons/cc.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','뿱�y�R��˱,�\n#');
INSERT INTO `wp_wfFileMods` VALUES ('x��4\n0%�@NM','wp-content/plugins/iq-block-country/icons/cd.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','4�*���s�A;\rE');
INSERT INTO `wp_wfFileMods` VALUES (']���(���3��V','wp-content/plugins/iq-block-country/icons/cf.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','%-_LG7J>»��');
INSERT INTO `wp_wfFileMods` VALUES ('|�����[��������','wp-content/plugins/iq-block-country/icons/cg.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����Zr�V��U�CY');
INSERT INTO `wp_wfFileMods` VALUES ('����H�e���Y0d','wp-content/plugins/iq-block-country/icons/ch.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�{�vq��+<�J][');
INSERT INTO `wp_wfFileMods` VALUES ('T�	�\\JR�b����i','wp-content/plugins/iq-block-country/icons/ci.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���,!Qv��E;���C');
INSERT INTO `wp_wfFileMods` VALUES ('*��A�TuomP��Q�','wp-content/plugins/iq-block-country/icons/ck.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�	([r�.��nᄞ@�');
INSERT INTO `wp_wfFileMods` VALUES ('�5G���|f�s[)�','wp-content/plugins/iq-block-country/icons/cl.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�{;�x��EM�[y��');
INSERT INTO `wp_wfFileMods` VALUES ('�y��Cj��S��v�','wp-content/plugins/iq-block-country/icons/cm.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���e�6��2p|B��J');
INSERT INTO `wp_wfFileMods` VALUES ('A��(�ؗSE�7�ٗ','wp-content/plugins/iq-block-country/icons/cn.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�/�9��@b2�Dt�=�');
INSERT INTO `wp_wfFileMods` VALUES ('I�Y\'��;H��d��','wp-content/plugins/iq-block-country/icons/co.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','K�#�����h&�elS3');
INSERT INTO `wp_wfFileMods` VALUES ('�q�O��{��9MKS(','wp-content/plugins/iq-block-country/icons/cr.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�(��蟢�D�vB�_�');
INSERT INTO `wp_wfFileMods` VALUES ('��K��r��~!�a�hΐ','wp-content/plugins/iq-block-country/icons/cs.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','M�~�D�B����7h�X');
INSERT INTO `wp_wfFileMods` VALUES ('%2��	i�ؕ������','wp-content/plugins/iq-block-country/icons/cu.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Sf�\\�(B�`�3��');
INSERT INTO `wp_wfFileMods` VALUES ('�^�rڗ!������','wp-content/plugins/iq-block-country/icons/cv.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','/N�ܺL�?�z#_2�');
INSERT INTO `wp_wfFileMods` VALUES ('mx�`�����{2xv�','wp-content/plugins/iq-block-country/icons/cx.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��U�K�G�� �Q/');
INSERT INTO `wp_wfFileMods` VALUES ('űA#0&�����M��','wp-content/plugins/iq-block-country/icons/cy.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�A�\"�u�������');
INSERT INTO `wp_wfFileMods` VALUES ('~+KO0\\�mB�B','wp-content/plugins/iq-block-country/icons/cz.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�[m+�\n1y�e/h���');
INSERT INTO `wp_wfFileMods` VALUES ('��҄�����^�ʁ��^','wp-content/plugins/iq-block-country/icons/de.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ݫ�h~����뀍DC�');
INSERT INTO `wp_wfFileMods` VALUES ('�Ie�)-�d�@z�R','wp-content/plugins/iq-block-country/icons/dj.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','~o�W���s9=�A�');
INSERT INTO `wp_wfFileMods` VALUES ('6Y�\"w��S�>ôU��l','wp-content/plugins/iq-block-country/icons/dk.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��l�q�_����\nA��');
INSERT INTO `wp_wfFileMods` VALUES ('�����\rIy�$�	i','wp-content/plugins/iq-block-country/icons/dm.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��]��(�O(���Q]�');
INSERT INTO `wp_wfFileMods` VALUES ('Κ@D8i�ɣ�v=�I��','wp-content/plugins/iq-block-country/icons/do.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','9IXE�:Lw�=�');
INSERT INTO `wp_wfFileMods` VALUES ('�G�H���ޒƜd\\�|','wp-content/plugins/iq-block-country/icons/dz.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�<	Q�%�5����ֱ');
INSERT INTO `wp_wfFileMods` VALUES ('q�N�u�ԗ޸M��H','wp-content/plugins/iq-block-country/icons/ec.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','RD!⁑=�l�');
INSERT INTO `wp_wfFileMods` VALUES ('�y:\"2)�\Zq?�w޲�','wp-content/plugins/iq-block-country/icons/ee.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ߪ��p��F3��:�');
INSERT INTO `wp_wfFileMods` VALUES ('��{ȔIH��>�N�\r�','wp-content/plugins/iq-block-country/icons/eg.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','	č5b��Q��Pw�C');
INSERT INTO `wp_wfFileMods` VALUES ('/T �hu<���i�R��','wp-content/plugins/iq-block-country/icons/eh.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','}դj4���2�!:�{');
INSERT INTO `wp_wfFileMods` VALUES ('X�-�������J���','wp-content/plugins/iq-block-country/icons/england.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','s�� ��$�E�M�ڑ');
INSERT INTO `wp_wfFileMods` VALUES ('����fl�~\"�����w','wp-content/plugins/iq-block-country/icons/er.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','H9JɤO0@��W�#�');
INSERT INTO `wp_wfFileMods` VALUES ('�Ae<P���~�ڦt0','wp-content/plugins/iq-block-country/icons/es.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�i<�4k-����5UN\n');
INSERT INTO `wp_wfFileMods` VALUES ('�n��e�H��tB3<�;�','wp-content/plugins/iq-block-country/icons/et.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','sv>Fډo>�T�G;JK');
INSERT INTO `wp_wfFileMods` VALUES ('�tl�8�\0l�/\\��v;\n','wp-content/plugins/iq-block-country/icons/eu.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��^d�M6z ��@3�W');
INSERT INTO `wp_wfFileMods` VALUES ('[����Ȇ�ĉ�{�u�\"','wp-content/plugins/iq-block-country/icons/fam.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','6�!w,����hx�R1');
INSERT INTO `wp_wfFileMods` VALUES ('����E�-��oc91��','wp-content/plugins/iq-block-country/icons/fi.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��I=猙�\Z��- k');
INSERT INTO `wp_wfFileMods` VALUES (']���ڌ��\r�._��~�','wp-content/plugins/iq-block-country/icons/fj.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','|>x��K��es�6');
INSERT INTO `wp_wfFileMods` VALUES ('\r8��A����w�VSO','wp-content/plugins/iq-block-country/icons/fk.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\'1�u~��m��訇');
INSERT INTO `wp_wfFileMods` VALUES ('���>b�w6c%_\'r�','wp-content/plugins/iq-block-country/icons/fm.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�v~�TfW��c�V�T');
INSERT INTO `wp_wfFileMods` VALUES ('��\"�GDïMD��\r��','wp-content/plugins/iq-block-country/icons/fo.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�氣���\'[PW���f');
INSERT INTO `wp_wfFileMods` VALUES (':��<��B+&�7ad�','wp-content/plugins/iq-block-country/icons/fr.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��t�0^VcTzH��-�');
INSERT INTO `wp_wfFileMods` VALUES ('�->)^�.st�1�','wp-content/plugins/iq-block-country/icons/ga.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�-�Kޡ5�i��}��');
INSERT INTO `wp_wfFileMods` VALUES ('��V�N:�n%6','wp-content/plugins/iq-block-country/icons/gb.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����0��s>���');
INSERT INTO `wp_wfFileMods` VALUES ('�\nz2X�,<\n�򍫂K','wp-content/plugins/iq-block-country/icons/gd.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�����ƱQ	x�{�{F');
INSERT INTO `wp_wfFileMods` VALUES ('����%gSS�t�$\"�-','wp-content/plugins/iq-block-country/icons/ge.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�@rz�l��fjd7g');
INSERT INTO `wp_wfFileMods` VALUES ('	X=�\0\Z��Pڜ&�4��','wp-content/plugins/iq-block-country/icons/gf.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��t�0^VcTzH��-�');
INSERT INTO `wp_wfFileMods` VALUES ('�ڕY�Դ���0�(','wp-content/plugins/iq-block-country/icons/gh.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','څrM��w�r�ۍ�q');
INSERT INTO `wp_wfFileMods` VALUES ('�DS�\r���#=K ]','wp-content/plugins/iq-block-country/icons/gi.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���*��\\�w����');
INSERT INTO `wp_wfFileMods` VALUES ('7�����L[��{�)','wp-content/plugins/iq-block-country/icons/gl.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',';k�n��qE�݉��}');
INSERT INTO `wp_wfFileMods` VALUES ('��,�����d��Q���','wp-content/plugins/iq-block-country/icons/gm.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ׅ�A�j^m�0�ho ');
INSERT INTO `wp_wfFileMods` VALUES ('[�p;\"V\Zm�����','wp-content/plugins/iq-block-country/icons/gn.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�����)ۊ����e�\"');
INSERT INTO `wp_wfFileMods` VALUES ('E����ԕV�z$5Jķ#','wp-content/plugins/iq-block-country/icons/gp.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��\n b�O�d13q���');
INSERT INTO `wp_wfFileMods` VALUES ('�?��ޭf���*�6�','wp-content/plugins/iq-block-country/icons/gq.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','p�K+8��R�Dj>3');
INSERT INTO `wp_wfFileMods` VALUES ('��n8�c���,DP`��','wp-content/plugins/iq-block-country/icons/gr.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��2��1�\'X\\���y�');
INSERT INTO `wp_wfFileMods` VALUES ('���]Xx�Cjnϥ��','wp-content/plugins/iq-block-country/icons/gs.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',';Q\r6�p�ճڀ�ɷ');
INSERT INTO `wp_wfFileMods` VALUES ('��j����k<,g�K\n','wp-content/plugins/iq-block-country/icons/gt.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','8N�8B\ZhS��]H�Ě�');
INSERT INTO `wp_wfFileMods` VALUES ('(���_�w�;�C�a-tC','wp-content/plugins/iq-block-country/icons/gu.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','-�|�6M$�[�?��');
INSERT INTO `wp_wfFileMods` VALUES ('f�idR��;x2HX�	','wp-content/plugins/iq-block-country/icons/gw.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','5���!��_X�w�d�');
INSERT INTO `wp_wfFileMods` VALUES ('[I*���kP��r�E','wp-content/plugins/iq-block-country/icons/gy.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�	g�z��s͉�`�');
INSERT INTO `wp_wfFileMods` VALUES ('��KإBp�t0LJE','wp-content/plugins/iq-block-country/icons/hk.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','8�Q���@芓X����');
INSERT INTO `wp_wfFileMods` VALUES ('Ƭ/;�����n��zQ','wp-content/plugins/iq-block-country/icons/hm.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','/�IȈ�����G\\���');
INSERT INTO `wp_wfFileMods` VALUES ('��Вx�k��ӆ���','wp-content/plugins/iq-block-country/icons/hn.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��B�V�x\0�#���y�W');
INSERT INTO `wp_wfFileMods` VALUES ('v�a�H�B�[H:�kT�','wp-content/plugins/iq-block-country/icons/hr.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','hĐ\0�Sٴ�G��a');
INSERT INTO `wp_wfFileMods` VALUES ('�w�DL:�Ȥ\ZoC�Ym','wp-content/plugins/iq-block-country/icons/ht.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�6�t3;;�\'���V');
INSERT INTO `wp_wfFileMods` VALUES ('������u�uN�s���','wp-content/plugins/iq-block-country/icons/hu.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','loΊoМ4	d�^���');
INSERT INTO `wp_wfFileMods` VALUES ('h�k^�T��\'�K�2P','wp-content/plugins/iq-block-country/icons/id.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��8���\0��U�T&tL');
INSERT INTO `wp_wfFileMods` VALUES ('�\n^�����\0dFX�:','wp-content/plugins/iq-block-country/icons/ie.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','H�-\rQ籛{y�1��\\');
INSERT INTO `wp_wfFileMods` VALUES ('\"�ﭬ�\"�Ľ�;~','wp-content/plugins/iq-block-country/icons/il.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�5����9Ak�$v�+');
INSERT INTO `wp_wfFileMods` VALUES ('_B�ڵ@��������\'','wp-content/plugins/iq-block-country/icons/in.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','P�,��4����sdl��');
INSERT INTO `wp_wfFileMods` VALUES ('\n�sOQv8ѫ\r`L','wp-content/plugins/iq-block-country/icons/io.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','8���p\'��aP(��!');
INSERT INTO `wp_wfFileMods` VALUES ('޲\'���}E��%Q�%J','wp-content/plugins/iq-block-country/icons/iq.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','9��vb\Z�0�4�#O�');
INSERT INTO `wp_wfFileMods` VALUES ('o�<L|ә�J\Z7�O�','wp-content/plugins/iq-block-country/icons/ir.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','*���TupM0�Y�+');
INSERT INTO `wp_wfFileMods` VALUES ('I�c�z)����۔���','wp-content/plugins/iq-block-country/icons/is.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�����Ȑ�HX~�');
INSERT INTO `wp_wfFileMods` VALUES ('��Y�=2�kyT��p��','wp-content/plugins/iq-block-country/icons/it.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','xO~�3�YX�Ζ��');
INSERT INTO `wp_wfFileMods` VALUES ('K��;֒�9��+���`�','wp-content/plugins/iq-block-country/icons/jm.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���^ _v\'z�q�!�');
INSERT INTO `wp_wfFileMods` VALUES ('�(]߈\r��V��n�T','wp-content/plugins/iq-block-country/icons/jo.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ў�����������');
INSERT INTO `wp_wfFileMods` VALUES ('�lӃ�S�P����t���','wp-content/plugins/iq-block-country/icons/jp.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����|%�F��\"6\\\0<');
INSERT INTO `wp_wfFileMods` VALUES ('ƃBH��-}��s�4�','wp-content/plugins/iq-block-country/icons/ke.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','5qR�7��Z}Wſ0�<');
INSERT INTO `wp_wfFileMods` VALUES ('�U�&]$�$y�E�����','wp-content/plugins/iq-block-country/icons/kg.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',' 3��}Ī�c\\');
INSERT INTO `wp_wfFileMods` VALUES ('x��_ ��%��2.�','wp-content/plugins/iq-block-country/icons/kh.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�X�f�O�l�\Z�H,');
INSERT INTO `wp_wfFileMods` VALUES ('V��ƖmC6U��t	�\0&','wp-content/plugins/iq-block-country/icons/ki.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','p<풹|�q08����');
INSERT INTO `wp_wfFileMods` VALUES (' �`(��eȃa/','wp-content/plugins/iq-block-country/icons/km.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','̔$��� !��X#�4');
INSERT INTO `wp_wfFileMods` VALUES ('�c˿\rb�?}{���','wp-content/plugins/iq-block-country/icons/kn.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�rzv�e%�c4�\Z�j');
INSERT INTO `wp_wfFileMods` VALUES (',h��������@���','wp-content/plugins/iq-block-country/icons/kp.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�>��K������.6\0�');
INSERT INTO `wp_wfFileMods` VALUES ('��|�e ���\Z��E�','wp-content/plugins/iq-block-country/icons/kr.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�c�[�U�J������');
INSERT INTO `wp_wfFileMods` VALUES ('�}����ܡy4Or','wp-content/plugins/iq-block-country/icons/kw.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','.�͹ʂ@��7.L��');
INSERT INTO `wp_wfFileMods` VALUES ('Ǳ���Ϫd��\0r��','wp-content/plugins/iq-block-country/icons/ky.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�,V�%h�0�q?�');
INSERT INTO `wp_wfFileMods` VALUES ('�~��\ZRdc0\"t','wp-content/plugins/iq-block-country/icons/kz.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','mQk�R�_�]vE315');
INSERT INTO `wp_wfFileMods` VALUES ('��t��G{Y�U!�E1l','wp-content/plugins/iq-block-country/icons/la.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','3u�S]i$�\n�>�h�');
INSERT INTO `wp_wfFileMods` VALUES ('���f���.l�̚�Ȟ','wp-content/plugins/iq-block-country/icons/lb.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���o\r�̠�J�3-��');
INSERT INTO `wp_wfFileMods` VALUES ('m=��NO�A	��w��','wp-content/plugins/iq-block-country/icons/lc.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�_,y�wK� ��\n�');
INSERT INTO `wp_wfFileMods` VALUES ('<����%��Z?w�.','wp-content/plugins/iq-block-country/icons/li.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','� 4��F����B	*2');
INSERT INTO `wp_wfFileMods` VALUES ('���t�޴�\"�_Ņ�','wp-content/plugins/iq-block-country/icons/lk.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','N��S��wiv���N�');
INSERT INTO `wp_wfFileMods` VALUES ('S��Ljc�/o�ͷq','wp-content/plugins/iq-block-country/icons/lr.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',';m�r!���FRI��+\'');
INSERT INTO `wp_wfFileMods` VALUES ('�L#\n|�ڲ�ڛk��','wp-content/plugins/iq-block-country/icons/ls.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�(x:��T��QZ*�');
INSERT INTO `wp_wfFileMods` VALUES ('\'�H�D�!>L��e�7�','wp-content/plugins/iq-block-country/icons/lt.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��읹�t�_���S�Ä');
INSERT INTO `wp_wfFileMods` VALUES ('T�a�s�\Z��րJ�B','wp-content/plugins/iq-block-country/icons/lu.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',';೦	n�w�׹��d�');
INSERT INTO `wp_wfFileMods` VALUES ('�i���4u�\0hA^�+_','wp-content/plugins/iq-block-country/icons/lv.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','o���em=�R��-�');
INSERT INTO `wp_wfFileMods` VALUES ('�27�#���Y�;\'x��','wp-content/plugins/iq-block-country/icons/ly.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','?�n��_�ˌ \Z�鷼');
INSERT INTO `wp_wfFileMods` VALUES ('=\0�Y|3u;aK_�K쾩','wp-content/plugins/iq-block-country/icons/ma.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�6������_�L\rhhN');
INSERT INTO `wp_wfFileMods` VALUES ('��W	�x�:������','wp-content/plugins/iq-block-country/icons/mc.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','c��1Ȱ�s6���S�');
INSERT INTO `wp_wfFileMods` VALUES ('�7����J_JC�J���5','wp-content/plugins/iq-block-country/icons/md.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��U�8glS�3\rk�');
INSERT INTO `wp_wfFileMods` VALUES ('���v͊�+Tr^�l4�','wp-content/plugins/iq-block-country/icons/me.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','z.���^�xj����	');
INSERT INTO `wp_wfFileMods` VALUES ('҃��o{\"���N��Z�','wp-content/plugins/iq-block-country/icons/mg.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Z�$����Wp��8�');
INSERT INTO `wp_wfFileMods` VALUES ('�Y����5� ��ݴ,','wp-content/plugins/iq-block-country/icons/mh.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���X!��E�߆g�`�');
INSERT INTO `wp_wfFileMods` VALUES ('�u�G�@��k\\8��*\n�','wp-content/plugins/iq-block-country/icons/mk.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ay��ʯ��ZLt��');
INSERT INTO `wp_wfFileMods` VALUES ('�pJ����o�&��','wp-content/plugins/iq-block-country/icons/ml.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Q�C�qg�1���l');
INSERT INTO `wp_wfFileMods` VALUES ('݈�~���jf���','wp-content/plugins/iq-block-country/icons/mm.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��!�Ij�ϧw��C');
INSERT INTO `wp_wfFileMods` VALUES ('KLj�����!c�yh','wp-content/plugins/iq-block-country/icons/mn.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Jۚ�A�u71��\'�Og�');
INSERT INTO `wp_wfFileMods` VALUES ('(r�X���dE����','wp-content/plugins/iq-block-country/icons/mo.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','c9���L����h_');
INSERT INTO `wp_wfFileMods` VALUES ('`KK����3wڙ�','wp-content/plugins/iq-block-country/icons/mp.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���翵��0�ƒU�');
INSERT INTO `wp_wfFileMods` VALUES ('	:[��=��=@�����','wp-content/plugins/iq-block-country/icons/mq.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�_��3�������7?');
INSERT INTO `wp_wfFileMods` VALUES ('�T�P��acgg����','wp-content/plugins/iq-block-country/icons/mr.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','lȡ���B\Z8��s�|�');
INSERT INTO `wp_wfFileMods` VALUES ('P]�\0\"�tyRQܖ�','wp-content/plugins/iq-block-country/icons/ms.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ݼ*��\n�3���&');
INSERT INTO `wp_wfFileMods` VALUES (' 2��s�j!o�T��y','wp-content/plugins/iq-block-country/icons/mt.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','z~������n�S�o!');
INSERT INTO `wp_wfFileMods` VALUES ('rg��i���I�q(�','wp-content/plugins/iq-block-country/icons/mu.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','H���?���{��R/');
INSERT INTO `wp_wfFileMods` VALUES ('���P�3y��unIF���','wp-content/plugins/iq-block-country/icons/mv.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','$���?�02vði�');
INSERT INTO `wp_wfFileMods` VALUES ('<����8���m��','wp-content/plugins/iq-block-country/icons/mw.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','+�6�-C�ѫK$1_�9');
INSERT INTO `wp_wfFileMods` VALUES ('�8�xY�X�������e','wp-content/plugins/iq-block-country/icons/mx.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','G��_��p�T���?�}');
INSERT INTO `wp_wfFileMods` VALUES ('���6�>H,���*��','wp-content/plugins/iq-block-country/icons/my.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���b�A�a_��у��');
INSERT INTO `wp_wfFileMods` VALUES (':���peU�{b�B�?�','wp-content/plugins/iq-block-country/icons/mz.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��A���<h��)�');
INSERT INTO `wp_wfFileMods` VALUES ('�>$\ZYzB��<��','wp-content/plugins/iq-block-country/icons/na.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�1� �8�6�� ');
INSERT INTO `wp_wfFileMods` VALUES ('��)[eH+��o�\":�','wp-content/plugins/iq-block-country/icons/nc.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�����_�#��<�Cx');
INSERT INTO `wp_wfFileMods` VALUES ('Q]���ǅ�Ӽ������','wp-content/plugins/iq-block-country/icons/ne.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���e`]���ӯK!^�');
INSERT INTO `wp_wfFileMods` VALUES ('��!���8G#��)�1','wp-content/plugins/iq-block-country/icons/nf.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�$�!��Y%j>:QG�%');
INSERT INTO `wp_wfFileMods` VALUES ('߷Z����*�B�}�&�','wp-content/plugins/iq-block-country/icons/ng.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Pa1��x.O�\\쉩');
INSERT INTO `wp_wfFileMods` VALUES ('�j�K��?`��/@[t','wp-content/plugins/iq-block-country/icons/ni.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�:_5H��X���ښ��');
INSERT INTO `wp_wfFileMods` VALUES ('L�31�`�\Z���Q','wp-content/plugins/iq-block-country/icons/nl.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','a�U�w��Ӯ7�3�');
INSERT INTO `wp_wfFileMods` VALUES ('�DJ��_��ubǫ�W��','wp-content/plugins/iq-block-country/icons/no.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','U�庮�sۍ�P�lb');
INSERT INTO `wp_wfFileMods` VALUES ('�x�p!���P���q���','wp-content/plugins/iq-block-country/icons/np.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','R�dE=�:����/(');
INSERT INTO `wp_wfFileMods` VALUES ('��fԣY�.&@���','wp-content/plugins/iq-block-country/icons/nr.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','/�Ktxv��[c�l��o�');
INSERT INTO `wp_wfFileMods` VALUES ('o�@\\TZ�/���D���','wp-content/plugins/iq-block-country/icons/nu.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�/h-�@��n�)oc܇');
INSERT INTO `wp_wfFileMods` VALUES ('G�d�k���lc��[�','wp-content/plugins/iq-block-country/icons/nz.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ÚX�$�����ܠ');
INSERT INTO `wp_wfFileMods` VALUES ('UT	�v/��&B��ld','wp-content/plugins/iq-block-country/icons/om.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','{\0+�ī\Z����,DB�');
INSERT INTO `wp_wfFileMods` VALUES ('S�+�Ȧ��A�>Y�Z�','wp-content/plugins/iq-block-country/icons/pa.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','dyP	֛6��F�Y��V');
INSERT INTO `wp_wfFileMods` VALUES ('�_2o\'���,y��D�','wp-content/plugins/iq-block-country/icons/pe.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��b����\"z�%7');
INSERT INTO `wp_wfFileMods` VALUES ('+X���B�t^]�BMa','wp-content/plugins/iq-block-country/icons/pf.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���F�a��`�O�');
INSERT INTO `wp_wfFileMods` VALUES ('���Υ�F}�2���o','wp-content/plugins/iq-block-country/icons/pg.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','H����;���a��');
INSERT INTO `wp_wfFileMods` VALUES ('�X���k��e�)AI#��','wp-content/plugins/iq-block-country/icons/ph.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��Ѕ��\"M4F^$��');
INSERT INTO `wp_wfFileMods` VALUES ('C�x�d��]�\'���2�','wp-content/plugins/iq-block-country/icons/pk.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',';щq�n�F&��');
INSERT INTO `wp_wfFileMods` VALUES ('n�Ⲡ]�})�F:J�','wp-content/plugins/iq-block-country/icons/pl.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���l ��I�&��L�');
INSERT INTO `wp_wfFileMods` VALUES ('�vŻ\r�u�P��}�Q�','wp-content/plugins/iq-block-country/icons/pm.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�A��IP���¨�');
INSERT INTO `wp_wfFileMods` VALUES ('7����˄�R�S%���u','wp-content/plugins/iq-block-country/icons/pn.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���W�4���w�6�;�');
INSERT INTO `wp_wfFileMods` VALUES ('A[��Y)�HTX���%','wp-content/plugins/iq-block-country/icons/pr.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','@��\ZL�m@��\\o՚');
INSERT INTO `wp_wfFileMods` VALUES ('�7LJ�ZZ\nۃ�rW���','wp-content/plugins/iq-block-country/icons/ps.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','h���$�~�ӳ�2�\"�');
INSERT INTO `wp_wfFileMods` VALUES ('،�m\Z���^��\r�','wp-content/plugins/iq-block-country/icons/pt.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','[����!)�2����p');
INSERT INTO `wp_wfFileMods` VALUES ('�t���֑s�J�}��','wp-content/plugins/iq-block-country/icons/pw.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','������@�=�O');
INSERT INTO `wp_wfFileMods` VALUES ('M,/��-ū�g%��','wp-content/plugins/iq-block-country/icons/py.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���Z1D�\ZE)�xp');
INSERT INTO `wp_wfFileMods` VALUES ('��g�\\��R�t�^�u�','wp-content/plugins/iq-block-country/icons/qa.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��6:\'��ў$\'G׾�');
INSERT INTO `wp_wfFileMods` VALUES ('��=׷\'�Tk��fN�P','wp-content/plugins/iq-block-country/icons/re.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��t�0^VcTzH��-�');
INSERT INTO `wp_wfFileMods` VALUES ('ԣ\'�.Na�dH� ���','wp-content/plugins/iq-block-country/icons/ro.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�8��R��O�\\{��G');
INSERT INTO `wp_wfFileMods` VALUES ('ju&jJ�T�s�\r��','wp-content/plugins/iq-block-country/icons/rs.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','[g.>�3aB�a[�wK�');
INSERT INTO `wp_wfFileMods` VALUES ('��la{7���!','wp-content/plugins/iq-block-country/icons/ru.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\r1�u��\"s�˓�Jt\"');
INSERT INTO `wp_wfFileMods` VALUES ('�ҁS\"��<��?��','wp-content/plugins/iq-block-country/icons/rw.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��#H��8�F#&�/�\"');
INSERT INTO `wp_wfFileMods` VALUES ('�>y֚�j�I�+��~,','wp-content/plugins/iq-block-country/icons/sa.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','`X����F�����\Z��');
INSERT INTO `wp_wfFileMods` VALUES ('W8�+��˛s�4X','wp-content/plugins/iq-block-country/icons/sb.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','^Kt��t+�:b���');
INSERT INTO `wp_wfFileMods` VALUES ('�|��OI�L���`�','wp-content/plugins/iq-block-country/icons/sc.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','9e�(Q�!eװ�;D');
INSERT INTO `wp_wfFileMods` VALUES ('�p2Ʀ�B����ݕ�~','wp-content/plugins/iq-block-country/icons/scotland.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','쥾�nM���X������');
INSERT INTO `wp_wfFileMods` VALUES ('\0�M���Y�U`��c','wp-content/plugins/iq-block-country/icons/sd.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�r��3i� �XѸ`��');
INSERT INTO `wp_wfFileMods` VALUES ('y3�RM�G��4�@:��','wp-content/plugins/iq-block-country/icons/se.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','L�m�3$&~(ܭ�W/');
INSERT INTO `wp_wfFileMods` VALUES ('��F�� )����','wp-content/plugins/iq-block-country/icons/sg.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��QY�7���=���ы');
INSERT INTO `wp_wfFileMods` VALUES ('U�ͳP\'\"�G\r;�c��','wp-content/plugins/iq-block-country/icons/sh.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���	��zJ`����	=');
INSERT INTO `wp_wfFileMods` VALUES ('�\'�zC������+�J','wp-content/plugins/iq-block-country/icons/si.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�N��Z�i\0�\ZqŁ�');
INSERT INTO `wp_wfFileMods` VALUES ('y\0��,`1ώq�B��','wp-content/plugins/iq-block-country/icons/sj.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','U�庮�sۍ�P�lb');
INSERT INTO `wp_wfFileMods` VALUES ('?\r�	\'p�� X����K','wp-content/plugins/iq-block-country/icons/sk.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Z~�~D�b���$�0��2');
INSERT INTO `wp_wfFileMods` VALUES ('�	xH��X澥��c','wp-content/plugins/iq-block-country/icons/sl.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','s�N��O�i<N�NX!');
INSERT INTO `wp_wfFileMods` VALUES ('���U�L�/�%���s@�','wp-content/plugins/iq-block-country/icons/sm.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','V�����\'�kP�Q��');
INSERT INTO `wp_wfFileMods` VALUES ('�R���zNBL����','wp-content/plugins/iq-block-country/icons/sn.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','P\Z_�f-zՈ�\\��IT');
INSERT INTO `wp_wfFileMods` VALUES ('���\'@xM�tFiM���','wp-content/plugins/iq-block-country/icons/so.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','K����m�CJ�}�?��');
INSERT INTO `wp_wfFileMods` VALUES ('[e#���@��^�c','wp-content/plugins/iq-block-country/icons/sr.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���sv{�xv�*�C�`');
INSERT INTO `wp_wfFileMods` VALUES ('�n��w�����p��','wp-content/plugins/iq-block-country/icons/st.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\'*P�ee�6����');
INSERT INTO `wp_wfFileMods` VALUES ('������&�D-�g�,','wp-content/plugins/iq-block-country/icons/sv.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��Svm��-�\"Y��/\\');
INSERT INTO `wp_wfFileMods` VALUES ('�b3�f�g!�#��	u�','wp-content/plugins/iq-block-country/icons/sy.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��n�>�}dj�QMWR�');
INSERT INTO `wp_wfFileMods` VALUES ('le��\\RkaNp��Ѩ','wp-content/plugins/iq-block-country/icons/sz.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�vu�R���Lɚ�\0O');
INSERT INTO `wp_wfFileMods` VALUES ('�Z��}]���P��</','wp-content/plugins/iq-block-country/icons/tc.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Ps<�g\0X�7�R���');
INSERT INTO `wp_wfFileMods` VALUES ('�.�yr��#I��i��','wp-content/plugins/iq-block-country/icons/td.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','l�?l����J�I}�');
INSERT INTO `wp_wfFileMods` VALUES ('�\"�(��\"/���R�Ҧ','wp-content/plugins/iq-block-country/icons/tf.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�̺��N��Lx`���');
INSERT INTO `wp_wfFileMods` VALUES ('C}�ts#K�Be�&�','wp-content/plugins/iq-block-country/icons/tg.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\\bru�����n+��');
INSERT INTO `wp_wfFileMods` VALUES ('@��W���[��BX��','wp-content/plugins/iq-block-country/icons/th.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��(k������6��RQ');
INSERT INTO `wp_wfFileMods` VALUES ('�`��\\Zpo�s\"i�','wp-content/plugins/iq-block-country/icons/tj.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\\�Hх��6�s����');
INSERT INTO `wp_wfFileMods` VALUES ('>��p�e�=�M0��','wp-content/plugins/iq-block-country/icons/tk.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�o��F8�ca�0vh�T');
INSERT INTO `wp_wfFileMods` VALUES ('O�3m;���24Ӕg','wp-content/plugins/iq-block-country/icons/tl.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','	>v�gYd|3�^񺝠');
INSERT INTO `wp_wfFileMods` VALUES ('0�W��y����5��','wp-content/plugins/iq-block-country/icons/tm.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�l�&���gvN�\0)+');
INSERT INTO `wp_wfFileMods` VALUES ('���u\r%����~','wp-content/plugins/iq-block-country/icons/tn.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��GٜH�M$�$6�');
INSERT INTO `wp_wfFileMods` VALUES ('ݞ��[R�Z��j���N','wp-content/plugins/iq-block-country/icons/to.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Ά��-wx�f��_Ks�');
INSERT INTO `wp_wfFileMods` VALUES ('w4*����1���ş�','wp-content/plugins/iq-block-country/icons/tr.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','1�pXT�W�2�Ph��');
INSERT INTO `wp_wfFileMods` VALUES ('ܞ�sS۝���%h��','wp-content/plugins/iq-block-country/icons/tt.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��G�Ԇ\'��lْ�,�+');
INSERT INTO `wp_wfFileMods` VALUES ('\Z�~e�E���	�b��9','wp-content/plugins/iq-block-country/icons/tv.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','o�Umؽ�l���̆I�');
INSERT INTO `wp_wfFileMods` VALUES ('Z��RY�	x\0U����','wp-content/plugins/iq-block-country/icons/tw.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','A�+<�=^veЂ1�');
INSERT INTO `wp_wfFileMods` VALUES ('*.�A.��p�8�z�','wp-content/plugins/iq-block-country/icons/tz.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Fx�����1;���\\');
INSERT INTO `wp_wfFileMods` VALUES ('I�;Q�\r�E�8�A�','wp-content/plugins/iq-block-country/icons/ua.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','~�����}\\/�p�');
INSERT INTO `wp_wfFileMods` VALUES ('�_�2��-���','wp-content/plugins/iq-block-country/icons/ug.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�4���v�UA��an]');
INSERT INTO `wp_wfFileMods` VALUES ('\Z���H�V����(3','wp-content/plugins/iq-block-country/icons/um.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��/J�̱>��Y!');
INSERT INTO `wp_wfFileMods` VALUES ('�>Ή�F\"\"��ǯ','wp-content/plugins/iq-block-country/icons/us.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����	����K�Yz�H');
INSERT INTO `wp_wfFileMods` VALUES ('l\ni)TDeN|̡����','wp-content/plugins/iq-block-country/icons/uy.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���ٱ�0�U\\�~�');
INSERT INTO `wp_wfFileMods` VALUES ('�M7r^�*�����Q','wp-content/plugins/iq-block-country/icons/uz.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','7佶B)�bL��}B�!M');
INSERT INTO `wp_wfFileMods` VALUES ('����b󶾢iC�|x','wp-content/plugins/iq-block-country/icons/va.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','I6B�k�D`/���O�');
INSERT INTO `wp_wfFileMods` VALUES ('���\0�dd{���z�\Zj','wp-content/plugins/iq-block-country/icons/vc.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','`���y�^���b�7��');
INSERT INTO `wp_wfFileMods` VALUES ('�.����\r�1�(�6�','wp-content/plugins/iq-block-country/icons/ve.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',':�$�_j���E /��');
INSERT INTO `wp_wfFileMods` VALUES ('&�-�УbL��%(\0͛','wp-content/plugins/iq-block-country/icons/vg.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','y�WQI�f=����');
INSERT INTO `wp_wfFileMods` VALUES ('�L	��n�j�\0,O\n','wp-content/plugins/iq-block-country/icons/vi.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�[�u,ґw��^��9');
INSERT INTO `wp_wfFileMods` VALUES ('N��I�1M�7B�O�','wp-content/plugins/iq-block-country/icons/vn.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','c�6���ڷ�l����S');
INSERT INTO `wp_wfFileMods` VALUES ('�ߦ���ع/�e��','wp-content/plugins/iq-block-country/icons/vu.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�{��,߀I.�M��bV�');
INSERT INTO `wp_wfFileMods` VALUES ('V���,�.�T��','wp-content/plugins/iq-block-country/icons/wales.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','B�ʃr�2$��M�&');
INSERT INTO `wp_wfFileMods` VALUES ('&��_�\"�����v','wp-content/plugins/iq-block-country/icons/wf.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��\Z�7��t��gp��');
INSERT INTO `wp_wfFileMods` VALUES ('8n�쉩P���r	�N','wp-content/plugins/iq-block-country/icons/ws.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','h?d2�\Z��z�1���');
INSERT INTO `wp_wfFileMods` VALUES ('G�Y���Ɖ!�	��@�','wp-content/plugins/iq-block-country/icons/ye.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',')	��B��)�Y�');
INSERT INTO `wp_wfFileMods` VALUES ('�B���@\0�lnS','wp-content/plugins/iq-block-country/icons/yt.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�l|ײGL��[ �U�');
INSERT INTO `wp_wfFileMods` VALUES ('f���0|�)\\\"����2','wp-content/plugins/iq-block-country/icons/za.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��M���zy�gk�z');
INSERT INTO `wp_wfFileMods` VALUES ('��m��h�79�i�','wp-content/plugins/iq-block-country/icons/zm.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�i���}#Dhg��JR#�');
INSERT INTO `wp_wfFileMods` VALUES ('-��E �v���3���','wp-content/plugins/iq-block-country/icons/zw.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�~<I��u�օI�\Z');
INSERT INTO `wp_wfFileMods` VALUES ('5��R�|=YoeΨ�6w�','wp-content/plugins/iq-block-country/iq-block-country.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Dㇻr6A�8�KP');
INSERT INTO `wp_wfFileMods` VALUES ('�ms��6���\rQu� ','wp-content/plugins/iq-block-country/lang/en_EN.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','C�u4$q�n\\Z5�f�');
INSERT INTO `wp_wfFileMods` VALUES ('!�cP�V�ƻCo_3��','wp-content/plugins/iq-block-country/lang/en_EN.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��y��B�(�\\�B�');
INSERT INTO `wp_wfFileMods` VALUES ('��!�c԰�6S0%','wp-content/plugins/iq-block-country/lang/iqblockcountry-nl_NL.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����tZ|n_��(');
INSERT INTO `wp_wfFileMods` VALUES ('$��!j�mzV��4�z','wp-content/plugins/iq-block-country/lang/iqblockcountry-nl_NL.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�FGҢ�Z�3�go3�4');
INSERT INTO `wp_wfFileMods` VALUES ('�&.���ףK XB:�','wp-content/plugins/iq-block-country/lang/iqblockcountry-ru_RU.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ZҮn�	g�b����\0J');
INSERT INTO `wp_wfFileMods` VALUES ('}^.�|���:~��}�','wp-content/plugins/iq-block-country/lang/iqblockcountry-ru_RU.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',']? ��X�%�ߕ�T��');
INSERT INTO `wp_wfFileMods` VALUES ('q�G\"�N�&4�˗�Yx','wp-content/plugins/iq-block-country/lang/iqblockcountry-sr_RS.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�}��GK�e-\r�x�');
INSERT INTO `wp_wfFileMods` VALUES (']<zz��H�z��C�','wp-content/plugins/iq-block-country/lang/iqblockcountry-sr_RS.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�_�h٢�.{K�[�U%');
INSERT INTO `wp_wfFileMods` VALUES ('�Έ-���ᩃ\rc=��','wp-content/plugins/iq-block-country/libs/blockcountry-checks.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��Ә4��7j��o�&');
INSERT INTO `wp_wfFileMods` VALUES (':����DK��X��','wp-content/plugins/iq-block-country/libs/blockcountry-logging.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','t�)uk��Vsg�6]Q');
INSERT INTO `wp_wfFileMods` VALUES ('<8?~�Z�L����[','wp-content/plugins/iq-block-country/libs/blockcountry-search-engines.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','G�B���H� 1L����');
INSERT INTO `wp_wfFileMods` VALUES ('Sײ��{hi|�I�V','wp-content/plugins/iq-block-country/libs/blockcountry-settings.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��5��Q�c;�.��');
INSERT INTO `wp_wfFileMods` VALUES ('-�|���/�z��(','wp-content/plugins/iq-block-country/libs/blockcountry-tracking.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����m�\"2�\"$�\'');
INSERT INTO `wp_wfFileMods` VALUES ('�\nDL\Z�����%5D��','wp-content/plugins/iq-block-country/libs/blockcountry-validation.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','%��(����ty}�W');
INSERT INTO `wp_wfFileMods` VALUES ('jHը�iF\'­��','wp-content/plugins/iq-block-country/libs/geoip.inc',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\'��}�e�K��Nt���');
INSERT INTO `wp_wfFileMods` VALUES ('�\n���(=r^�','wp-content/plugins/iq-block-country/readme.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Z�]� |��[m|�');
INSERT INTO `wp_wfFileMods` VALUES ('�<���86Ko��X','wp-content/plugins/wordfence/css/activity-report-widget.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���\r�mE�d�b�');
INSERT INTO `wp_wfFileMods` VALUES ('�!@A�;1)SJ��b��','wp-content/plugins/wordfence/css/colorbox.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���\0g/�4BE-����');
INSERT INTO `wp_wfFileMods` VALUES ('��ŷN	\0��f\ZT��','wp-content/plugins/wordfence/css/diff.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\"�����y1���4Z�');
INSERT INTO `wp_wfFileMods` VALUES ('a�|\n��|@X\n��fM\r�','wp-content/plugins/wordfence/css/dt_table.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�[�f��\Z��}�I+o');
INSERT INTO `wp_wfFileMods` VALUES ('��5Z�����o��Ү<','wp-content/plugins/wordfence/css/fullLog.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','+����W�jw˄}��');
INSERT INTO `wp_wfFileMods` VALUES ('j��o�+��s�7�8','wp-content/plugins/wordfence/css/iptraf.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','+	���<�dq�7^�');
INSERT INTO `wp_wfFileMods` VALUES ('o��a��w5h�@+w\r�','wp-content/plugins/wordfence/css/main.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','OMB&�qW�Rw���}9�');
INSERT INTO `wp_wfFileMods` VALUES ('���s�YX���㞗','wp-content/plugins/wordfence/css/phpinfo.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�<`�,7��Ju\0�');
INSERT INTO `wp_wfFileMods` VALUES ('様��7�^��b�\"�','wp-content/plugins/wordfence/images/back_disabled.jpg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','h���g���i���>');
INSERT INTO `wp_wfFileMods` VALUES ('���׮F��p�s��4�','wp-content/plugins/wordfence/images/back_enabled.jpg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����]�����H��');
INSERT INTO `wp_wfFileMods` VALUES ('^yG=ڜFg;3�á�','wp-content/plugins/wordfence/images/button-grad-grey.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��RC���Ty��?�');
INSERT INTO `wp_wfFileMods` VALUES ('.�E�[J��l�x��','wp-content/plugins/wordfence/images/forward_disabled.jpg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','M_��Z?�N)�Ҋ�:�5');
INSERT INTO `wp_wfFileMods` VALUES ('�\0h�Kf��\0��','wp-content/plugins/wordfence/images/forward_enabled.jpg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','U\0/3e4e������');
INSERT INTO `wp_wfFileMods` VALUES ('���窒�u��\rZJW+','wp-content/plugins/wordfence/images/help.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','$N��;\'��M���� Y');
INSERT INTO `wp_wfFileMods` VALUES ('٘�\"P�ܞ��,���','wp-content/plugins/wordfence/images/icons/ajax24.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','K:�����m𙗣P�');
INSERT INTO `wp_wfFileMods` VALUES ('\'���� �o���S��','wp-content/plugins/wordfence/images/icons/ajax3.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','mw�ߴtꍓ\'\n���s');
INSERT INTO `wp_wfFileMods` VALUES ('��y�&a�A�7�]Dm','wp-content/plugins/wordfence/images/icons/ajaxRed16.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���%���B\ng�2��;');
INSERT INTO `wp_wfFileMods` VALUES ('���4�����=��','wp-content/plugins/wordfence/images/icons/ajaxScan.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ʖ�Ѵ��~f���i�');
INSERT INTO `wp_wfFileMods` VALUES ('j&�V1���6�4����','wp-content/plugins/wordfence/images/icons/ajaxWhite32x32.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���r��9 �#��{�');
INSERT INTO `wp_wfFileMods` VALUES ('(x*J���,�LÛn�<K','wp-content/plugins/wordfence/images/icons/arrow_refresh.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','k�w�`�`�|�}$G��');
INSERT INTO `wp_wfFileMods` VALUES ('6[f�9�?�� _�','wp-content/plugins/wordfence/images/icons/bullet_yellow.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','J&���Ɍ����ԔQ<');
INSERT INTO `wp_wfFileMods` VALUES (']���*������J�','wp-content/plugins/wordfence/images/icons/email_go.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��j��E��H)�.��');
INSERT INTO `wp_wfFileMods` VALUES ('����`%��{���+��','wp-content/plugins/wordfence/images/icons/error128.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�:�%7�!��.�');
INSERT INTO `wp_wfFileMods` VALUES ('z�5�*\ZADZCk��j��','wp-content/plugins/wordfence/images/icons/magnifier.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���uO�{:qcV��\'');
INSERT INTO `wp_wfFileMods` VALUES ('�Ρ~�ߓ�:�����eo','wp-content/plugins/wordfence/images/icons/tick128.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ğ��c�h4\"���');
INSERT INTO `wp_wfFileMods` VALUES ('�;`�$r���$���=','wp-content/plugins/wordfence/images/icons/warning128.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','p�G�I�t*����Np=');
INSERT INTO `wp_wfFileMods` VALUES ('�X��@��%�1C��i','wp-content/plugins/wordfence/images/lightbox-controls.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�m]�a���\\$��');
INSERT INTO `wp_wfFileMods` VALUES ('��?���z6���aDz','wp-content/plugins/wordfence/images/loading.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','K:�����m𙗣P�');
INSERT INTO `wp_wfFileMods` VALUES ('�Kj��h����','wp-content/plugins/wordfence/images/loading_background.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��\'�2��p\nK�X��');
INSERT INTO `wp_wfFileMods` VALUES ('���Q�o�H*���(�','wp-content/plugins/wordfence/images/sort_asc.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',',��I��+ƾ���=��');
INSERT INTO `wp_wfFileMods` VALUES ('�lX�w��B�*X�W�','wp-content/plugins/wordfence/images/sort_asc_disabled.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Oɧ���*�X���9e');
INSERT INTO `wp_wfFileMods` VALUES ('?Yv�q_����ۮXO','wp-content/plugins/wordfence/images/sort_both.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��%�B�Qx�SV.D');
INSERT INTO `wp_wfFileMods` VALUES ('7�c�.$P!�\"�򹚆','wp-content/plugins/wordfence/images/sort_desc.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�<���j��_�ˊR�2');
INSERT INTO `wp_wfFileMods` VALUES ('xy�!���q�)�.ˉ\"','wp-content/plugins/wordfence/images/sort_desc_disabled.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�m����͟��r�� 9');
INSERT INTO `wp_wfFileMods` VALUES (':mwvK\r�����Z��~','wp-content/plugins/wordfence/images/wordfence-logo-16x16.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Y�~F,�N8z����O2');
INSERT INTO `wp_wfFileMods` VALUES ('F��Oۣ������g�','wp-content/plugins/wordfence/images/wordfence-logo-32x32.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��@ۯI����uU�');
INSERT INTO `wp_wfFileMods` VALUES ('jڿ�t��1u���}���','wp-content/plugins/wordfence/images/wordfence-logo-64x64.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','v^�I�N/��g@��\\u');
INSERT INTO `wp_wfFileMods` VALUES ('�zR�u�������	;','wp-content/plugins/wordfence/images/wordfenceFalcon.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','d\'m_0�xZb-���%');
INSERT INTO `wp_wfFileMods` VALUES ('=��;�8�N�.��E�3�','wp-content/plugins/wordfence/images/wordfenceFalconEngineSmall.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�s�*�f�&@7�=J');
INSERT INTO `wp_wfFileMods` VALUES ('�d��[���8��4�ky','wp-content/plugins/wordfence/images/wordfenceFalconSmall.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','>��h�j�K�w�~��');
INSERT INTO `wp_wfFileMods` VALUES ('E��(�zRA1;eN�qD3','wp-content/plugins/wordfence/index.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','2��e��ª��\\��og');
INSERT INTO `wp_wfFileMods` VALUES ('�\"��[Q	����','wp-content/plugins/wordfence/js/admin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','J�Ģ�(c�_�YkvNV');
INSERT INTO `wp_wfFileMods` VALUES ('w�A�/	����ĉ\\q','wp-content/plugins/wordfence/js/jquery.colorbox-min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','4?Jǃ�G�`�\n�N�xl');
INSERT INTO `wp_wfFileMods` VALUES ('��EN0����6','wp-content/plugins/wordfence/js/jquery.dataTables.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','aG��z�����׳�');
INSERT INTO `wp_wfFileMods` VALUES ('a\Z�c����r�2���','wp-content/plugins/wordfence/js/jquery.tmpl.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\\}�\"���7ڷ��DZ');
INSERT INTO `wp_wfFileMods` VALUES ('����˄�v��+�nG�','wp-content/plugins/wordfence/js/jquery.tools.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�:-��Eՠx�$�B');
INSERT INTO `wp_wfFileMods` VALUES ('���XiU1`��]���','wp-content/plugins/wordfence/js/perf.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','uQ�\"�wF���R@p');
INSERT INTO `wp_wfFileMods` VALUES ('��y��/��dz�Qg��','wp-content/plugins/wordfence/js/tourTip.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Z/�׳}�d���1Fٝ');
INSERT INTO `wp_wfFileMods` VALUES ('R���1?���Y�VDt�','wp-content/plugins/wordfence/lib/.htaccess',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�I�z~�i�,L���');
INSERT INTO `wp_wfFileMods` VALUES ('��\'��FE�A�vQMv','wp-content/plugins/wordfence/lib/Diff/Renderer/Abstract.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','>\r��5]xVI�\'�i�');
INSERT INTO `wp_wfFileMods` VALUES ('y���1��-�/fIנ','wp-content/plugins/wordfence/lib/Diff/Renderer/Html/Array.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�±���t�T2�y%p�');
INSERT INTO `wp_wfFileMods` VALUES ('�-n�$.�#g%�}��','wp-content/plugins/wordfence/lib/Diff/Renderer/Html/SideBySide.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','p���uQ���: �*');
INSERT INTO `wp_wfFileMods` VALUES ('`�c0���\\���3�','wp-content/plugins/wordfence/lib/Diff/SequenceMatcher.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�O�\"%é�O�DZ�j');
INSERT INTO `wp_wfFileMods` VALUES ('ۖJ�Bw�C��|M�v','wp-content/plugins/wordfence/lib/Diff.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','R|�$����V;P����');
INSERT INTO `wp_wfFileMods` VALUES ('�&)-â�\Z�Ι�p','wp-content/plugins/wordfence/lib/GeoIP.dat',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\"\0�����HZ�');
INSERT INTO `wp_wfFileMods` VALUES ('��J���!�[W6ݧ��','wp-content/plugins/wordfence/lib/IPTraf.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��0t^J�����F�-\n');
INSERT INTO `wp_wfFileMods` VALUES ('���SP�;^ƭz��I','wp-content/plugins/wordfence/lib/conntest.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�j��\"�����r\r');
INSERT INTO `wp_wfFileMods` VALUES ('��f�N�d�����L��','wp-content/plugins/wordfence/lib/cronview.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Wjۚ�����مO');
INSERT INTO `wp_wfFileMods` VALUES ('���Ƿ�������\n�H�','wp-content/plugins/wordfence/lib/dashboard.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Be�k��.�I^R�ˡ');
INSERT INTO `wp_wfFileMods` VALUES ('����6Ri*5����æ','wp-content/plugins/wordfence/lib/dbview.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���(D�e��d�:�]');
INSERT INTO `wp_wfFileMods` VALUES ('�)����\0�e�_�5=�','wp-content/plugins/wordfence/lib/diffResult.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','IY��Y8�\\@�6d\'r#');
INSERT INTO `wp_wfFileMods` VALUES ('#\n��/��PZ~h���','wp-content/plugins/wordfence/lib/email_genericAlert.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','3Y�iV��P4�[3� ');
INSERT INTO `wp_wfFileMods` VALUES ('�����Fe�	57[�','wp-content/plugins/wordfence/lib/email_newIssues.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��Ũ��|�O_�T ���');
INSERT INTO `wp_wfFileMods` VALUES ('��t+���N-�̒��','wp-content/plugins/wordfence/lib/email_passwdChanged.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�IwK��mKa{į�;�');
INSERT INTO `wp_wfFileMods` VALUES ('\'��?�h�	}�Y\0IG','wp-content/plugins/wordfence/lib/email_pleaseChangePasswd.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�*�Gs�WcȐ�3');
INSERT INTO `wp_wfFileMods` VALUES ('��^�u����}�G��','wp-content/plugins/wordfence/lib/email_unlockRequest.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','� �E�28.63R���');
INSERT INTO `wp_wfFileMods` VALUES ('ؐV\\=lS��l�J�&','wp-content/plugins/wordfence/lib/menuHeader.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','vB��p_0*�k8�oG');
INSERT INTO `wp_wfFileMods` VALUES ('�RLS�f,�@��L=�.','wp-content/plugins/wordfence/lib/menu_activity.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��&�I�{b���$F');
INSERT INTO `wp_wfFileMods` VALUES ('���+��0�����1','wp-content/plugins/wordfence/lib/menu_blockedIPs.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','z�\nA�B!�Z�w�v');
INSERT INTO `wp_wfFileMods` VALUES ('H�`H�Ǜ�O.��ViC','wp-content/plugins/wordfence/lib/menu_countryBlocking.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�X�Q�T���<�Q,\'');
INSERT INTO `wp_wfFileMods` VALUES ('�WM��{h����(��','wp-content/plugins/wordfence/lib/menu_options.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���`��=(\\�JMN7�');
INSERT INTO `wp_wfFileMods` VALUES ('�K��z��=�G����8i','wp-content/plugins/wordfence/lib/menu_passwd.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��3��O��]-.��%��');
INSERT INTO `wp_wfFileMods` VALUES ('->��]���2j���','wp-content/plugins/wordfence/lib/menu_rangeBlocking.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�����o��`!݌�$\r');
INSERT INTO `wp_wfFileMods` VALUES ('�6cI�	@۞o����','wp-content/plugins/wordfence/lib/menu_scan.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','U\\Z���,b���pK,p8');
INSERT INTO `wp_wfFileMods` VALUES ('� *�s\\�O��il�','wp-content/plugins/wordfence/lib/menu_scanSchedule.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\nx�n�tI��b�\\N�');
INSERT INTO `wp_wfFileMods` VALUES ('�|��B�����5Y��','wp-content/plugins/wordfence/lib/menu_sitePerf.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Ϳ\"��x<�%��+�4');
INSERT INTO `wp_wfFileMods` VALUES ('�A	!f�Y�j=	qQ|H','wp-content/plugins/wordfence/lib/menu_sitePerfStats.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','B9�>��q�̉-�押');
INSERT INTO `wp_wfFileMods` VALUES ('��n��4�ۆ�x��','wp-content/plugins/wordfence/lib/menu_twoFactor.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���o���.��d��');
INSERT INTO `wp_wfFileMods` VALUES ('�Ŋ�`�7��T��a','wp-content/plugins/wordfence/lib/menu_whois.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','&�:���o�u�)/n6');
INSERT INTO `wp_wfFileMods` VALUES ('�#��>��҆�Kl','wp-content/plugins/wordfence/lib/pageTitle.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Hh�I��!S�??k');
INSERT INTO `wp_wfFileMods` VALUES ('~Ӥ�w�J̼���.�','wp-content/plugins/wordfence/lib/schedWeekEntry.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','D�1�D1����� .V');
INSERT INTO `wp_wfFileMods` VALUES ('��F�����{���A','wp-content/plugins/wordfence/lib/sysinfo.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','֤�C���C�W���M\Z');
INSERT INTO `wp_wfFileMods` VALUES ('����M~�^x��;��','wp-content/plugins/wordfence/lib/unknownFiles.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','A�{���U���z�[��');
INSERT INTO `wp_wfFileMods` VALUES ('LR7Q��ToG|�{','wp-content/plugins/wordfence/lib/viewFullActivityLog.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��݉\0�w��aY�%P');
INSERT INTO `wp_wfFileMods` VALUES ('�ٵ\nh��Jx�dv�ԃ]','wp-content/plugins/wordfence/lib/wf503.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���D�G��\\4�*Ɣ');
INSERT INTO `wp_wfFileMods` VALUES ('��2]hqu:�T6E�U�','wp-content/plugins/wordfence/lib/wfAPI.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\Z�\Z��֠�Ѿ�)E*');
INSERT INTO `wp_wfFileMods` VALUES ('#疭ۭ�v\"��M�','wp-content/plugins/wordfence/lib/wfAction.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','@��_������>js');
INSERT INTO `wp_wfFileMods` VALUES ('Ɇ8����pŻѵV�','wp-content/plugins/wordfence/lib/wfActivityReport.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����J��N�99��e');
INSERT INTO `wp_wfFileMods` VALUES ('�ދ���1F����a�','wp-content/plugins/wordfence/lib/wfArray.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��e�my��V�M�\Z��');
INSERT INTO `wp_wfFileMods` VALUES ('�-=Q�Cw�tnL�#','wp-content/plugins/wordfence/lib/wfBrowscap.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��Q?SXl��4�Z�>');
INSERT INTO `wp_wfFileMods` VALUES ('���X����J��p','wp-content/plugins/wordfence/lib/wfBrowscapCache.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','7�Oq���/��s��{x�');
INSERT INTO `wp_wfFileMods` VALUES ('���1�]�M|�K�FZ','wp-content/plugins/wordfence/lib/wfBulkCountries.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','}���M슱���_#9');
INSERT INTO `wp_wfFileMods` VALUES ('���ґ-���\r�{,�','wp-content/plugins/wordfence/lib/wfCache.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��^Y��-ad�uX�c');
INSERT INTO `wp_wfFileMods` VALUES ('Z4<n?e�����','wp-content/plugins/wordfence/lib/wfConfig.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�^U�.xk�JK�?�p\"');
INSERT INTO `wp_wfFileMods` VALUES ('���B�6[s��M�','wp-content/plugins/wordfence/lib/wfCountryMap.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',']hF�3���k�;�u');
INSERT INTO `wp_wfFileMods` VALUES ('8ÛZE�Q$}UP�T��','wp-content/plugins/wordfence/lib/wfCrawl.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Ɲ�ژ�\'��,��Śs:');
INSERT INTO `wp_wfFileMods` VALUES ('�x��βЦ��A	�<�','wp-content/plugins/wordfence/lib/wfCrypt.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���W��k|��)���4+');
INSERT INTO `wp_wfFileMods` VALUES ('�J��^\Z7��uG�k+','wp-content/plugins/wordfence/lib/wfDB.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����$y��\'�Z��N#');
INSERT INTO `wp_wfFileMods` VALUES ('�F��\Z����C��1�P','wp-content/plugins/wordfence/lib/wfDict.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','*��6Att��#�');
INSERT INTO `wp_wfFileMods` VALUES ('���A0f��f`� Kǁ}','wp-content/plugins/wordfence/lib/wfDirectoryIterator.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','켘~d[�!L��A�/�9');
INSERT INTO `wp_wfFileMods` VALUES ('=9)���)�\\��','wp-content/plugins/wordfence/lib/wfGeoIP.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','It�h�\\5���q�xdU');
INSERT INTO `wp_wfFileMods` VALUES ('q��5@�*=�&��\\X�','wp-content/plugins/wordfence/lib/wfHelperBin.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',';��!�ȍ��4Q��X#');
INSERT INTO `wp_wfFileMods` VALUES ('P�M�\Z�I̸�ݭY`r','wp-content/plugins/wordfence/lib/wfHelperString.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�OV�FaD�V�4�4ܪ');
INSERT INTO `wp_wfFileMods` VALUES ('�js��w2��p��qS','wp-content/plugins/wordfence/lib/wfIssues.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','gN��Ɗ�͝sS\Z[џ');
INSERT INTO `wp_wfFileMods` VALUES ('�ؠ]�f���P����','wp-content/plugins/wordfence/lib/wfLockedOut.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��Wѱ�X�e D���');
INSERT INTO `wp_wfFileMods` VALUES ('��w�+\"+�$��^�','wp-content/plugins/wordfence/lib/wfLog.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','N 43�f�)��{6!�|�');
INSERT INTO `wp_wfFileMods` VALUES ('^k�֪Dv6�R�','wp-content/plugins/wordfence/lib/wfRate.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Ӳ��:�\'_��G');
INSERT INTO `wp_wfFileMods` VALUES ('�ތt+�\\�+�Xa�ZU','wp-content/plugins/wordfence/lib/wfScan.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','7�����2���!���');
INSERT INTO `wp_wfFileMods` VALUES ('��6X�Ԫ4��[_��=t','wp-content/plugins/wordfence/lib/wfScanEngine.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���� }\Z�����\'');
INSERT INTO `wp_wfFileMods` VALUES ('b���HzfW����gw�','wp-content/plugins/wordfence/lib/wfSchema.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','	�n��^�\0�.�F}��');
INSERT INTO `wp_wfFileMods` VALUES ('��h�L���JH�X#0','wp-content/plugins/wordfence/lib/wfUnlockMsg.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ϥA��]Q�!y>�@Y');
INSERT INTO `wp_wfFileMods` VALUES ('��e�\\��1�tƋ�<	�','wp-content/plugins/wordfence/lib/wfUpdateCheck.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\r����^,l�8!l');
INSERT INTO `wp_wfFileMods` VALUES ('�Q49��Lz�J�','wp-content/plugins/wordfence/lib/wfUtils.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','[�nF2�}*�tX�1i');
INSERT INTO `wp_wfFileMods` VALUES ('�eŐ�����n���A�','wp-content/plugins/wordfence/lib/wfView.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�#��(|����AE|Ĉ');
INSERT INTO `wp_wfFileMods` VALUES ('���v{C����ҧ��4I','wp-content/plugins/wordfence/lib/wfViewResult.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','	qN��K80�O��');
INSERT INTO `wp_wfFileMods` VALUES ('�ݡ=��Nx��K�`*','wp-content/plugins/wordfence/lib/wordfenceClass.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�f��Ұ� �6M�t��');
INSERT INTO `wp_wfFileMods` VALUES ('�kHm�1��`0ѹ��_','wp-content/plugins/wordfence/lib/wordfenceConstants.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���^�Zm��C�');
INSERT INTO `wp_wfFileMods` VALUES ('��X����-�4�J�_�3','wp-content/plugins/wordfence/lib/wordfenceHash.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��e�s3xD�{`x\'i');
INSERT INTO `wp_wfFileMods` VALUES ('z�|*6�S\\5��3','wp-content/plugins/wordfence/lib/wordfenceScanner.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','P#�Ə,�K�^��');
INSERT INTO `wp_wfFileMods` VALUES ('h�<�]���OpNCƴ�','wp-content/plugins/wordfence/lib/wordfenceURLHoover.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','v�#Aq\'I�bO��v�D');
INSERT INTO `wp_wfFileMods` VALUES ('�v�FI��2h����n�','wp-content/plugins/wordfence/readme.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','fV�lV�Y�\Z*��ݾ�');
INSERT INTO `wp_wfFileMods` VALUES ('�;L�t�׬C����ɣ','wp-content/plugins/wordfence/tmp/.htaccess',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�I�z~�i�,L���');
INSERT INTO `wp_wfFileMods` VALUES ('��GW��`��Lh�;��','wp-content/plugins/wordfence/tmp/configCache.php',0,'����ʶ����\"C_S_','����ʶ����\"C_S_');
INSERT INTO `wp_wfFileMods` VALUES ('ClJԹ�B\"�U�sR��','wp-content/plugins/wordfence/tmp-wordfence-readme.pot',0,'� /k��\"avQ��','� /k��\"avQ��');
INSERT INTO `wp_wfFileMods` VALUES ('T?�?:q׮P��ah\'��','wp-content/plugins/wordfence/views/reports/activity-report-email-inline.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','=\\�uj��t�Q��;z�');
INSERT INTO `wp_wfFileMods` VALUES ('H���c���I�J%�H','wp-content/plugins/wordfence/views/reports/activity-report-email.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����vcy2;��9�');
INSERT INTO `wp_wfFileMods` VALUES ('N�d#R��+��r\0s[','wp-content/plugins/wordfence/views/reports/activity-report.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Q��W;�H-eGs��/w');
INSERT INTO `wp_wfFileMods` VALUES ('E#���-v37�6�Ť','wp-content/plugins/wordfence/wordfence.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\rD�����+�18');
INSERT INTO `wp_wfFileMods` VALUES ('n?FěK\\\'�3j}ɵ','wp-content/themes/gridster-lite/404.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�i՘�(�Z�5�d;��');
INSERT INTO `wp_wfFileMods` VALUES ('�Dm�Ҁ�\"ip����*1','wp-content/themes/gridster-lite/archive.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�d\'ܼ�)̔����');
INSERT INTO `wp_wfFileMods` VALUES ('�q6��L�1����4��','wp-content/themes/gridster-lite/changelog.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\0P�X��JE＾');
INSERT INTO `wp_wfFileMods` VALUES ('����\"���`M�4 �','wp-content/themes/gridster-lite/comments.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�1QP�`Ƙ2�Qr�P��');
INSERT INTO `wp_wfFileMods` VALUES ('�\r��q\"�4@͌M�','wp-content/themes/gridster-lite/content-page.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','������jŽ��ۯ��');
INSERT INTO `wp_wfFileMods` VALUES ('����мm>I��C','wp-content/themes/gridster-lite/content-single.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���(���!D�\"6:');
INSERT INTO `wp_wfFileMods` VALUES ('ψ�P�Q�\'d�&u�(�','wp-content/themes/gridster-lite/content.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���v�8K�0�N+Y');
INSERT INTO `wp_wfFileMods` VALUES ('[�~�{U��Y�C�]','wp-content/themes/gridster-lite/footer.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��|��ha�:��S�G�');
INSERT INTO `wp_wfFileMods` VALUES ('^�%}N������raJ�p','wp-content/themes/gridster-lite/functions.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��TV��-x��F�T��');
INSERT INTO `wp_wfFileMods` VALUES ('��\"��z \0�eS9��\"','wp-content/themes/gridster-lite/header.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��r���Qeۻ�H\06Q');
INSERT INTO `wp_wfFileMods` VALUES ('�\Z3XM҆��o���.','wp-content/themes/gridster-lite/home.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Ȗ8J\r��q\0�P');
INSERT INTO `wp_wfFileMods` VALUES ('���-grDL\0f���V ','wp-content/themes/gridster-lite/image.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Z���R�^����#');
INSERT INTO `wp_wfFileMods` VALUES ('�@�9�R^.2	���\n','wp-content/themes/gridster-lite/img/author-icon.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','W��ɕV��\n�D����');
INSERT INTO `wp_wfFileMods` VALUES ('�eJPoy\\�>�9H�','wp-content/themes/gridster-lite/img/category-icon.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��z�[�V�M�Q���');
INSERT INTO `wp_wfFileMods` VALUES ('֥!�-9ܳ���°','wp-content/themes/gridster-lite/img/comments-icon.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�����$���:�����d');
INSERT INTO `wp_wfFileMods` VALUES ('ERQs~a(2����9�','wp-content/themes/gridster-lite/img/date-icon.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','9�mb5��.�&�%���');
INSERT INTO `wp_wfFileMods` VALUES ('|��>�	ϘЁKl��#','wp-content/themes/gridster-lite/img/defaultthumb.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',';#�!�<�����P�');
INSERT INTO `wp_wfFileMods` VALUES ('_d�+�����	Ɛ','wp-content/themes/gridster-lite/img/logo.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','*�MP9�\'F�v��8');
INSERT INTO `wp_wfFileMods` VALUES ('O�+���������','wp-content/themes/gridster-lite/img/white-bg.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','u8k�Гl��y���');
INSERT INTO `wp_wfFileMods` VALUES ('�u�E�3\\�k�?���N','wp-content/themes/gridster-lite/inc/customizer.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��n�3���%Q�fSi');
INSERT INTO `wp_wfFileMods` VALUES ('�k��L8���o�i�`','wp-content/themes/gridster-lite/inc/defaults.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��� \Z����y]�');
INSERT INTO `wp_wfFileMods` VALUES ('������!*�����','wp-content/themes/gridster-lite/inc/extras.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�����v��A�1�');
INSERT INTO `wp_wfFileMods` VALUES ('ytD�b�|��M;{�','wp-content/themes/gridster-lite/inc/jetpack.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�{\r�\"t_��<Ӹ��');
INSERT INTO `wp_wfFileMods` VALUES ('��ɦї���K��','wp-content/themes/gridster-lite/inc/template-tags.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�r�C-�PX͗�Q�-�e');
INSERT INTO `wp_wfFileMods` VALUES ('���u\rVE�!��Ө��','wp-content/themes/gridster-lite/index.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','X+\\��sS&��5Y6');
INSERT INTO `wp_wfFileMods` VALUES ('���E�ۄ��쇨�4\"]','wp-content/themes/gridster-lite/js/customizer.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','T��>[�3F��M\\����');
INSERT INTO `wp_wfFileMods` VALUES ('��x�f=��$��:��','wp-content/themes/gridster-lite/js/keyboard-image-navigation.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���9����Z�o�(�n�');
INSERT INTO `wp_wfFileMods` VALUES ('��b7Q7�Q��T��P	c','wp-content/themes/gridster-lite/js/navigation.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','v�� z�֓/t\n��');
INSERT INTO `wp_wfFileMods` VALUES ('���l�dD���{�i','wp-content/themes/gridster-lite/js/skip-link-focus-fix.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���!E��fC�5');
INSERT INTO `wp_wfFileMods` VALUES ('�����Nط�Eqj','wp-content/themes/gridster-lite/languages/default.mo',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','7�)v���鸇�C~�8');
INSERT INTO `wp_wfFileMods` VALUES ('�ح����);��~��','wp-content/themes/gridster-lite/languages/default.po',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','k�^p�T�#���Z!�');
INSERT INTO `wp_wfFileMods` VALUES ('bi0B-��2+�d\\:A�','wp-content/themes/gridster-lite/license.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Mvxc���_C�@9�');
INSERT INTO `wp_wfFileMods` VALUES ('q�fΖ��2�f���','wp-content/themes/gridster-lite/no-results.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�.��(9ٷ���A�');
INSERT INTO `wp_wfFileMods` VALUES ('9�U�r��X����Pn�','wp-content/themes/gridster-lite/page.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��}q?�1���?/�l');
INSERT INTO `wp_wfFileMods` VALUES ('�Wϲ���V�֝�/','wp-content/themes/gridster-lite/readme.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Q>�5\"-b��7��');
INSERT INTO `wp_wfFileMods` VALUES ('\n�\\�q�\\?�\0w�{{�','wp-content/themes/gridster-lite/screenshot.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\0ٵ���19�Z�M�Ԟ');
INSERT INTO `wp_wfFileMods` VALUES ('��z\nr�����a','wp-content/themes/gridster-lite/search.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�iw�,X�2�`D`D');
INSERT INTO `wp_wfFileMods` VALUES ('�\\�׉{�8�,�&#��','wp-content/themes/gridster-lite/searchform.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��õ�ڢIۺI?���');
INSERT INTO `wp_wfFileMods` VALUES ('�-�0��1�������','wp-content/themes/gridster-lite/sidebar.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��q2��Ț�{9�');
INSERT INTO `wp_wfFileMods` VALUES ('�F�9���/��C�R��','wp-content/themes/gridster-lite/single.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�~�1�\0�0YG�n%�');
INSERT INTO `wp_wfFileMods` VALUES ('��*%Q��=\0G�/�v','wp-content/themes/gridster-lite/style.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','������6<������d');
INSERT INTO `wp_wfFileMods` VALUES ('����J�}F��E\0�9�','wp-content/themes/index.php',0,'gD,V�=\\�bP','gD,V�=\\�bP');
INSERT INTO `wp_wfFileMods` VALUES ('x�s�2����\"Z�U�®','wp-content/themes/twentyfifteen/404.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�� ��2�MD�$��');
INSERT INTO `wp_wfFileMods` VALUES ('�}��%J����g��z��','wp-content/themes/twentyfifteen/archive.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','[k�\"x�E�7@s}l�');
INSERT INTO `wp_wfFileMods` VALUES ('�|��\Z����:s�~�','wp-content/themes/twentyfifteen/author-bio.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','4�ԡR$)����wZO�');
INSERT INTO `wp_wfFileMods` VALUES ('\\�Jh\'�{���a�`_�','wp-content/themes/twentyfifteen/comments.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','R�ڢd��ɓ�GH��');
INSERT INTO `wp_wfFileMods` VALUES ('�2[��s�$��t�X[','wp-content/themes/twentyfifteen/content-link.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���F\'i�V�1��');
INSERT INTO `wp_wfFileMods` VALUES ('���`�䃽�eW�Y��','wp-content/themes/twentyfifteen/content-none.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��V��X+�1�');
INSERT INTO `wp_wfFileMods` VALUES (';�\"�C��ؘܳ� hc\Z','wp-content/themes/twentyfifteen/content-page.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�$zx���6ޓ�M#');
INSERT INTO `wp_wfFileMods` VALUES ('�^�K^�8v�8���','wp-content/themes/twentyfifteen/content-search.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�<CUy�Q�O���b�');
INSERT INTO `wp_wfFileMods` VALUES ('���v#�9���)?Ip�','wp-content/themes/twentyfifteen/content.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','?<h���>C��Bq��p');
INSERT INTO `wp_wfFileMods` VALUES ('J����0��\0���;','wp-content/themes/twentyfifteen/css/editor-style.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��&kB���O�Ql�*f');
INSERT INTO `wp_wfFileMods` VALUES ('���Ĭ+�����0','wp-content/themes/twentyfifteen/css/ie.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�l�g��IN�6���');
INSERT INTO `wp_wfFileMods` VALUES ('�l�d�՟�L�1u0','wp-content/themes/twentyfifteen/css/ie7.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','dh��=�[KM7��,��');
INSERT INTO `wp_wfFileMods` VALUES ('\0�ێx%�d\Z�kK](','wp-content/themes/twentyfifteen/footer.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','hYӠ�&��6�	���N');
INSERT INTO `wp_wfFileMods` VALUES ('��M�aN��`�:�,�','wp-content/themes/twentyfifteen/functions.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�O�B�g���#cֱ');
INSERT INTO `wp_wfFileMods` VALUES ('��\'_G���>��r-gʯ','wp-content/themes/twentyfifteen/genericons/COPYING.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�B;��a`GԢ�މ');
INSERT INTO `wp_wfFileMods` VALUES ('�����}�vϣ��G�','wp-content/themes/twentyfifteen/genericons/Genericons.eot',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','→��(��7k�j');
INSERT INTO `wp_wfFileMods` VALUES ('��J]����;�o*��P','wp-content/themes/twentyfifteen/genericons/Genericons.svg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','/�=³zeX*�|��b');
INSERT INTO `wp_wfFileMods` VALUES ('J9�?�+��Q�鴵�','wp-content/themes/twentyfifteen/genericons/Genericons.ttf',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�&tw�4�Љ�pc�$');
INSERT INTO `wp_wfFileMods` VALUES ('d�on�W>a������','wp-content/themes/twentyfifteen/genericons/Genericons.woff',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','s/��n]�d���z�?');
INSERT INTO `wp_wfFileMods` VALUES ('u��Q\"��~W����ð','wp-content/themes/twentyfifteen/genericons/LICENSE.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�4�Mi���Hj���JBc');
INSERT INTO `wp_wfFileMods` VALUES ('vlBT��[6��B�J�','wp-content/themes/twentyfifteen/genericons/README.md',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','u�9\nJ��La7Q��焑');
INSERT INTO `wp_wfFileMods` VALUES (':��X�&e��ͣ���','wp-content/themes/twentyfifteen/genericons/genericons.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ĥ��U�S��t�+�');
INSERT INTO `wp_wfFileMods` VALUES ('x.o\Z0L�u ϳ��','wp-content/themes/twentyfifteen/header.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���_KnO:X�X�0^�F');
INSERT INTO `wp_wfFileMods` VALUES ('�^��C�O��P�>�','wp-content/themes/twentyfifteen/image.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�{��I��<�<$���~');
INSERT INTO `wp_wfFileMods` VALUES ('�L$�@��]����%+X','wp-content/themes/twentyfifteen/inc/back-compat.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','a������� �[�`z');
INSERT INTO `wp_wfFileMods` VALUES ('��,���G� �:�0�/','wp-content/themes/twentyfifteen/inc/custom-header.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','7���Ҋ�F����v�');
INSERT INTO `wp_wfFileMods` VALUES ('*lX��KPqU','wp-content/themes/twentyfifteen/inc/customizer.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','׊Z�78���H�jii>G');
INSERT INTO `wp_wfFileMods` VALUES ('�a��qb�OaI�-�\r*','wp-content/themes/twentyfifteen/inc/template-tags.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��j?�\\c�K[�o');
INSERT INTO `wp_wfFileMods` VALUES ('q\0^�mvBsfC~�','wp-content/themes/twentyfifteen/index.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ɲb�ZK���K�W��:');
INSERT INTO `wp_wfFileMods` VALUES ('���@���N�� _n','wp-content/themes/twentyfifteen/js/color-scheme-control.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','g��O:�]ɏ���X��');
INSERT INTO `wp_wfFileMods` VALUES ('�Z�1h������N3�','wp-content/themes/twentyfifteen/js/customize-preview.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��t��?\r�J4��a�)');
INSERT INTO `wp_wfFileMods` VALUES ('��&��KG���)�','wp-content/themes/twentyfifteen/js/functions.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ߑ�xv(���=�m');
INSERT INTO `wp_wfFileMods` VALUES ('���WWՃo�m����e','wp-content/themes/twentyfifteen/js/html5.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\\�\"�ȶ��jȓ�P');
INSERT INTO `wp_wfFileMods` VALUES ('�koZ���z!/��f','wp-content/themes/twentyfifteen/js/keyboard-image-navigation.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�/�80r�\ro���');
INSERT INTO `wp_wfFileMods` VALUES ('����q𷞊�D��`','wp-content/themes/twentyfifteen/js/skip-link-focus-fix.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�t���>:{������');
INSERT INTO `wp_wfFileMods` VALUES ('3�kMf�9j��]�','wp-content/themes/twentyfifteen/languages/twentyfifteen.pot',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\ZȄΊ�j(ܨ���RF');
INSERT INTO `wp_wfFileMods` VALUES ('ײ2�D�ɻ&-u��	','wp-content/themes/twentyfifteen/page.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','B�5���^�\0�`�C�');
INSERT INTO `wp_wfFileMods` VALUES ('鍕��c�B�w!��W','wp-content/themes/twentyfifteen/readme.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ju���g6�6�');
INSERT INTO `wp_wfFileMods` VALUES ('5]���/����\r�','wp-content/themes/twentyfifteen/rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���fߏ���h��');
INSERT INTO `wp_wfFileMods` VALUES ('m����\Z�/�����','wp-content/themes/twentyfifteen/screenshot.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�(��� o���-\\');
INSERT INTO `wp_wfFileMods` VALUES ('\\��+5��¦DW\"�','wp-content/themes/twentyfifteen/search.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','>��\"7ў׉!�T\n�}�');
INSERT INTO `wp_wfFileMods` VALUES ('���\"\\��D�-\\gc�','wp-content/themes/twentyfifteen/sidebar.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��*�pz.9�{���S');
INSERT INTO `wp_wfFileMods` VALUES ('���x��Agm%����','wp-content/themes/twentyfifteen/single.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�lC�n���/���');
INSERT INTO `wp_wfFileMods` VALUES ('uv�՞(S5���훨','wp-content/themes/twentyfifteen/style.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Z����\r�P%���9�');
INSERT INTO `wp_wfFileMods` VALUES ('82NG�@|�M�8|\n','wp-content/themes/twentyfourteen/404.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��*<�S�\"��\n��s');
INSERT INTO `wp_wfFileMods` VALUES ('RB����eL��±�{�','wp-content/themes/twentyfourteen/archive.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���Z�C��J�+W');
INSERT INTO `wp_wfFileMods` VALUES ('�ii��B�e8.��8�','wp-content/themes/twentyfourteen/author.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','� �}z������Y');
INSERT INTO `wp_wfFileMods` VALUES ('ߖ/�2�Z��{�6��','wp-content/themes/twentyfourteen/category.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��Ȇ��@9�{���%=');
INSERT INTO `wp_wfFileMods` VALUES ('�jI�!W������*:G�','wp-content/themes/twentyfourteen/comments.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','.������_݇�X�');
INSERT INTO `wp_wfFileMods` VALUES ('�4B�i\01������>/�','wp-content/themes/twentyfourteen/content-aside.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�����y�*s�$�uR');
INSERT INTO `wp_wfFileMods` VALUES ('an�ܨ�5MgU{�','wp-content/themes/twentyfourteen/content-audio.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�gd��L#\\����|');
INSERT INTO `wp_wfFileMods` VALUES ('�!A���\rږ\r>�','wp-content/themes/twentyfourteen/content-featured-post.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','`��X�\'�gT\\d)�');
INSERT INTO `wp_wfFileMods` VALUES ('�+qK(�e�$k�\\���','wp-content/themes/twentyfourteen/content-gallery.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��&ΜQWƗ`��w');
INSERT INTO `wp_wfFileMods` VALUES ('��`Ƚ�c �)d��','wp-content/themes/twentyfourteen/content-image.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Ky#�$~� p��ǁ');
INSERT INTO `wp_wfFileMods` VALUES ('5��WB��$���l�','wp-content/themes/twentyfourteen/content-link.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','g%VҔэ����Ԫc�');
INSERT INTO `wp_wfFileMods` VALUES ('|�t|�Ay��\rA�����','wp-content/themes/twentyfourteen/content-none.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�	�]X&2��_');
INSERT INTO `wp_wfFileMods` VALUES ('�m��jg�.��P��','wp-content/themes/twentyfourteen/content-page.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','f��2\"�zYl�/���');
INSERT INTO `wp_wfFileMods` VALUES ('�=Fh3{DW}��!b��','wp-content/themes/twentyfourteen/content-quote.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�d���k��I�9<�');
INSERT INTO `wp_wfFileMods` VALUES ('QB��QP6*J̿��c;','wp-content/themes/twentyfourteen/content-video.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�_�9Nvt�(ܶ�.');
INSERT INTO `wp_wfFileMods` VALUES ('�b|Lv��_�7���E�','wp-content/themes/twentyfourteen/content.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���C���KZ��˳?�');
INSERT INTO `wp_wfFileMods` VALUES ('���6��9&�����R�','wp-content/themes/twentyfourteen/css/editor-style.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','x�S@��Ra�9���;�');
INSERT INTO `wp_wfFileMods` VALUES ('|;�?���1��2','wp-content/themes/twentyfourteen/css/ie.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ǎ?�n��Oj��eA');
INSERT INTO `wp_wfFileMods` VALUES ('\"�}�%��x�R:F���','wp-content/themes/twentyfourteen/featured-content.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Q� qϞ�2V���w');
INSERT INTO `wp_wfFileMods` VALUES ('��pX�I}����y�','wp-content/themes/twentyfourteen/footer.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��%���o���\'�');
INSERT INTO `wp_wfFileMods` VALUES ('�`1�����o��x','wp-content/themes/twentyfourteen/functions.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�4R���~N!�ǝ');
INSERT INTO `wp_wfFileMods` VALUES ('Lo�SX���9!r�4�','wp-content/themes/twentyfourteen/genericons/COPYING.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�B;��a`GԢ�މ');
INSERT INTO `wp_wfFileMods` VALUES ('��U�F ����Ԟ','wp-content/themes/twentyfourteen/genericons/Genericons-Regular.otf',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�1k��\ZN��+�>�');
INSERT INTO `wp_wfFileMods` VALUES ('�Ǩ�`�r�]���h','wp-content/themes/twentyfourteen/genericons/LICENSE.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�4�Mi���Hj���JBc');
INSERT INTO `wp_wfFileMods` VALUES ('��Y����1�؎$ɧ','wp-content/themes/twentyfourteen/genericons/README.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','I#\'y��F�@���d\"');
INSERT INTO `wp_wfFileMods` VALUES ('B�	t�#�{A��؝','wp-content/themes/twentyfourteen/genericons/example.html',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��[�\r#�%�UM�');
INSERT INTO `wp_wfFileMods` VALUES ('=g���<;��3��w�','wp-content/themes/twentyfourteen/genericons/font/genericons-regular-webfont.eot',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���r9�8e�z��`');
INSERT INTO `wp_wfFileMods` VALUES ('���|��U�C�D��h','wp-content/themes/twentyfourteen/genericons/font/genericons-regular-webfont.svg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�f���l����G{');
INSERT INTO `wp_wfFileMods` VALUES ('��*괶�Z�3�\\�f�','wp-content/themes/twentyfourteen/genericons/font/genericons-regular-webfont.ttf',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�?\'�� �K��>����');
INSERT INTO `wp_wfFileMods` VALUES ('���倽���ڊt�%�','wp-content/themes/twentyfourteen/genericons/font/genericons-regular-webfont.woff',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�z��g�Å��m~��v');
INSERT INTO `wp_wfFileMods` VALUES ('༗!>#�@��7W�\'','wp-content/themes/twentyfourteen/genericons/genericons.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���4b��-�+l��');
INSERT INTO `wp_wfFileMods` VALUES ('��Ȅ�7�g�b^I5','wp-content/themes/twentyfourteen/header.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','W�����i?T����');
INSERT INTO `wp_wfFileMods` VALUES ('\'��T��*<�=`�ӿ','wp-content/themes/twentyfourteen/image.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Ыp	�D����.r.');
INSERT INTO `wp_wfFileMods` VALUES ('�{fZ���ߥ���	�KQ','wp-content/themes/twentyfourteen/images/pattern-dark.svg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�E��[�.�t5��\0k');
INSERT INTO `wp_wfFileMods` VALUES ('�\rn8#Ô��9����|','wp-content/themes/twentyfourteen/images/pattern-light.svg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�i���Gp�j���Sݨ');
INSERT INTO `wp_wfFileMods` VALUES (',���1`Ц�q;�R|','wp-content/themes/twentyfourteen/inc/back-compat.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���]z4���f߮');
INSERT INTO `wp_wfFileMods` VALUES ('ޠ�����@w�c!�','wp-content/themes/twentyfourteen/inc/custom-header.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','c\0�<E6	��;�.*+');
INSERT INTO `wp_wfFileMods` VALUES ('���r��SXi��','wp-content/themes/twentyfourteen/inc/customizer.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�U�$�!��R��Y`��');
INSERT INTO `wp_wfFileMods` VALUES ('�գm��p��驍�9\n','wp-content/themes/twentyfourteen/inc/featured-content.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',';>55�H f��:\0S');
INSERT INTO `wp_wfFileMods` VALUES ('�\Zpr5>��#E���ĕ','wp-content/themes/twentyfourteen/inc/template-tags.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','t%d&���H,e\ZO');
INSERT INTO `wp_wfFileMods` VALUES ('��u��d*�oZ>��','wp-content/themes/twentyfourteen/inc/widgets.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����xD�Q�	Tz�J');
INSERT INTO `wp_wfFileMods` VALUES ('���\Z��NwVl��/̸','wp-content/themes/twentyfourteen/index.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','^���*�1�x��Ӷ#');
INSERT INTO `wp_wfFileMods` VALUES ('d#��u=k�f�\'�\0��','wp-content/themes/twentyfourteen/js/customizer.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�bp�_��[�r�$/��');
INSERT INTO `wp_wfFileMods` VALUES ('�\0� M�\\�5̿��c\0','wp-content/themes/twentyfourteen/js/featured-content-admin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\0���P�wp\"�LK6��');
INSERT INTO `wp_wfFileMods` VALUES ('���ť�X����Q��','wp-content/themes/twentyfourteen/js/functions.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��κP�ˋߥ�����');
INSERT INTO `wp_wfFileMods` VALUES ('��vPiZ޴8W����','wp-content/themes/twentyfourteen/js/html5.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Z��k\\���8F2Y�A');
INSERT INTO `wp_wfFileMods` VALUES ('z�S��ͬ�\\�/��','wp-content/themes/twentyfourteen/js/keyboard-image-navigation.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���?ft3��K%���\0');
INSERT INTO `wp_wfFileMods` VALUES ('C2}	��2��-�c��','wp-content/themes/twentyfourteen/js/slider.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�)�Cۤ\0G(�,��');
INSERT INTO `wp_wfFileMods` VALUES ('�w�i�hg$�����','wp-content/themes/twentyfourteen/languages/twentyfourteen.pot',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','X;[�ݳg<��}�');
INSERT INTO `wp_wfFileMods` VALUES ('oPZ\n�%�o2X!�\'^','wp-content/themes/twentyfourteen/page-templates/contributors.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','*��x/>7�e���C�');
INSERT INTO `wp_wfFileMods` VALUES ('���c���\'6z��I','wp-content/themes/twentyfourteen/page-templates/full-width.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Ce\"��m���\0o�s�');
INSERT INTO `wp_wfFileMods` VALUES ('�&�(�yf�\r��*KcA','wp-content/themes/twentyfourteen/page.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','M�;DjR�?���');
INSERT INTO `wp_wfFileMods` VALUES ('�;Μpne���^@�','wp-content/themes/twentyfourteen/rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','@����h3>�?i��');
INSERT INTO `wp_wfFileMods` VALUES ('[���uPE����x{�','wp-content/themes/twentyfourteen/screenshot.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��P��:�9L�$��=');
INSERT INTO `wp_wfFileMods` VALUES ('K�ߢ���,��S���G�','wp-content/themes/twentyfourteen/search.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Wfs�Cu�����`}���');
INSERT INTO `wp_wfFileMods` VALUES ('�s�\Z��Zt��c�	�','wp-content/themes/twentyfourteen/sidebar-content.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���ȃ$��\0DO��K');
INSERT INTO `wp_wfFileMods` VALUES ('/��\'�p�i20����	R','wp-content/themes/twentyfourteen/sidebar-footer.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��`��kt֙��|,6');
INSERT INTO `wp_wfFileMods` VALUES ('��Ҧ���$2�b�L�$','wp-content/themes/twentyfourteen/sidebar.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ORn�]&d�������n');
INSERT INTO `wp_wfFileMods` VALUES ('��R� N+`gVO��Z','wp-content/themes/twentyfourteen/single.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','N�OG(v!$�uL���a');
INSERT INTO `wp_wfFileMods` VALUES ('4\"^u�Yu�D��ۗCA#','wp-content/themes/twentyfourteen/style.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','1s�V\\�^j˗��');
INSERT INTO `wp_wfFileMods` VALUES ('$��������/��4�','wp-content/themes/twentyfourteen/tag.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��a,��\'Vɱ�J�E');
INSERT INTO `wp_wfFileMods` VALUES ('�ĝYE	���$��','wp-content/themes/twentyfourteen/taxonomy-post_format.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�.��\\+6��΁!��');
INSERT INTO `wp_wfFileMods` VALUES ('��j��)tP��@)�s','wp-content/themes/twentythirteen/404.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','SğR��$�yj�;��T');
INSERT INTO `wp_wfFileMods` VALUES ('���W{&�V8i\\V�','wp-content/themes/twentythirteen/archive.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���GKW�P�k�T�');
INSERT INTO `wp_wfFileMods` VALUES ('%N��k����<�m[�~','wp-content/themes/twentythirteen/author-bio.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�7�҄!�����!');
INSERT INTO `wp_wfFileMods` VALUES ('��*k\'l?,Wӟ�','wp-content/themes/twentythirteen/author.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�m㛖V������p;�');
INSERT INTO `wp_wfFileMods` VALUES ('�f�M%\"$�	����s�','wp-content/themes/twentythirteen/category.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','|N6$�Ծ񨕕ad\r');
INSERT INTO `wp_wfFileMods` VALUES ('���07�e�	�ӟ\n�','wp-content/themes/twentythirteen/comments.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���ɺ���庖�4');
INSERT INTO `wp_wfFileMods` VALUES ('�h���2M�	�25p�','wp-content/themes/twentythirteen/content-aside.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ر.����y���j��G�');
INSERT INTO `wp_wfFileMods` VALUES ('�r��I�!���','wp-content/themes/twentythirteen/content-audio.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�E���<cG���\r');
INSERT INTO `wp_wfFileMods` VALUES ('s�R����||(W�!�','wp-content/themes/twentythirteen/content-chat.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\"� �S>\Z3)�b�1�	');
INSERT INTO `wp_wfFileMods` VALUES ('����Sqf+�7r��','wp-content/themes/twentythirteen/content-gallery.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�,|�҈�9�@�$�');
INSERT INTO `wp_wfFileMods` VALUES (')|��;m8Z\rs�p','wp-content/themes/twentythirteen/content-image.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\\^�@��ms��x�');
INSERT INTO `wp_wfFileMods` VALUES ('j����&�\\�U���چ','wp-content/themes/twentythirteen/content-link.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�_�N�w����(9�w�');
INSERT INTO `wp_wfFileMods` VALUES ('��h���-���f:��-','wp-content/themes/twentythirteen/content-none.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�z~ŉ�_�-����\r');
INSERT INTO `wp_wfFileMods` VALUES ('�%�\\i\\j�?��x','wp-content/themes/twentythirteen/content-quote.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�;��R�W�k��l�ӗ');
INSERT INTO `wp_wfFileMods` VALUES ('�29�`�#0TR��|��','wp-content/themes/twentythirteen/content-status.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�:{�I0�b�L��K');
INSERT INTO `wp_wfFileMods` VALUES ('6H6�8�H�Yշ�(h','wp-content/themes/twentythirteen/content-video.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�xB��\r\Z�Αd\0L�');
INSERT INTO `wp_wfFileMods` VALUES ('�(��wփ������','wp-content/themes/twentythirteen/content.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','c��myb�/\"�s��');
INSERT INTO `wp_wfFileMods` VALUES ('�����>8������\\�','wp-content/themes/twentythirteen/css/editor-style.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�+�5q��Ͻr%D�E�');
INSERT INTO `wp_wfFileMods` VALUES ('�;�:ǝ\\�4t�YB�','wp-content/themes/twentythirteen/css/ie.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','/�-�tR��i.m����');
INSERT INTO `wp_wfFileMods` VALUES ('��Q����i��\n��','wp-content/themes/twentythirteen/footer.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�+��>>���ݪb��<');
INSERT INTO `wp_wfFileMods` VALUES ('�vn�\\��?<]h��','wp-content/themes/twentythirteen/functions.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','w�J@N�y��*��z�N');
INSERT INTO `wp_wfFileMods` VALUES ('�\Z���j>O9o���!\\)','wp-content/themes/twentythirteen/genericons/COPYING.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�B;��a`GԢ�މ');
INSERT INTO `wp_wfFileMods` VALUES ('�eO+ ]jq��t�\"]','wp-content/themes/twentythirteen/genericons/Genericons-Regular.otf',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�1k��\ZN��+�>�');
INSERT INTO `wp_wfFileMods` VALUES ('�}_0E��s�Ru֯��','wp-content/themes/twentythirteen/genericons/LICENSE.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�4�Mi���Hj���JBc');
INSERT INTO `wp_wfFileMods` VALUES ('�2��X��k�!�pd/','wp-content/themes/twentythirteen/genericons/README.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','I#\'y��F�@���d\"');
INSERT INTO `wp_wfFileMods` VALUES ('�?IhZq_��c�d�g�','wp-content/themes/twentythirteen/genericons/example.html',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��[�\r#�%�UM�');
INSERT INTO `wp_wfFileMods` VALUES ('8�\n1n�!QD���;��','wp-content/themes/twentythirteen/genericons/font/genericons-regular-webfont.eot',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���r9�8e�z��`');
INSERT INTO `wp_wfFileMods` VALUES ('���R�����~�y\Z��','wp-content/themes/twentythirteen/genericons/font/genericons-regular-webfont.svg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�f���l����G{');
INSERT INTO `wp_wfFileMods` VALUES ('өa�FG��5������','wp-content/themes/twentythirteen/genericons/font/genericons-regular-webfont.ttf',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�?\'�� �K��>����');
INSERT INTO `wp_wfFileMods` VALUES ('>E��$�\'n���F','wp-content/themes/twentythirteen/genericons/font/genericons-regular-webfont.woff',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�z��g�Å��m~��v');
INSERT INTO `wp_wfFileMods` VALUES ('ֳ)����vk�\'�\ry5','wp-content/themes/twentythirteen/genericons/genericons.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���4b��-�+l��');
INSERT INTO `wp_wfFileMods` VALUES ('��?Y~ rƵ|����P�','wp-content/themes/twentythirteen/header.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','|�8���y����y�Yw�');
INSERT INTO `wp_wfFileMods` VALUES ('�!3(^�ܣ�*�LmA C','wp-content/themes/twentythirteen/image.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','zP�B3f��ף�3');
INSERT INTO `wp_wfFileMods` VALUES ('}��������Đ$�','wp-content/themes/twentythirteen/images/dotted-line-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��vL����sFw��');
INSERT INTO `wp_wfFileMods` VALUES ('��ש)�׵�g8����','wp-content/themes/twentythirteen/images/dotted-line-light-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','<νq3x�wxr\\ 2');
INSERT INTO `wp_wfFileMods` VALUES ('4�@x�(�/Y��G}�','wp-content/themes/twentythirteen/images/dotted-line-light.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','3���<�(��{IW�');
INSERT INTO `wp_wfFileMods` VALUES ('Y�OT�����(��d','wp-content/themes/twentythirteen/images/dotted-line.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��l���8.���;Ւi�');
INSERT INTO `wp_wfFileMods` VALUES ('@�)�Vr�a�\'��\0c�','wp-content/themes/twentythirteen/images/headers/circle-thumbnail.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�0(��pCg^e����');
INSERT INTO `wp_wfFileMods` VALUES ('Vh�ޤ+F��4��','wp-content/themes/twentythirteen/images/headers/circle.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��IN��#�O\\/�}�');
INSERT INTO `wp_wfFileMods` VALUES ('�-�VW�igM4|\r�C�B','wp-content/themes/twentythirteen/images/headers/diamond-thumbnail.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','#�g�a���2��*�{');
INSERT INTO `wp_wfFileMods` VALUES ('�������L���m','wp-content/themes/twentythirteen/images/headers/diamond.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',':ɴ��� ���7');
INSERT INTO `wp_wfFileMods` VALUES ('5?���ׇRR|E^�f*','wp-content/themes/twentythirteen/images/headers/star-thumbnail.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','7����\n�ON�x\ZZC');
INSERT INTO `wp_wfFileMods` VALUES ('>�$\\Τ�ْa~A�','wp-content/themes/twentythirteen/images/headers/star.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���9�co56��Q`');
INSERT INTO `wp_wfFileMods` VALUES ('�@hզ���}���9�\r','wp-content/themes/twentythirteen/images/search-icon-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','uQ+��00��\\�5(��');
INSERT INTO `wp_wfFileMods` VALUES ('u����}���eu�ƽ0q','wp-content/themes/twentythirteen/images/search-icon.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','7�ώ=]�\0,U؈4���');
INSERT INTO `wp_wfFileMods` VALUES ('1�*���P	X�','wp-content/themes/twentythirteen/inc/back-compat.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ؕZ&bC�%m����');
INSERT INTO `wp_wfFileMods` VALUES ('��>�֔)��=U�','wp-content/themes/twentythirteen/inc/custom-header.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','큔g3F#������Q�');
INSERT INTO `wp_wfFileMods` VALUES ('*K���\rA\0�?�R>�','wp-content/themes/twentythirteen/index.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�^e�ܼ��2�͊\"Z');
INSERT INTO `wp_wfFileMods` VALUES ('R�W>��p�	\\��','wp-content/themes/twentythirteen/js/functions.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','4�O����ȳL�,�e');
INSERT INTO `wp_wfFileMods` VALUES ('���5�K�k�� ��B','wp-content/themes/twentythirteen/js/html5.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Z��k\\���8F2Y�A');
INSERT INTO `wp_wfFileMods` VALUES ('���ģ��0�4�\\�','wp-content/themes/twentythirteen/js/theme-customizer.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','7����5ESS$U9\Z��');
INSERT INTO `wp_wfFileMods` VALUES ('�̷i���Y	��8le�','wp-content/themes/twentythirteen/languages/twentythirteen.pot',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','7:\ZJx�몔Q��?	^');
INSERT INTO `wp_wfFileMods` VALUES ('�`����8�\"N�T�','wp-content/themes/twentythirteen/page.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����o�Gi��sn)m');
INSERT INTO `wp_wfFileMods` VALUES ('d���a\'�gCM~u��Nd','wp-content/themes/twentythirteen/rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','<�o�$k)���_-l');
INSERT INTO `wp_wfFileMods` VALUES ('^˨_���R�6��+6','wp-content/themes/twentythirteen/screenshot.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��C���a� �A�����');
INSERT INTO `wp_wfFileMods` VALUES ('k�T��Y���U.����','wp-content/themes/twentythirteen/search.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ÜA�d�pn���ļ�	+');
INSERT INTO `wp_wfFileMods` VALUES ('2u\0�]*qS���p�\\','wp-content/themes/twentythirteen/sidebar-main.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���X\"_�;�s/�*x');
INSERT INTO `wp_wfFileMods` VALUES ('��e~Q�8����F','wp-content/themes/twentythirteen/sidebar.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','n��K�+M�H%^g�');
INSERT INTO `wp_wfFileMods` VALUES ('��O��|<C��w�y��','wp-content/themes/twentythirteen/single.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','q4��:Dwxj��h*ޖ');
INSERT INTO `wp_wfFileMods` VALUES ('�\"�/Ƭκ�t�z���;','wp-content/themes/twentythirteen/style.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','hK:��l�Jv���');
INSERT INTO `wp_wfFileMods` VALUES ('��ΣBgĂ̎t�h%��','wp-content/themes/twentythirteen/tag.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��d�����L�R�');
INSERT INTO `wp_wfFileMods` VALUES ('Xk7���Am�uQD;�w','wp-content/themes/twentythirteen/taxonomy-post_format.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','.�&�֤rN�����');
INSERT INTO `wp_wfFileMods` VALUES ('j��T~Z�W�9�~�3�','wp-content/wfcache/GMAGIGOLO.COM_/~~~~_wfcache.html',0,'�).�ʫF].��~w','�).�ʫF].��~w');
INSERT INTO `wp_wfFileMods` VALUES ('\n��ҫ�c.I,h��$,','wp-content/wfcache/clear.lock',0,'��ُ\0��	���B~','��ُ\0��	���B~');
INSERT INTO `wp_wfFileMods` VALUES ('�&g1�Z���o�t���','wp-content/wfcache/gmagigolo.com_/~~~~_wfcache.html',0,'���MF0����8�8F��','���MF0����8�8F��');
INSERT INTO `wp_wfFileMods` VALUES ('�a�Oj\'�ŻD*ցV4','wp-cron.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����hc�����p�');
INSERT INTO `wp_wfFileMods` VALUES ('����v���ό�Y9�','wp-includes/ID3/getid3.lib.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����p�sQ�F����0');
INSERT INTO `wp_wfFileMods` VALUES ('d��:w���O�І','wp-includes/ID3/getid3.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\"�\nQ�Q.���b�o�');
INSERT INTO `wp_wfFileMods` VALUES ('9ՍҢ��9��d\r�Y','wp-includes/ID3/license.commercial.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�K�GD �.}�c�H3��');
INSERT INTO `wp_wfFileMods` VALUES ('}�Ȑ�\\L��`���i)','wp-includes/ID3/license.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','6�����jQ���#1�');
INSERT INTO `wp_wfFileMods` VALUES ('D.���:�\0��S�R8','wp-includes/ID3/module.audio-video.asf.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','A��H�!�0�� �s�W');
INSERT INTO `wp_wfFileMods` VALUES ('x	G!N�$�.�d�Tb�','wp-includes/ID3/module.audio-video.flv.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��ֈ?�d�h�@�D��');
INSERT INTO `wp_wfFileMods` VALUES ('�oҨ*K��o�7{� <','wp-includes/ID3/module.audio-video.matroska.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Y�!�Z0zDj&Cp�');
INSERT INTO `wp_wfFileMods` VALUES ('T���vm?,�a���T4�','wp-includes/ID3/module.audio-video.quicktime.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�U�`��f�.�0�F˼');
INSERT INTO `wp_wfFileMods` VALUES ('��\Zv�I:wm�\'~K-','wp-includes/ID3/module.audio-video.riff.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�TfbpGO�-�');
INSERT INTO `wp_wfFileMods` VALUES ('����L��6	���׳','wp-includes/ID3/module.audio.ac3.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�N��E�p:�A��Z��');
INSERT INTO `wp_wfFileMods` VALUES ('ǳ\\��_L-Y�Ō%$','wp-includes/ID3/module.audio.dts.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�lA��E��O87�$(');
INSERT INTO `wp_wfFileMods` VALUES ('@��+�T΄\'����٤','wp-includes/ID3/module.audio.flac.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��,�g�\0.���i�');
INSERT INTO `wp_wfFileMods` VALUES ('����N����@�(�3�','wp-includes/ID3/module.audio.mp3.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','#�\Z�~e�����J�8�');
INSERT INTO `wp_wfFileMods` VALUES (':�|L�H6(��c�g��','wp-includes/ID3/module.audio.ogg.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���v�N�5�O۬��');
INSERT INTO `wp_wfFileMods` VALUES ('�_)-�]�ˌkO	���','wp-includes/ID3/module.tag.apetag.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�7��l,�iwF�Q�ql');
INSERT INTO `wp_wfFileMods` VALUES ('���2zs��4x�EB','wp-includes/ID3/module.tag.id3v1.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��h؜�ٱal��w�4�');
INSERT INTO `wp_wfFileMods` VALUES (',���@��hj�qrޒ�','wp-includes/ID3/module.tag.id3v2.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','U[��,j�}jAؚ��c');
INSERT INTO `wp_wfFileMods` VALUES ('�?�8������Z��N�','wp-includes/ID3/module.tag.lyrics3.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�K�׬㑎��0�');
INSERT INTO `wp_wfFileMods` VALUES ('(~6vqV�0�{�\"','wp-includes/ID3/readme.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����Ɯ���VLN[�');
INSERT INTO `wp_wfFileMods` VALUES ('���k�5S�H���Ы','wp-includes/SimplePie/Author.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','4�q�_�A�%�Nw�1');
INSERT INTO `wp_wfFileMods` VALUES ('U�\\p{J��O�Q�&','wp-includes/SimplePie/Cache/Base.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�C�����2]�]#|j');
INSERT INTO `wp_wfFileMods` VALUES (',�hɃs?4B[�^՝','wp-includes/SimplePie/Cache/DB.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Y�OU���.�b���');
INSERT INTO `wp_wfFileMods` VALUES ('�����V,E@�X���y','wp-includes/SimplePie/Cache/File.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�=�@��B[	S�');
INSERT INTO `wp_wfFileMods` VALUES ('����I�:4P�U���','wp-includes/SimplePie/Cache/Memcache.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��JU���1SQ��?�');
INSERT INTO `wp_wfFileMods` VALUES ('<)8T*.�SuS�ĺ�','wp-includes/SimplePie/Cache/MySQL.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���B�C�\ZH�xV�');
INSERT INTO `wp_wfFileMods` VALUES ('Y֝��U����}�r/','wp-includes/SimplePie/Cache.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','y���:�oMh�vL�4');
INSERT INTO `wp_wfFileMods` VALUES ('���\"ܒ����nzD','wp-includes/SimplePie/Caption.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�����BjM��g[����');
INSERT INTO `wp_wfFileMods` VALUES ('���q�K�U�j��','wp-includes/SimplePie/Category.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�~��?��.\nܯd�*');
INSERT INTO `wp_wfFileMods` VALUES ('�l&�*�������&','wp-includes/SimplePie/Content/Type/Sniffer.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','|r��i�Ub�lw����3');
INSERT INTO `wp_wfFileMods` VALUES ('���an���V=Ty X�','wp-includes/SimplePie/Copyright.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��h�T��	Ù���j');
INSERT INTO `wp_wfFileMods` VALUES ('�o�ǣ�	ף�f0�Y','wp-includes/SimplePie/Core.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���#��������\Z�');
INSERT INTO `wp_wfFileMods` VALUES ('ͽ3��=��O�G�|~�','wp-includes/SimplePie/Credit.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��M猋*>\n�|');
INSERT INTO `wp_wfFileMods` VALUES ('���P�Of;���/��','wp-includes/SimplePie/Decode/HTML/Entities.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','E�^/�\rB���Z#�%/a');
INSERT INTO `wp_wfFileMods` VALUES ('2��^(��ʭ�-^x��','wp-includes/SimplePie/Enclosure.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','.�B�n΍K�s]');
INSERT INTO `wp_wfFileMods` VALUES ('�\nfv�8���1���-I','wp-includes/SimplePie/Exception.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','	K�v&���<\\ڏ�S5');
INSERT INTO `wp_wfFileMods` VALUES ('��4r�%����j���','wp-includes/SimplePie/File.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���kU�6�\n�+�)%�');
INSERT INTO `wp_wfFileMods` VALUES ('�Pط��悇̺ƴ$@�','wp-includes/SimplePie/HTTP/Parser.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','W%���4�6���6	');
INSERT INTO `wp_wfFileMods` VALUES ('oZ0�������<c�0','wp-includes/SimplePie/IRI.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','n� �憒�;a{�_6�');
INSERT INTO `wp_wfFileMods` VALUES ('f�����e��R�)�','wp-includes/SimplePie/Item.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','E�!�Cz�\0�c<ܧ');
INSERT INTO `wp_wfFileMods` VALUES ('�TB��O>�v2��}Ea','wp-includes/SimplePie/Locator.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�s����;�uvf^��');
INSERT INTO `wp_wfFileMods` VALUES ('FF�v��V;v�8/�\r��','wp-includes/SimplePie/Misc.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���y�-���^�\ZK�');
INSERT INTO `wp_wfFileMods` VALUES ('�Mj�A�M��O�\"If','wp-includes/SimplePie/Net/IPv6.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Fy!j�ـ�����');
INSERT INTO `wp_wfFileMods` VALUES ('�B��ه�v<Sv稳','wp-includes/SimplePie/Parse/Date.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\n2m0�H�����n\'`');
INSERT INTO `wp_wfFileMods` VALUES ('�tfF	�r{�܇�_I�x','wp-includes/SimplePie/Parser.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','R�.�b���~����+�');
INSERT INTO `wp_wfFileMods` VALUES ('d�hħ{q4�2�K\"�','wp-includes/SimplePie/Rating.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','=p�m	�K�دat�');
INSERT INTO `wp_wfFileMods` VALUES ('}�7 ޘ�DHD�Pl','wp-includes/SimplePie/Registry.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Ȣ����1v9�d\0�ٸ');
INSERT INTO `wp_wfFileMods` VALUES ('\0`Y�ϭrG����','wp-includes/SimplePie/Restriction.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','*qhd�s�;�y');
INSERT INTO `wp_wfFileMods` VALUES ('[���1�YAdk�,','wp-includes/SimplePie/Sanitize.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Bظ��F�إ�H��u');
INSERT INTO `wp_wfFileMods` VALUES ('��0l��j�0+%�','wp-includes/SimplePie/Source.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','������S{�*���');
INSERT INTO `wp_wfFileMods` VALUES ('��\'g!�:�H��),�','wp-includes/SimplePie/XML/Declaration/Parser.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���p(Å��B��s#b');
INSERT INTO `wp_wfFileMods` VALUES ('ZҌ�[��\nv���	F','wp-includes/SimplePie/gzdecode.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�8��a��al�4�');
INSERT INTO `wp_wfFileMods` VALUES ('O�hu�G���&\0�L�','wp-includes/Text/Diff/Engine/native.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\'*�����*�x');
INSERT INTO `wp_wfFileMods` VALUES ('ǂ-i)�.�\\���z�^a','wp-includes/Text/Diff/Engine/shell.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','u�Aܑ�~J�^t����');
INSERT INTO `wp_wfFileMods` VALUES ('� @�;��*��|��','wp-includes/Text/Diff/Engine/string.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','^��x@�R�ƙ=���');
INSERT INTO `wp_wfFileMods` VALUES ('e�^#|ۍ�TЩ��z','wp-includes/Text/Diff/Engine/xdiff.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ֹ�b�t�X8�GX');
INSERT INTO `wp_wfFileMods` VALUES ('&���Rw?~�j�hJ�D','wp-includes/Text/Diff/Renderer/inline.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\n�n5�P�����B\'�');
INSERT INTO `wp_wfFileMods` VALUES ('3��fQ3�h�5[��W�<','wp-includes/Text/Diff/Renderer.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����������菨)');
INSERT INTO `wp_wfFileMods` VALUES (']B#�2�z���bU��/','wp-includes/Text/Diff.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','%��gkj@b�%���\0�');
INSERT INTO `wp_wfFileMods` VALUES ('-kdϯ���X�w\\7���','wp-includes/admin-bar.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�.A�~E��L+,H[d�');
INSERT INTO `wp_wfFileMods` VALUES ('Gu�^�/1��ՁS�7','wp-includes/atomlib.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�e�.���[�\0\nf�A');
INSERT INTO `wp_wfFileMods` VALUES ('�&�S짿o�$��0�n','wp-includes/author-template.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','l�@Ñ�\r�P>�itz\0');
INSERT INTO `wp_wfFileMods` VALUES ('�>�s�l�WD7�M�','wp-includes/bookmark-template.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���!m<\r������O4');
INSERT INTO `wp_wfFileMods` VALUES ('��\0�>#����z(','wp-includes/bookmark.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���F��a*�s�<�7');
INSERT INTO `wp_wfFileMods` VALUES ('ǅ�9��9:���\Z�','wp-includes/cache.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','|��G�-��E���B�');
INSERT INTO `wp_wfFileMods` VALUES ('�2G�?�_��\\���-B','wp-includes/canonical.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','<!\n�4?ζ6�O�Q�');
INSERT INTO `wp_wfFileMods` VALUES ('��YC��o�oR�亞�','wp-includes/capabilities.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���+�!��L�	�\"�');
INSERT INTO `wp_wfFileMods` VALUES ('�j��I���<꟟��iU','wp-includes/category-template.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��v�uW����dai');
INSERT INTO `wp_wfFileMods` VALUES ('D��5\n\'�\\��~W��','wp-includes/category.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\'�*ˀ�j��5 e�');
INSERT INTO `wp_wfFileMods` VALUES ('mD��T�ms���A�}','wp-includes/certificates/ca-bundle.crt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��vǻ��!�o\n�f��o');
INSERT INTO `wp_wfFileMods` VALUES ('�J���y��0m�`�/','wp-includes/class-IXR.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','n�V�8��0�P\"yP_');
INSERT INTO `wp_wfFileMods` VALUES (':<�$��0,w\"&e({','wp-includes/class-feed.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','<��Byْ���');
INSERT INTO `wp_wfFileMods` VALUES ('!���@|�4��n���','wp-includes/class-http.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Qc.F��B�6�l��');
INSERT INTO `wp_wfFileMods` VALUES ('�&�Zh�$�Éo�','wp-includes/class-json.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','L�SA���̈́���%\Z');
INSERT INTO `wp_wfFileMods` VALUES ('��E����Q?��	(�','wp-includes/class-oembed.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','-fO������Ó�f��|');
INSERT INTO `wp_wfFileMods` VALUES ('	QW���~-�\0d�','wp-includes/class-phpass.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','#�FDP�\0\Z�f�G�Ƨ');
INSERT INTO `wp_wfFileMods` VALUES ('�8�ڧ��s}��ն�Ni','wp-includes/class-phpmailer.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','BqO7W��vai4c');
INSERT INTO `wp_wfFileMods` VALUES ('\"�����u>1�7���','wp-includes/class-pop3.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�K���S��|����/}');
INSERT INTO `wp_wfFileMods` VALUES ('��\\ ��Iѻ���,','wp-includes/class-simplepie.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Ys�r�	�m���D;��.');
INSERT INTO `wp_wfFileMods` VALUES ('��Κ,�Q�a�gl��\Z�','wp-includes/class-smtp.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��P�����ʄb�.');
INSERT INTO `wp_wfFileMods` VALUES ('e��__�%��x���','wp-includes/class-snoopy.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���mMz�Mr�;v��');
INSERT INTO `wp_wfFileMods` VALUES ('ֶ��9؞f�po3t','wp-includes/class-wp-admin-bar.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','YS�y�Ρ����Q��');
INSERT INTO `wp_wfFileMods` VALUES ('ֻE\n�<�B�[�,','wp-includes/class-wp-ajax-response.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','r6`0}�dmĂQ���\\�');
INSERT INTO `wp_wfFileMods` VALUES ('ȍP�� �3����\n��','wp-includes/class-wp-customize-control.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ͩ�t��!rl��{~');
INSERT INTO `wp_wfFileMods` VALUES ('h\ZOhl��_��Lm/�','wp-includes/class-wp-customize-manager.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','G����.��F���ά(');
INSERT INTO `wp_wfFileMods` VALUES ('\r�ҧxOz���z���h','wp-includes/class-wp-customize-panel.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����v�x~;)�]��l�');
INSERT INTO `wp_wfFileMods` VALUES ('��-x�(�E�oI�=�','wp-includes/class-wp-customize-section.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','!������	�pP~�');
INSERT INTO `wp_wfFileMods` VALUES ('f�u3\n�M\\�}6*0�','wp-includes/class-wp-customize-setting.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�=t��$Q����I');
INSERT INTO `wp_wfFileMods` VALUES ('�J��ёe�\rXd��$�','wp-includes/class-wp-customize-widgets.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','p�Ryǣ�K���9�ͯ');
INSERT INTO `wp_wfFileMods` VALUES ('��ɱ%��a{Z�j	%�','wp-includes/class-wp-editor.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','c�;~^$���w�');
INSERT INTO `wp_wfFileMods` VALUES ('5`�]\\ͭi\0���\ZJ�T','wp-includes/class-wp-embed.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�-�J7د�ŏ���,');
INSERT INTO `wp_wfFileMods` VALUES ('��k{��&��x\n��','wp-includes/class-wp-error.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','4ĸ\'��3��Bd\n���');
INSERT INTO `wp_wfFileMods` VALUES ('��u�X�ݼ#�-����','wp-includes/class-wp-http-ixr-client.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','tJr�P�?��bU��a');
INSERT INTO `wp_wfFileMods` VALUES ('>��X�\r�b��ڟ�$W','wp-includes/class-wp-image-editor-gd.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��3��\0P\0C6�o');
INSERT INTO `wp_wfFileMods` VALUES ('��^��bR��SI�!�?','wp-includes/class-wp-image-editor-imagick.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','P��,h2�԰�ڙ�2');
INSERT INTO `wp_wfFileMods` VALUES ('����T\n����e.(��','wp-includes/class-wp-image-editor.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��:T��Xd�L��ܕg');
INSERT INTO `wp_wfFileMods` VALUES ('�#�?���Gc	¯l1e','wp-includes/class-wp-theme.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�6���qߒAz`!�d');
INSERT INTO `wp_wfFileMods` VALUES ('\0��]�a�v���CY','wp-includes/class-wp-walker.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����W#�\'����m');
INSERT INTO `wp_wfFileMods` VALUES ('j�䱋����%���]�','wp-includes/class-wp-xmlrpc-server.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','WUT��W��r��͜');
INSERT INTO `wp_wfFileMods` VALUES ('$���C����/�9��','wp-includes/class-wp.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�iG!��Q�l�3nI%�');
INSERT INTO `wp_wfFileMods` VALUES ('y���E�a��:�[\0','wp-includes/class.wp-dependencies.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��T_[@j��j�\\?ou');
INSERT INTO `wp_wfFileMods` VALUES ('�����;~ӷR�>��','wp-includes/class.wp-scripts.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',';��\ns? Ei9{�w��');
INSERT INTO `wp_wfFileMods` VALUES ('9ψ[�1d{���@','wp-includes/class.wp-styles.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�4� �?�M�nI��t�');
INSERT INTO `wp_wfFileMods` VALUES ('=��k�[4��� ��=�','wp-includes/comment-template.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','$j���M6��Yb�x}Q');
INSERT INTO `wp_wfFileMods` VALUES ('�S����KK2iɈ','wp-includes/comment.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�I�D�ǅ<�}F�>UJ�');
INSERT INTO `wp_wfFileMods` VALUES ('�_\\c9mL�v��1���','wp-includes/compat.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ڲ@;h_�yu]�H���');
INSERT INTO `wp_wfFileMods` VALUES ('�-\"D��ʹD�5a�/','wp-includes/cron.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�b�.*�r�T:~�t��');
INSERT INTO `wp_wfFileMods` VALUES ('����=֬H�@-i��','wp-includes/css/admin-bar-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�u��`��\nL�&6;');
INSERT INTO `wp_wfFileMods` VALUES ('�{ڭd3T�Xy����7;','wp-includes/css/admin-bar-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�֥]��_C?��+]�.');
INSERT INTO `wp_wfFileMods` VALUES ('�Ȇp���]4��L��q�','wp-includes/css/admin-bar.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','U(X,�3tB��_');
INSERT INTO `wp_wfFileMods` VALUES ('�I\"�p��t�Q��[Z6x','wp-includes/css/admin-bar.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���mk�x�Hk�1q�W�');
INSERT INTO `wp_wfFileMods` VALUES ('t8����p�̋�z{jDp','wp-includes/css/buttons-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','1>�����:�z^��');
INSERT INTO `wp_wfFileMods` VALUES ('��Ul1�ȕD�bmg�','wp-includes/css/buttons-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\Z�z�e��=�\"�');
INSERT INTO `wp_wfFileMods` VALUES ('���;�^𩸴8c�','wp-includes/css/buttons.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��1R�1��!��\\=P�');
INSERT INTO `wp_wfFileMods` VALUES ('�з&�L۽¨��VN�','wp-includes/css/buttons.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','I@�3\r�#������');
INSERT INTO `wp_wfFileMods` VALUES ('��p��S��`�]T]D�','wp-includes/css/dashicons.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','}\0�c���\'ޒà�');
INSERT INTO `wp_wfFileMods` VALUES ('�L���yE�{��f�','wp-includes/css/dashicons.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','U�Y��V=}W(}�.N');
INSERT INTO `wp_wfFileMods` VALUES ('�po���X0%������','wp-includes/css/editor-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�u�]X)�*��﬋��');
INSERT INTO `wp_wfFileMods` VALUES ('ꍥ��2jEbg؈W�x�','wp-includes/css/editor-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','`�o��\"�K��PzJ��');
INSERT INTO `wp_wfFileMods` VALUES ('LsЇś\n�c}>�K��','wp-includes/css/editor.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','JE�0I	,l�95�y');
INSERT INTO `wp_wfFileMods` VALUES ('_�|��T�M^���J','wp-includes/css/editor.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����m-o>�q��');
INSERT INTO `wp_wfFileMods` VALUES (' ��c̫)I�\np,͑��','wp-includes/css/jquery-ui-dialog-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����7���ִ�F3');
INSERT INTO `wp_wfFileMods` VALUES ('~F��㫎>dy��j�','wp-includes/css/jquery-ui-dialog-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','2iy6�v���&]�2��');
INSERT INTO `wp_wfFileMods` VALUES ('i��PÙ��ld\0��','wp-includes/css/jquery-ui-dialog.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\n��d����\\6�');
INSERT INTO `wp_wfFileMods` VALUES ('@V�$�K���<�1*��','wp-includes/css/jquery-ui-dialog.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�(}��eB{xS	');
INSERT INTO `wp_wfFileMods` VALUES ('\05g���꫔c�0�\"D','wp-includes/css/media-views-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�X2q_�9�5VLT');
INSERT INTO `wp_wfFileMods` VALUES ('_�����8}���?�','wp-includes/css/media-views-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','t[kn�i�+�/���j�I');
INSERT INTO `wp_wfFileMods` VALUES ('��Sڰp��GMǯ�l�','wp-includes/css/media-views.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���[52*�6���V�\r');
INSERT INTO `wp_wfFileMods` VALUES ('4%�IH�O��ʰ�L','wp-includes/css/media-views.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\Z�w�0**�b6��Џ�');
INSERT INTO `wp_wfFileMods` VALUES ('Ǥ>z�Ԅ��!J]>','wp-includes/css/wp-auth-check-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����6&B���Kb�');
INSERT INTO `wp_wfFileMods` VALUES ('�Y$\'����o���','wp-includes/css/wp-auth-check-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Gn+��i�7\Z���b�$');
INSERT INTO `wp_wfFileMods` VALUES ('��,CUU����9i-','wp-includes/css/wp-auth-check.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�^�G7���_�h�Q�^');
INSERT INTO `wp_wfFileMods` VALUES ('Y�68�H;%,�_c\n�','wp-includes/css/wp-auth-check.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�`�4j@9��Y���\Z�');
INSERT INTO `wp_wfFileMods` VALUES ('\\[��i%Ͱ<��e�>�','wp-includes/css/wp-pointer-rtl.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��͆���\Zj_�L�J');
INSERT INTO `wp_wfFileMods` VALUES ('jQ���e���;�e','wp-includes/css/wp-pointer-rtl.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','l>SR1�i�Y�7��');
INSERT INTO `wp_wfFileMods` VALUES ('s�C4M�*��*B�)�','wp-includes/css/wp-pointer.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','=|t��r`�֖}|?�');
INSERT INTO `wp_wfFileMods` VALUES ('-��藂��Y{]ns�','wp-includes/css/wp-pointer.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ȡN�mH˟,3g\"��b');
INSERT INTO `wp_wfFileMods` VALUES ('�\0�����.}�fwA','wp-includes/date.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�u���<��OI');
INSERT INTO `wp_wfFileMods` VALUES ('}���{RҢ����\"','wp-includes/default-constants.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�j����vj�$��%��+');
INSERT INTO `wp_wfFileMods` VALUES ('��R�,�A���\Z�GJ\'-','wp-includes/default-filters.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',',}�\'�!��J�v�');
INSERT INTO `wp_wfFileMods` VALUES ('VL6�7G^l%D5z3��','wp-includes/default-widgets.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�%�ܴ�l�Z��)��');
INSERT INTO `wp_wfFileMods` VALUES ('p��.а��[ÍD�','wp-includes/deprecated.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��v��_�S��^Yv�');
INSERT INTO `wp_wfFileMods` VALUES ('���R֝�d��q�U��','wp-includes/error_log',0,'Z�e�O̥�&sPq.�-','Z�e�O̥�&sPq.�-');
INSERT INTO `wp_wfFileMods` VALUES ('\"����b9��e�|�_�','wp-includes/feed-atom-comments.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','c�D1;�)��-�B?6s');
INSERT INTO `wp_wfFileMods` VALUES ('����2@�k�w>K�2','wp-includes/feed-atom.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�q5B���4���D\nW');
INSERT INTO `wp_wfFileMods` VALUES ('�ȼ�؟�\'\r`����','wp-includes/feed-rdf.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�<C���H�,D\'��7i');
INSERT INTO `wp_wfFileMods` VALUES ('�])��	���{�?R}','wp-includes/feed-rss.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�kY���>�]DtH/');
INSERT INTO `wp_wfFileMods` VALUES ('��߲;��0����','wp-includes/feed-rss2-comments.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�<����7Uv9Q�7');
INSERT INTO `wp_wfFileMods` VALUES ('_*�⽞L�0�>\r','wp-includes/feed-rss2.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','A��`\'r}��b� QG');
INSERT INTO `wp_wfFileMods` VALUES ('{�RC��\Z�.*\"�Q','wp-includes/feed.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\\3!/���)Tj');
INSERT INTO `wp_wfFileMods` VALUES ('��\Z5o��#R\'/��l','wp-includes/fonts/dashicons.eot',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','΢6d����HD��Qك');
INSERT INTO `wp_wfFileMods` VALUES ('΢�S˪�\n��B�V\"','wp-includes/fonts/dashicons.svg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','~�)x䌉��[�w�');
INSERT INTO `wp_wfFileMods` VALUES ('���<kUJv%��1��','wp-includes/fonts/dashicons.ttf',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Ez{�C7|�2�');
INSERT INTO `wp_wfFileMods` VALUES ('��f0��ͭ��~�)','wp-includes/fonts/dashicons.woff',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','x�����a�\rI�~t~�');
INSERT INTO `wp_wfFileMods` VALUES ('�ŉ�	i����/Э','wp-includes/formatting.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��wSY�N�ڢ*�֗');
INSERT INTO `wp_wfFileMods` VALUES ('\Z������)qtsCI9','wp-includes/functions.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','}�Q��oNw�}\r��$7');
INSERT INTO `wp_wfFileMods` VALUES ('�b`K�\'��컜���K','wp-includes/functions.wp-scripts.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','x?!�bc�Q��*B36n');
INSERT INTO `wp_wfFileMods` VALUES ('h d��껅2��_�r','wp-includes/functions.wp-styles.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�|{�D�v��	��:B');
INSERT INTO `wp_wfFileMods` VALUES ('�0���R�J�{y�ˣ��','wp-includes/general-template.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�G;Y=.����T1!');
INSERT INTO `wp_wfFileMods` VALUES ('�/&�����2�ѡ\rgDs','wp-includes/http.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��w��$~�r�4T$');
INSERT INTO `wp_wfFileMods` VALUES ('.IhU���3��+B\Z��','wp-includes/images/admin-bar-sprite-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Q����8��o��');
INSERT INTO `wp_wfFileMods` VALUES ('��Ư	\'CԻ��ګ\Z','wp-includes/images/admin-bar-sprite.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','S���:�W����^');
INSERT INTO `wp_wfFileMods` VALUES ('r�_�/��HG=�%�<�','wp-includes/images/arrow-pointer-blue-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','%m�rތ]4�9c�');
INSERT INTO `wp_wfFileMods` VALUES ('@��̘9�#�L�y(��','wp-includes/images/arrow-pointer-blue.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','w��b�·*L���[��');
INSERT INTO `wp_wfFileMods` VALUES ('�G��5�@����07��','wp-includes/images/blank.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','H�+��51	��f]��9');
INSERT INTO `wp_wfFileMods` VALUES ('�>�M�8� ٵ��|','wp-includes/images/crystal/archive.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�S������I0An�');
INSERT INTO `wp_wfFileMods` VALUES ('�J\'#��rN�0a\r�','wp-includes/images/crystal/audio.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�nV�:�ω�G��-#k');
INSERT INTO `wp_wfFileMods` VALUES ('w���L��0���]r.','wp-includes/images/crystal/code.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','`�1������1�9');
INSERT INTO `wp_wfFileMods` VALUES ('����!ެ��߳���p','wp-includes/images/crystal/default.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','A�>)*/��!�-�');
INSERT INTO `wp_wfFileMods` VALUES ('Dm�\n��z�H��S���','wp-includes/images/crystal/document.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\'^c�s���D��3T\\');
INSERT INTO `wp_wfFileMods` VALUES ('j�����5F+���o','wp-includes/images/crystal/interactive.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�R�m`���`�9��');
INSERT INTO `wp_wfFileMods` VALUES ('�Ǌ�E�v�c,�صyS^','wp-includes/images/crystal/license.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�]�Lc�iG�fQ�\r��');
INSERT INTO `wp_wfFileMods` VALUES ('^�Ð����+�y|�','wp-includes/images/crystal/spreadsheet.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','5�9�Т1�T��n��');
INSERT INTO `wp_wfFileMods` VALUES ('�������\"�R�Ŝ','wp-includes/images/crystal/text.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�� Ѳ��#�d�%�[�');
INSERT INTO `wp_wfFileMods` VALUES ('U���$i\"u��&���9','wp-includes/images/crystal/video.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����l��ڤ�;�=');
INSERT INTO `wp_wfFileMods` VALUES ('*��-3�u��E�[�O#','wp-includes/images/down_arrow-2x.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�s���$�6(�@�a');
INSERT INTO `wp_wfFileMods` VALUES ('\n��O�_��;]/^��','wp-includes/images/down_arrow.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','e��]:u�Wv���\"��');
INSERT INTO `wp_wfFileMods` VALUES ('Ҟ����ǟ�	Ks���','wp-includes/images/icon-pointer-flag-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���2�b��&�Z�r');
INSERT INTO `wp_wfFileMods` VALUES ('�Z��	r!ޏf���	�','wp-includes/images/icon-pointer-flag.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��,���E^�j`\'');
INSERT INTO `wp_wfFileMods` VALUES ('Y�,�e�A��w�`���','wp-includes/images/media/archive.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','9����h�\0��ì�u');
INSERT INTO `wp_wfFileMods` VALUES (':�n̣RM�ti#��=','wp-includes/images/media/audio.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�taCA����.��Z��');
INSERT INTO `wp_wfFileMods` VALUES ('��3\"�(z�a�4�8�','wp-includes/images/media/code.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','-o��Uʓ��U�U_');
INSERT INTO `wp_wfFileMods` VALUES ('(?���>��S�N揚�&','wp-includes/images/media/default.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','-����I�B�h�@���b');
INSERT INTO `wp_wfFileMods` VALUES ('/<ا^ɼf}�\"���$�','wp-includes/images/media/document.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','v�4�8�Αy�6�d�');
INSERT INTO `wp_wfFileMods` VALUES ('�rY�S�xwDY˚J�[','wp-includes/images/media/interactive.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','R׬˂���ôŉh�H');
INSERT INTO `wp_wfFileMods` VALUES ('��HVե�d��p�Vp','wp-includes/images/media/spreadsheet.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���4���\0T��̇?�');
INSERT INTO `wp_wfFileMods` VALUES ('9��s�3�SZ,p�8g','wp-includes/images/media/text.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','z��s��0�ȝ�Q�K');
INSERT INTO `wp_wfFileMods` VALUES ('�\n%f[!aE�r�tg�i','wp-includes/images/media/video.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����u�h����q��');
INSERT INTO `wp_wfFileMods` VALUES ('�k��/y�����&��G','wp-includes/images/rss-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Ya[�Q�����rj�');
INSERT INTO `wp_wfFileMods` VALUES ('��r�����؁=�Ԓ�','wp-includes/images/rss.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��[�(�.��*NZ�');
INSERT INTO `wp_wfFileMods` VALUES ('{�\r�-��}�^��','wp-includes/images/smilies/frownie.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Q���������');
INSERT INTO `wp_wfFileMods` VALUES ('Т�펹�|����@','wp-includes/images/smilies/icon_arrow.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ʵ	�������(');
INSERT INTO `wp_wfFileMods` VALUES ('�㯩�	\'��ި��V','wp-includes/images/smilies/icon_biggrin.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�YpR�+�0}k�N{�k');
INSERT INTO `wp_wfFileMods` VALUES ('�$�͓�bHn��,\0-','wp-includes/images/smilies/icon_confused.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�sYFPZ6��,��');
INSERT INTO `wp_wfFileMods` VALUES ('X,�E�Cj$_��8I��0','wp-includes/images/smilies/icon_cool.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�F~��ߢ.���>t8');
INSERT INTO `wp_wfFileMods` VALUES ('ĔԼ���pP�Z	H��','wp-includes/images/smilies/icon_cry.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','E>z?��Ap�mWlA�`');
INSERT INTO `wp_wfFileMods` VALUES ('!_��輵p3p�n��L','wp-includes/images/smilies/icon_eek.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��_��s���jN��_z�');
INSERT INTO `wp_wfFileMods` VALUES ('�Obc��\" ���|J(','wp-includes/images/smilies/icon_evil.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','c����VM<�\"!�.');
INSERT INTO `wp_wfFileMods` VALUES ('�J��B�GT�;,l��T','wp-includes/images/smilies/icon_exclaim.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\\�qE�\Z!HY__=�{_�');
INSERT INTO `wp_wfFileMods` VALUES ('�\"u@��T��S��5�','wp-includes/images/smilies/icon_idea.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��\"m%h�����S��r�');
INSERT INTO `wp_wfFileMods` VALUES ('� �n�$��q��^qf��','wp-includes/images/smilies/icon_lol.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��M�Z8|����,���');
INSERT INTO `wp_wfFileMods` VALUES ('�(���ה�W�h@=a','wp-includes/images/smilies/icon_mad.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','׾�ie\Zc�{��0');
INSERT INTO `wp_wfFileMods` VALUES ('\Z�UE�s(���#E�p','wp-includes/images/smilies/icon_mrgreen.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���J����Rw��w��');
INSERT INTO `wp_wfFileMods` VALUES ('���k��i��.���\\��','wp-includes/images/smilies/icon_neutral.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','������	����Z�');
INSERT INTO `wp_wfFileMods` VALUES ('���7�M3�$��','wp-includes/images/smilies/icon_question.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\'u��&E�qA���mN�');
INSERT INTO `wp_wfFileMods` VALUES ('�����:[&b�[�hY��','wp-includes/images/smilies/icon_razz.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��˭��=��J�@��');
INSERT INTO `wp_wfFileMods` VALUES ('$����0S\r�r���','wp-includes/images/smilies/icon_redface.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','m��A��R!4a');
INSERT INTO `wp_wfFileMods` VALUES ('��B]nȄ�8�7g��','wp-includes/images/smilies/icon_rolleyes.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Ȼ�_�Ҹ*>,\Z�\Z!j');
INSERT INTO `wp_wfFileMods` VALUES ('�H�����Pw��%8��','wp-includes/images/smilies/icon_sad.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\Z\'=��Oj�?�uA|��');
INSERT INTO `wp_wfFileMods` VALUES ('����e��97�aJS','wp-includes/images/smilies/icon_smile.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��G)ö��u��\\\nM');
INSERT INTO `wp_wfFileMods` VALUES (';�Wct���*+��Br�','wp-includes/images/smilies/icon_surprised.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',')�r�����i\r�^@8��');
INSERT INTO `wp_wfFileMods` VALUES ('��\\:��ڈ��)g,\\','wp-includes/images/smilies/icon_twisted.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','b���.�8\Z|`�Q�LF');
INSERT INTO `wp_wfFileMods` VALUES ('�8�������P5aĨ�	','wp-includes/images/smilies/icon_wink.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\ZO�Z���g9�4�');
INSERT INTO `wp_wfFileMods` VALUES ('g|y_�o4\"��X�N���','wp-includes/images/smilies/mrgreen.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','-5��^����J�j���');
INSERT INTO `wp_wfFileMods` VALUES ('�{��Y�\\�z錿�}c','wp-includes/images/smilies/rolleyes.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',' ���O�2�Ofݣi�');
INSERT INTO `wp_wfFileMods` VALUES ('��ջZml��4�ˮU','wp-includes/images/smilies/simple-smile.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�K��{��f�w�h');
INSERT INTO `wp_wfFileMods` VALUES ('}`��g\"P�2��V��','wp-includes/images/spinner-2x.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\\q��9)hdxR���]l');
INSERT INTO `wp_wfFileMods` VALUES (':�Xqݝ�J\\�5P�4','wp-includes/images/spinner.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����1c~\'�dv�vHq');
INSERT INTO `wp_wfFileMods` VALUES ('}ĉ=�t�����','wp-includes/images/toggle-arrow-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','F���\\����CDr�');
INSERT INTO `wp_wfFileMods` VALUES ('�ܵ[Ҳm%�6�S8:D','wp-includes/images/toggle-arrow.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��·�a��;�d��*�');
INSERT INTO `wp_wfFileMods` VALUES ('/鹠���ΰ1�iw��','wp-includes/images/uploader-icons-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���&-��O��Õ�~');
INSERT INTO `wp_wfFileMods` VALUES ('_���4�3���=��','wp-includes/images/uploader-icons.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��\\M�����m��');
INSERT INTO `wp_wfFileMods` VALUES ('�h�����FuQe� �','wp-includes/images/wlw/wp-comments.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','L�6]P����.s���');
INSERT INTO `wp_wfFileMods` VALUES ('����Pq-�t�@l�','wp-includes/images/wlw/wp-icon.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','1	�ʚ�7w3K��*');
INSERT INTO `wp_wfFileMods` VALUES ('�����6��b�g�>_�','wp-includes/images/wlw/wp-watermark.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',';��uMmܭD|�w���D');
INSERT INTO `wp_wfFileMods` VALUES ('�~����U�\"�&��','wp-includes/images/wpicons-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��n�V�o�$��Of~7');
INSERT INTO `wp_wfFileMods` VALUES ('g�$G\\��;�r���1X','wp-includes/images/wpicons.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','dS��uq��V_���a�');
INSERT INTO `wp_wfFileMods` VALUES ('�\rE��U���̈́��','wp-includes/images/wpspin-2x.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','}�3��Y�(�I��m');
INSERT INTO `wp_wfFileMods` VALUES ('R�x�4Mp@�9u\n֊ p','wp-includes/images/wpspin.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Nm�h����;\Z@��');
INSERT INTO `wp_wfFileMods` VALUES ('�N�\\�|�`*�,)@4','wp-includes/images/xit-2x.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��r�T��`��?J�/�');
INSERT INTO `wp_wfFileMods` VALUES ('���\n\\��ɶ.5���','wp-includes/images/xit.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�)�X��`1���H��');
INSERT INTO `wp_wfFileMods` VALUES ('|/ڒ�\0[*4��x��','wp-includes/js/admin-bar.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','3�o�\0�H�[�H');
INSERT INTO `wp_wfFileMods` VALUES ('MР\0�A���9Q�+��','wp-includes/js/admin-bar.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','x�Oas�{�-v\'�&#');
INSERT INTO `wp_wfFileMods` VALUES ('R3�Us�3��}T���','wp-includes/js/autosave.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','c�i|}f���C�S�/');
INSERT INTO `wp_wfFileMods` VALUES ('wu�l|��p��Q','wp-includes/js/autosave.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','.�,@��g�h/7');
INSERT INTO `wp_wfFileMods` VALUES ('PE۫�7r|oI�6��>','wp-includes/js/backbone.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���z�����)�b�');
INSERT INTO `wp_wfFileMods` VALUES ('��\np���Gnu:���','wp-includes/js/colorpicker.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��V g�����-�');
INSERT INTO `wp_wfFileMods` VALUES ('0���E\00���X�H','wp-includes/js/colorpicker.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','5\n���w�-g���:OH�');
INSERT INTO `wp_wfFileMods` VALUES ('pUy�a	�b��va�;�8','wp-includes/js/comment-reply.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\n�(e=N�(ZMV{�');
INSERT INTO `wp_wfFileMods` VALUES ('1��X�/�t60^Ҁ!�7','wp-includes/js/comment-reply.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���\Z~��i_');
INSERT INTO `wp_wfFileMods` VALUES ('bY�,��ϥY�r۝�;�','wp-includes/js/crop/cropper.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ky5�ni*M(��');
INSERT INTO `wp_wfFileMods` VALUES ('\r�%����%�yS�`�','wp-includes/js/crop/cropper.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����H.s�o����');
INSERT INTO `wp_wfFileMods` VALUES ('�(�|n���sARF�+','wp-includes/js/crop/marqueeHoriz.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�̮����;���Lo\n');
INSERT INTO `wp_wfFileMods` VALUES ('Z�\0��Y���� æfg','wp-includes/js/crop/marqueeVert.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����\0���9��R���');
INSERT INTO `wp_wfFileMods` VALUES ('�r�\\�j�����A$�','wp-includes/js/customize-base.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',']�0�g�\Z��ν����');
INSERT INTO `wp_wfFileMods` VALUES ('V\n��U`�_�5���8','wp-includes/js/customize-base.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','.��ҖX�`�5A');
INSERT INTO `wp_wfFileMods` VALUES ('�V}�P���m�/�|I*�','wp-includes/js/customize-loader.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','!0�&�q���\0�~�');
INSERT INTO `wp_wfFileMods` VALUES ('b�����Ҍ &�?�{','wp-includes/js/customize-loader.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����<�ܽL-�Im');
INSERT INTO `wp_wfFileMods` VALUES ('����x�Й�)DC��<','wp-includes/js/customize-models.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','� Һ�zCp�OE�a�V�');
INSERT INTO `wp_wfFileMods` VALUES ('\n��NNM��ۑ4;�p�4','wp-includes/js/customize-models.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','OK�.�q;�t��N�\n');
INSERT INTO `wp_wfFileMods` VALUES ('9�\r5\'X���>?�','wp-includes/js/customize-preview-widgets.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��z{�Y}q�y�ڴ�');
INSERT INTO `wp_wfFileMods` VALUES ('����9��r�Mԧ��','wp-includes/js/customize-preview-widgets.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Q~���6�a���');
INSERT INTO `wp_wfFileMods` VALUES ('�4���2�)A.;4�','wp-includes/js/customize-preview.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','C2������,ھ');
INSERT INTO `wp_wfFileMods` VALUES ('>ql�+�m�\05Ħ\"�^','wp-includes/js/customize-preview.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��%Hh�������\rT�');
INSERT INTO `wp_wfFileMods` VALUES ('QY��1�Tl��Vr<','wp-includes/js/customize-views.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��;�z��	�YM�#y�');
INSERT INTO `wp_wfFileMods` VALUES ('�Y^~5~��p�G-���','wp-includes/js/customize-views.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��_�\Z�%cݹ����');
INSERT INTO `wp_wfFileMods` VALUES ('��!�(t��<Թ','wp-includes/js/heartbeat.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','� �	�1�]�d*D�G');
INSERT INTO `wp_wfFileMods` VALUES ('�n97�I.O�ҝ޿�','wp-includes/js/heartbeat.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��톙�@��Cm');
INSERT INTO `wp_wfFileMods` VALUES ('�y�g��zaU\"�	XKG','wp-includes/js/hoverIntent.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ʳY�C��c�On�כ');
INSERT INTO `wp_wfFileMods` VALUES ('S.FȫA�j���(�:','wp-includes/js/hoverIntent.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�P\nޅL1A�Wb��\0');
INSERT INTO `wp_wfFileMods` VALUES ('���%bQ�bM<�x','wp-includes/js/imgareaselect/border-anim-h.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Z��,�ntZ^6�{Lp�4');
INSERT INTO `wp_wfFileMods` VALUES ('��F�\"��vh�$Lb��','wp-includes/js/imgareaselect/border-anim-v.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',' �z!�<�7������*�');
INSERT INTO `wp_wfFileMods` VALUES ('<F���Pz�22��~','wp-includes/js/imgareaselect/imgareaselect.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','}(��()��3���󵕯');
INSERT INTO `wp_wfFileMods` VALUES ('�8/B��$8���`m�','wp-includes/js/imgareaselect/jquery.imgareaselect.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','U���K(t���0���');
INSERT INTO `wp_wfFileMods` VALUES ('����ͤ6�\0/��k���','wp-includes/js/imgareaselect/jquery.imgareaselect.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\00ԺLB�wm#��wu�:');
INSERT INTO `wp_wfFileMods` VALUES ('SX+7��1?����-','wp-includes/js/jcrop/Jcrop.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Z��7e�����Q�%K');
INSERT INTO `wp_wfFileMods` VALUES ('�g�\"�}_�7����J5','wp-includes/js/jcrop/jquery.Jcrop.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','V̞��/K�x����');
INSERT INTO `wp_wfFileMods` VALUES ('T�.o@Ψ2�w�v��X�','wp-includes/js/jcrop/jquery.Jcrop.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','/a��Lru�4�\Z�');
INSERT INTO `wp_wfFileMods` VALUES ('v��ޣ��R�','wp-includes/js/jquery/jquery-migrate.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��7��5�X��QN�z');
INSERT INTO `wp_wfFileMods` VALUES ('�a�@o��\'��kb���','wp-includes/js/jquery/jquery-migrate.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Q+�\Z(0�BY�<�4:��');
INSERT INTO `wp_wfFileMods` VALUES ('��ʙ\0}��甠K��.�','wp-includes/js/jquery/jquery.color.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�-���E�G����>vJ');
INSERT INTO `wp_wfFileMods` VALUES ('v�Ҹ);�D��~J\"��q','wp-includes/js/jquery/jquery.form.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���.�,�+��\nq');
INSERT INTO `wp_wfFileMods` VALUES ('&=\Z�+t�\"�/k\'\n','wp-includes/js/jquery/jquery.form.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�À�s���E�VM�-�');
INSERT INTO `wp_wfFileMods` VALUES ('��P\Z��/���l%�','wp-includes/js/jquery/jquery.hotkeys.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','┃��&�݋\rFư��');
INSERT INTO `wp_wfFileMods` VALUES ('��-�p�lE���k�/�','wp-includes/js/jquery/jquery.hotkeys.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�S!}EU�\\b�g�h��=');
INSERT INTO `wp_wfFileMods` VALUES ('g#�,vM������:��','wp-includes/js/jquery/jquery.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','N*ht��(�#Y�(JC');
INSERT INTO `wp_wfFileMods` VALUES ('c,���[xޫ�3�\n�@','wp-includes/js/jquery/jquery.masonry.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�����R�(��e^');
INSERT INTO `wp_wfFileMods` VALUES ('{�)�4e4p:�fW�','wp-includes/js/jquery/jquery.query.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',';�Xz�ǰ����wC');
INSERT INTO `wp_wfFileMods` VALUES ('(��g%\0��4��l>��','wp-includes/js/jquery/jquery.schedule.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','&��T�k�f؞���');
INSERT INTO `wp_wfFileMods` VALUES ('qh�665�y|�=�?S	','wp-includes/js/jquery/jquery.serialize-object.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\\)������J�l<�\"');
INSERT INTO `wp_wfFileMods` VALUES ('�0<Ps��מH���22','wp-includes/js/jquery/jquery.table-hotkeys.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��֔#t�gP�g��');
INSERT INTO `wp_wfFileMods` VALUES ('򱠭��B�R�z��Y','wp-includes/js/jquery/jquery.table-hotkeys.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�o�go����~i�I	�');
INSERT INTO `wp_wfFileMods` VALUES ('mY����}ɽ��?','wp-includes/js/jquery/jquery.ui.touch-punch.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','L�m�Q4փ��]�');
INSERT INTO `wp_wfFileMods` VALUES ('Ƭ+\Z���I�d^i <\0','wp-includes/js/jquery/suggest.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�U�k�7*헸Hޞ');
INSERT INTO `wp_wfFileMods` VALUES ('�3��Ƈe�(ú9�','wp-includes/js/jquery/suggest.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','!����^�~k�ۥ��');
INSERT INTO `wp_wfFileMods` VALUES ('6٨	��:{�^D�','wp-includes/js/jquery/ui/accordion.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','asy��6�=�(�w��');
INSERT INTO `wp_wfFileMods` VALUES ('g�Ed��1��D}�����','wp-includes/js/jquery/ui/autocomplete.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���PصC��\Z8�zj�\\');
INSERT INTO `wp_wfFileMods` VALUES ('��]/~���q��XŎE','wp-includes/js/jquery/ui/button.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�~���B��h�F��Vml');
INSERT INTO `wp_wfFileMods` VALUES ('�%y�>}H�o���(6','wp-includes/js/jquery/ui/core.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',' Ms���\r�a���{');
INSERT INTO `wp_wfFileMods` VALUES ('@k/�����I�?T,','wp-includes/js/jquery/ui/datepicker.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','I�N�u��QA�+�');
INSERT INTO `wp_wfFileMods` VALUES ('F��e���}�(��','wp-includes/js/jquery/ui/dialog.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','$aV�{Ԅ��,�0');
INSERT INTO `wp_wfFileMods` VALUES ('p��7u�L�_{2Û�','wp-includes/js/jquery/ui/draggable.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','PV�d��@��Y��');
INSERT INTO `wp_wfFileMods` VALUES ('�z�������|�z�xv','wp-includes/js/jquery/ui/droppable.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\ZK\"q�H�d����~A�P');
INSERT INTO `wp_wfFileMods` VALUES ('&c�YD�#�P{+��','wp-includes/js/jquery/ui/effect-blind.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����<O�mA�_;OL');
INSERT INTO `wp_wfFileMods` VALUES ('��a5[4�5�Me�pC','wp-includes/js/jquery/ui/effect-bounce.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ؖ�0TQ�5����S');
INSERT INTO `wp_wfFileMods` VALUES ('��U���$�\\*�1^�S�','wp-includes/js/jquery/ui/effect-clip.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Ǔ�W�#�GZas');
INSERT INTO `wp_wfFileMods` VALUES ('�D\rh}�����!\n','wp-includes/js/jquery/ui/effect-drop.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','W�V��ǥ�Y��F2��');
INSERT INTO `wp_wfFileMods` VALUES ('ϊ=��X���bBz\' �','wp-includes/js/jquery/ui/effect-explode.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','`YU����Q}X�Q�0�');
INSERT INTO `wp_wfFileMods` VALUES ('����A�G,��<���','wp-includes/js/jquery/ui/effect-fade.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�o�OO_��;{r�5$m');
INSERT INTO `wp_wfFileMods` VALUES ('�P\0\'�0l���v�#J<','wp-includes/js/jquery/ui/effect-fold.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�6^�����<��DEl');
INSERT INTO `wp_wfFileMods` VALUES ('{�M��i�i2n��6�','wp-includes/js/jquery/ui/effect-highlight.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����*��øN���!');
INSERT INTO `wp_wfFileMods` VALUES ('����8`9��?Bb�Б','wp-includes/js/jquery/ui/effect-puff.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Iml�c�G�@�ȳ� �');
INSERT INTO `wp_wfFileMods` VALUES ('����8(\Z�j�Z]}','wp-includes/js/jquery/ui/effect-pulsate.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�&`������f��');
INSERT INTO `wp_wfFileMods` VALUES ('4;V��\'�/����f�','wp-includes/js/jquery/ui/effect-scale.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�}0e,)����+m�T');
INSERT INTO `wp_wfFileMods` VALUES ('���NVԱ��z�Z','wp-includes/js/jquery/ui/effect-shake.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\'JgV�̯\0�@p�');
INSERT INTO `wp_wfFileMods` VALUES ('��~�w`�5;F㮮','wp-includes/js/jquery/ui/effect-size.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',':I�k�C�*���]�');
INSERT INTO `wp_wfFileMods` VALUES ('Y����]���ŞI���','wp-includes/js/jquery/ui/effect-slide.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�#G_��MVژ�y�');
INSERT INTO `wp_wfFileMods` VALUES ('��l�.H|S���{��','wp-includes/js/jquery/ui/effect-transfer.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ި\0w}����n�');
INSERT INTO `wp_wfFileMods` VALUES ('�ݙ�P(���O\'E��e','wp-includes/js/jquery/ui/effect.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','A֢�pi��u+`�');
INSERT INTO `wp_wfFileMods` VALUES ('7�c�¢)��S�eb�','wp-includes/js/jquery/ui/menu.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\'�Y����-�9|�l�>�');
INSERT INTO `wp_wfFileMods` VALUES ('�����:x��=�}�','wp-includes/js/jquery/ui/mouse.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�8\']��!��Iٲ��');
INSERT INTO `wp_wfFileMods` VALUES ('nef���A@���R�?��','wp-includes/js/jquery/ui/position.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','}��{:�pKv�ht�');
INSERT INTO `wp_wfFileMods` VALUES ('=f�u�A><Th���@','wp-includes/js/jquery/ui/progressbar.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��C�{��˚q��t	�');
INSERT INTO `wp_wfFileMods` VALUES ('��-��i>bs��1�','wp-includes/js/jquery/ui/resizable.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','?�*��W�i�X㝶տ');
INSERT INTO `wp_wfFileMods` VALUES ('�v����\r���&X��','wp-includes/js/jquery/ui/selectable.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Q�\"�{�B�M���');
INSERT INTO `wp_wfFileMods` VALUES ('S0�־��K/17u���','wp-includes/js/jquery/ui/selectmenu.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�}�˪2�9Zhxi\"6�');
INSERT INTO `wp_wfFileMods` VALUES ('\\�����AV*籿','wp-includes/js/jquery/ui/slider.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','}	1l4�&��QW��L�');
INSERT INTO `wp_wfFileMods` VALUES ('m��-\Zm1�����w��','wp-includes/js/jquery/ui/sortable.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��Xw���k^�');
INSERT INTO `wp_wfFileMods` VALUES ('mE������\\�)��o�','wp-includes/js/jquery/ui/spinner.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ש�/k&HQ��;j��');
INSERT INTO `wp_wfFileMods` VALUES ('����(5�aH�yo,X�','wp-includes/js/jquery/ui/tabs.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�gUZ���D�����j�');
INSERT INTO `wp_wfFileMods` VALUES ('-�_��+��Yn��S','wp-includes/js/jquery/ui/tooltip.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�]G҃������@EQ');
INSERT INTO `wp_wfFileMods` VALUES ('�!&�i�)^�W���R�','wp-includes/js/jquery/ui/widget.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�5��~�%�]c\r���<');
INSERT INTO `wp_wfFileMods` VALUES ('*�\Z07ѥ1O���َ8','wp-includes/js/json2.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','t������uD�+�');
INSERT INTO `wp_wfFileMods` VALUES ('������)�(��<��','wp-includes/js/json2.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�A��`� �ȡ�@�');
INSERT INTO `wp_wfFileMods` VALUES ('������|� ��','wp-includes/js/masonry.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','iq}Eigo@���T��');
INSERT INTO `wp_wfFileMods` VALUES ('r��r�(J�g�(�y�t','wp-includes/js/mce-view.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',' ���W�0`��G̪摟');
INSERT INTO `wp_wfFileMods` VALUES ('���f�%u�P���','wp-includes/js/mce-view.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�O���p�?v�+�');
INSERT INTO `wp_wfFileMods` VALUES ('��{�0l(Ʋu9,wS�u','wp-includes/js/media-audiovideo.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ur�������F\'&�');
INSERT INTO `wp_wfFileMods` VALUES ('�GV\\z��#���!;��','wp-includes/js/media-audiovideo.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','A�#�Iu�n?���I�X');
INSERT INTO `wp_wfFileMods` VALUES ('�u�N���.A_�_�','wp-includes/js/media-editor.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',' ��w��\"Wl���c6');
INSERT INTO `wp_wfFileMods` VALUES ('	,��/Օ�!�gy�d','wp-includes/js/media-editor.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��$�m+�:xܔ��D');
INSERT INTO `wp_wfFileMods` VALUES ('R�\\SC�|ju�9��A','wp-includes/js/media-grid.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','<fl� � �~\\����');
INSERT INTO `wp_wfFileMods` VALUES ('�Y��R�Yi/��l@HX�','wp-includes/js/media-grid.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','L�R�G�zpȟ�n��K');
INSERT INTO `wp_wfFileMods` VALUES (')��_���J�����','wp-includes/js/media-models.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','.xd��#c�n�3{��');
INSERT INTO `wp_wfFileMods` VALUES ('�F� �GJ��B��s7�','wp-includes/js/media-models.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','u|z���kNئ��');
INSERT INTO `wp_wfFileMods` VALUES ('�ȉV?	��]�)A','wp-includes/js/media-views.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�@�<d4�z��1��');
INSERT INTO `wp_wfFileMods` VALUES ('����E�?��Юᾠ','wp-includes/js/media-views.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��ԣ~蜿���gį�');
INSERT INTO `wp_wfFileMods` VALUES ('���6�d��x�D��','wp-includes/js/mediaelement/background.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','p<e�K�c�\\c8�r~\0l');
INSERT INTO `wp_wfFileMods` VALUES ('\Z�e\r���j!^��	��','wp-includes/js/mediaelement/bigplay.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','qd6�=�Ҟk7�b�Rgj');
INSERT INTO `wp_wfFileMods` VALUES ('7��O+�����ǋ\'n','wp-includes/js/mediaelement/bigplay.svg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�	\rqm�^@$��ȍ\r');
INSERT INTO `wp_wfFileMods` VALUES ('��5��[,	j�(�ƪ�','wp-includes/js/mediaelement/controls.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','$�\"�Ӭ����?�Ȥ');
INSERT INTO `wp_wfFileMods` VALUES ('Gq�@����gm屪','wp-includes/js/mediaelement/controls.svg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','@�oZsm������ۊR�');
INSERT INTO `wp_wfFileMods` VALUES ('{��a�t�\n\">��S','wp-includes/js/mediaelement/flashmediaelement.swf',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�{�l9�N���	�');
INSERT INTO `wp_wfFileMods` VALUES ('��+�Ϳ�#Ft�EǍ7','wp-includes/js/mediaelement/froogaloop.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','*�B����#�D����');
INSERT INTO `wp_wfFileMods` VALUES ('�\' ��#s��߾U|','wp-includes/js/mediaelement/loading.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','v�&��B\"o�!e���');
INSERT INTO `wp_wfFileMods` VALUES ('�y���!�\0pZ�[A','wp-includes/js/mediaelement/mediaelement-and-player.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��5:���\0 vu�k�');
INSERT INTO `wp_wfFileMods` VALUES ('	?������q�uM','wp-includes/js/mediaelement/mediaelementplayer.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',',�ؗx�����[�}�');
INSERT INTO `wp_wfFileMods` VALUES (';�&�nb��i�ٷ�','wp-includes/js/mediaelement/silverlightmediaelement.xap',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�:�:=C\".K�|�n\0t�');
INSERT INTO `wp_wfFileMods` VALUES ('A�Z�哖̅L��(','wp-includes/js/mediaelement/skipback.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�m�0�E���k��o�HF');
INSERT INTO `wp_wfFileMods` VALUES ('����S�h���S�%Tz�','wp-includes/js/mediaelement/wp-mediaelement.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�ؒj�F�5ρ�acR�');
INSERT INTO `wp_wfFileMods` VALUES ('�D����]�|߼�$�','wp-includes/js/mediaelement/wp-mediaelement.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�8؟\"{�պ��u�Z');
INSERT INTO `wp_wfFileMods` VALUES ('6����X/��HL','wp-includes/js/mediaelement/wp-playlist.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ɘY8@v��\'ٿ�');
INSERT INTO `wp_wfFileMods` VALUES ('J��E[�7U��\Z�~','wp-includes/js/plupload/handlers.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��WPIʿ���F�Ug)');
INSERT INTO `wp_wfFileMods` VALUES ('��;(Xp`ҙ��pݷ','wp-includes/js/plupload/handlers.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�<�`a*6Y$�qpM�\\');
INSERT INTO `wp_wfFileMods` VALUES ('�V�ڮ����M��jӁ','wp-includes/js/plupload/license.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','u&\n�TI�z����+�');
INSERT INTO `wp_wfFileMods` VALUES ('�C�3�!0Q�o�J�e `','wp-includes/js/plupload/plupload.flash.swf',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����g�}F�9�\"�~S');
INSERT INTO `wp_wfFileMods` VALUES ('\"����c���9�&','wp-includes/js/plupload/plupload.full.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�I�6�G��\n�!:D');
INSERT INTO `wp_wfFileMods` VALUES (' �p(?Qn����a��Z','wp-includes/js/plupload/plupload.silverlight.xap',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','<RGPTmᳪ�o���');
INSERT INTO `wp_wfFileMods` VALUES ('5C�)\nWu�꽝/F�cK','wp-includes/js/plupload/wp-plupload.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','e��;�2�@_e��R|');
INSERT INTO `wp_wfFileMods` VALUES ('�L����e5x?e=�&','wp-includes/js/plupload/wp-plupload.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��S�y�,lf@�@');
INSERT INTO `wp_wfFileMods` VALUES ('�?�����h�����;','wp-includes/js/quicktags.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�#��:<���T��ʭ');
INSERT INTO `wp_wfFileMods` VALUES ('ߌ��(������2���','wp-includes/js/quicktags.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\rz\0�j��7%��\Z 4');
INSERT INTO `wp_wfFileMods` VALUES ('ˍ�G䯀oe���o�','wp-includes/js/shortcode.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','� z�>1���J�92�');
INSERT INTO `wp_wfFileMods` VALUES ('g��]bR%� Z��E�','wp-includes/js/shortcode.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�X2\0`y��L8�*�');
INSERT INTO `wp_wfFileMods` VALUES ('�O�r#���T�G��!','wp-includes/js/swfobject.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���,�I}p�e~2�q�');
INSERT INTO `wp_wfFileMods` VALUES ('��M�٦M�/`�','wp-includes/js/swfupload/handlers.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��Oۅ��߲�}�');
INSERT INTO `wp_wfFileMods` VALUES ('�`#��G�b�C��֊�','wp-includes/js/swfupload/handlers.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Y,k?�X�N�0G�;');
INSERT INTO `wp_wfFileMods` VALUES ('�\Z-��x7��(A�4���','wp-includes/js/swfupload/license.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��[�`�^�-�o�QWz');
INSERT INTO `wp_wfFileMods` VALUES ('�D=Jǅ/	6ރa�','wp-includes/js/swfupload/plugins/swfupload.cookies.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�~�\rڈ�k\\ 7̴��');
INSERT INTO `wp_wfFileMods` VALUES ('�l�XNEM�CgVsA:','wp-includes/js/swfupload/plugins/swfupload.queue.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�SR/�J��5�-v͏');
INSERT INTO `wp_wfFileMods` VALUES (',B�c���ԛZ�4Y','wp-includes/js/swfupload/plugins/swfupload.speed.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','AZ7��k���E`,*�s�');
INSERT INTO `wp_wfFileMods` VALUES ('��$�<@�Řa���c\"','wp-includes/js/swfupload/plugins/swfupload.swfobject.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','̵q�V7�T\\���s');
INSERT INTO `wp_wfFileMods` VALUES ('��$��xM1>�_8P\0','wp-includes/js/swfupload/swfupload.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�:�E%ρz���s~');
INSERT INTO `wp_wfFileMods` VALUES ('*t$�ߋv��n��s�','wp-includes/js/swfupload/swfupload.swf',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Z%�5�e,�r��HO');
INSERT INTO `wp_wfFileMods` VALUES ('��	1��А々�S:(','wp-includes/js/thickbox/loadingAnimation.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�\"h\r�c�����&�');
INSERT INTO `wp_wfFileMods` VALUES ('����t���Z�O\'� \n','wp-includes/js/thickbox/macFFBgHack.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Ȱg�W�,/u�');
INSERT INTO `wp_wfFileMods` VALUES ('�v{L�Jlō�Yz�`�(','wp-includes/js/thickbox/thickbox.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','%R��j��o�AYx�');
INSERT INTO `wp_wfFileMods` VALUES ('AE���[�`����','wp-includes/js/thickbox/thickbox.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���C�eR���wS�%');
INSERT INTO `wp_wfFileMods` VALUES ('9:��d�o\n��p`Ry��','wp-includes/js/tinymce/langs/wp-langs-en.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�f�tS�uc�.k�7a7');
INSERT INTO `wp_wfFileMods` VALUES ('�	v�O.�|ߤҵ�','wp-includes/js/tinymce/license.txt',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',']�t\"ٞ3��[�t�|');
INSERT INTO `wp_wfFileMods` VALUES ('�\n$z�X�`�1Bw','wp-includes/js/tinymce/plugins/charmap/plugin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','a���w��g��\\c�H�');
INSERT INTO `wp_wfFileMods` VALUES ('k���$6O��-N�x�','wp-includes/js/tinymce/plugins/charmap/plugin.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��c������ni�?K%');
INSERT INTO `wp_wfFileMods` VALUES ('Aa�@J������Ł�','wp-includes/js/tinymce/plugins/colorpicker/plugin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','f�{�\'sVnш�ӹ|�');
INSERT INTO `wp_wfFileMods` VALUES (',<�� �?C]�0A�','wp-includes/js/tinymce/plugins/colorpicker/plugin.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��(oT���R��a�');
INSERT INTO `wp_wfFileMods` VALUES ('HC���!���\"(�','wp-includes/js/tinymce/plugins/compat3x/css/dialog.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��͕�\0A��It�dH');
INSERT INTO `wp_wfFileMods` VALUES ('go�s�V�;����\n$','wp-includes/js/tinymce/plugins/compat3x/plugin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','=�\\�-����e���U');
INSERT INTO `wp_wfFileMods` VALUES ('0]�qK\'�f�x����','wp-includes/js/tinymce/plugins/compat3x/plugin.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','W����������r��');
INSERT INTO `wp_wfFileMods` VALUES ('�!��#��I|���F�','wp-includes/js/tinymce/plugins/directionality/plugin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','*��V���ʬ� Hy�');
INSERT INTO `wp_wfFileMods` VALUES ('&��]0W��\n)�=��','wp-includes/js/tinymce/plugins/directionality/plugin.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','`�W%<�:oJ��9�');
INSERT INTO `wp_wfFileMods` VALUES ('���P�w���0�h�9','wp-includes/js/tinymce/plugins/fullscreen/plugin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�x�2����]�D�yZC');
INSERT INTO `wp_wfFileMods` VALUES ('s�ŏU\'���e@�d�','wp-includes/js/tinymce/plugins/fullscreen/plugin.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�y�_1u�݇�bo�');
INSERT INTO `wp_wfFileMods` VALUES ('��\\9ã>���Iz4�c','wp-includes/js/tinymce/plugins/hr/plugin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��<�<{LU798�ۆ');
INSERT INTO `wp_wfFileMods` VALUES ('���v��\\Q���-��','wp-includes/js/tinymce/plugins/hr/plugin.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\\#%Z����,3�I�8�');
INSERT INTO `wp_wfFileMods` VALUES ('π�tGȩ�����D','wp-includes/js/tinymce/plugins/image/plugin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','?�r�J\0�3��\\�d�');
INSERT INTO `wp_wfFileMods` VALUES ('�	���Em[�����l�<','wp-includes/js/tinymce/plugins/image/plugin.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','N�6_�� ��N�#�\\');
INSERT INTO `wp_wfFileMods` VALUES ('!�R���p�nL�w�m7','wp-includes/js/tinymce/plugins/lists/plugin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��4,~I�i%E���[');
INSERT INTO `wp_wfFileMods` VALUES ('�J0����j�Yg�h�','wp-includes/js/tinymce/plugins/lists/plugin.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','k��1�����I���');
INSERT INTO `wp_wfFileMods` VALUES ('��d]\0F�mŲp�D','wp-includes/js/tinymce/plugins/media/moxieplayer.swf',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','NY�N�-���3Yj���');
INSERT INTO `wp_wfFileMods` VALUES ('`���;�\"�-���+~;','wp-includes/js/tinymce/plugins/media/plugin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','~�\"��ʧ�Z�¥v\n');
INSERT INTO `wp_wfFileMods` VALUES ('ƅ����|_�i/y��	','wp-includes/js/tinymce/plugins/media/plugin.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','z�/~.SM�6L�5\\');
INSERT INTO `wp_wfFileMods` VALUES ('�����ƪq�悳��','wp-includes/js/tinymce/plugins/paste/plugin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','6�BU@��8�<ba');
INSERT INTO `wp_wfFileMods` VALUES ('�,(�i7:^�^�#','wp-includes/js/tinymce/plugins/paste/plugin.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�)>�|�K*\ZbH�');
INSERT INTO `wp_wfFileMods` VALUES ('x덂��@}Y��i�+','wp-includes/js/tinymce/plugins/tabfocus/plugin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�j��dFЂ�\"Ex�');
INSERT INTO `wp_wfFileMods` VALUES ('��v���|�-��','wp-includes/js/tinymce/plugins/tabfocus/plugin.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���6������t��');
INSERT INTO `wp_wfFileMods` VALUES ('?]�P�.��1����2b','wp-includes/js/tinymce/plugins/textcolor/plugin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��ޔ\r��]|�z�');
INSERT INTO `wp_wfFileMods` VALUES ('͓�Y�36��l�Y��','wp-includes/js/tinymce/plugins/textcolor/plugin.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��\n�������}�W0�');
INSERT INTO `wp_wfFileMods` VALUES ('�G���!#h�9	��&','wp-includes/js/tinymce/plugins/wordpress/plugin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�6B���û�yם');
INSERT INTO `wp_wfFileMods` VALUES ('u��s��y6\'v,��=','wp-includes/js/tinymce/plugins/wordpress/plugin.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','&�Bf�\Z�n�`��');
INSERT INTO `wp_wfFileMods` VALUES ('. �\0_oE�]A�_�0PJ','wp-includes/js/tinymce/plugins/wpautoresize/plugin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','d�\0Xc�O�@p��%�');
INSERT INTO `wp_wfFileMods` VALUES ('��}���PÛ�P\\�\Z','wp-includes/js/tinymce/plugins/wpautoresize/plugin.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','VL��	�gS\'����i');
INSERT INTO `wp_wfFileMods` VALUES ('	P=N>��b\"j:~[Q{�','wp-includes/js/tinymce/plugins/wpdialogs/plugin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���[ߢ�9��Z�');
INSERT INTO `wp_wfFileMods` VALUES ('3���\'���RK�Bf�','wp-includes/js/tinymce/plugins/wpdialogs/plugin.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���G���7�(tt�@�');
INSERT INTO `wp_wfFileMods` VALUES ('<��u꿖\Zܜ��Y�^','wp-includes/js/tinymce/plugins/wpeditimage/plugin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�c<�{��!���o');
INSERT INTO `wp_wfFileMods` VALUES ('�6�<��C�﮿�V:(r','wp-includes/js/tinymce/plugins/wpeditimage/plugin.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���J¾U�a��g���');
INSERT INTO `wp_wfFileMods` VALUES ('��%�\0��z�f�N�pS','wp-includes/js/tinymce/plugins/wpemoji/plugin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','y2\0׳���<�r�');
INSERT INTO `wp_wfFileMods` VALUES ('�@��,�n\\���+k�','wp-includes/js/tinymce/plugins/wpemoji/plugin.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','|�,s�M������Pm');
INSERT INTO `wp_wfFileMods` VALUES ('{��P8���5x��-�','wp-includes/js/tinymce/plugins/wpfullscreen/plugin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','݃�r\\�+zJ���');
INSERT INTO `wp_wfFileMods` VALUES ('T^Ih�����Ύ���(','wp-includes/js/tinymce/plugins/wpfullscreen/plugin.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','v����W`?�I_����=');
INSERT INTO `wp_wfFileMods` VALUES ('u��3!pA�f�)R�M�','wp-includes/js/tinymce/plugins/wpgallery/plugin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���A�#j�d�&�S�');
INSERT INTO `wp_wfFileMods` VALUES ('�Oӿ�;�=\\J�zy','wp-includes/js/tinymce/plugins/wpgallery/plugin.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�)F.jT&����I�O');
INSERT INTO `wp_wfFileMods` VALUES ('k����b��gS�','wp-includes/js/tinymce/plugins/wplink/plugin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���`�{WﺾUi\'w');
INSERT INTO `wp_wfFileMods` VALUES ('L��)��a$�D-�Ӯ�J','wp-includes/js/tinymce/plugins/wplink/plugin.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�.\"C��b>��K�\\�');
INSERT INTO `wp_wfFileMods` VALUES ('��q�82��v�&#M','wp-includes/js/tinymce/plugins/wpview/plugin.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','q������Xv�r&�`');
INSERT INTO `wp_wfFileMods` VALUES ('Wl��y:�\0Vn`�d\0�','wp-includes/js/tinymce/plugins/wpview/plugin.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�f둽�塴�;����');
INSERT INTO `wp_wfFileMods` VALUES ('�Z���(>(�1bޫ�Z�','wp-includes/js/tinymce/skins/lightgray/content.inline.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','[Θ|.zlˏ.�}լ');
INSERT INTO `wp_wfFileMods` VALUES ('����7�&��Ȁ','wp-includes/js/tinymce/skins/lightgray/content.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','oS�pZ5��Ǜ4�S�');
INSERT INTO `wp_wfFileMods` VALUES ('��(�[3?�H/�[�e]','wp-includes/js/tinymce/skins/lightgray/fonts/readme.md',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','zd��+���E@�1�');
INSERT INTO `wp_wfFileMods` VALUES ('��>�/ᡇ_�����','wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.eot',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�4 �\Z\\B�i�M銋');
INSERT INTO `wp_wfFileMods` VALUES (':�X��2�M���~��','wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.svg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','G6	=���<�%�#');
INSERT INTO `wp_wfFileMods` VALUES ('`���S�`NI�^G�','wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.ttf',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�a5Dn��r-m�@5P');
INSERT INTO `wp_wfFileMods` VALUES ('��t�0�g�a�/���','wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.woff',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�%���ցl R\n1�O�');
INSERT INTO `wp_wfFileMods` VALUES ('vڴ����V���K��P','wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.eot',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','P��6�_¸�f���');
INSERT INTO `wp_wfFileMods` VALUES ('�Q����ԁ�2�7u��L','wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.svg',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\r�f��W�)�˩��');
INSERT INTO `wp_wfFileMods` VALUES ('P��0��a��R�z= ','wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.ttf',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����\'�|hּk8ʙ');
INSERT INTO `wp_wfFileMods` VALUES ('�\Z���l����3Ȋ�','wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.woff',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���Ѕ�k��#M��');
INSERT INTO `wp_wfFileMods` VALUES ('������>+ܞL[�m','wp-includes/js/tinymce/skins/lightgray/img/anchor.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��a5q��ȑ_4�@');
INSERT INTO `wp_wfFileMods` VALUES ('L<#���\Z����}','wp-includes/js/tinymce/skins/lightgray/img/loader.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','9K���M�:�Tf�9');
INSERT INTO `wp_wfFileMods` VALUES ('oP��c����o�.�r','wp-includes/js/tinymce/skins/lightgray/img/object.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�rdP�E}u\n/M�A�� ');
INSERT INTO `wp_wfFileMods` VALUES ('�X����g5����(�=c','wp-includes/js/tinymce/skins/lightgray/img/trans.gif',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��7I �1F�Gu�j^');
INSERT INTO `wp_wfFileMods` VALUES ('�<{����,-�![M��','wp-includes/js/tinymce/skins/lightgray/skin.ie7.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���m_ҐsԥG');
INSERT INTO `wp_wfFileMods` VALUES ('��>�~�!�g�q��','wp-includes/js/tinymce/skins/lightgray/skin.min.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�-�uw*S������-�]');
INSERT INTO `wp_wfFileMods` VALUES ('Ĉ^A��+l���o�d��','wp-includes/js/tinymce/skins/wordpress/images/audio.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','7~!���\0�����\"w');
INSERT INTO `wp_wfFileMods` VALUES ('FH���30m�:��s��','wp-includes/js/tinymce/skins/wordpress/images/dashicon-edit.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','xR�	�Y�X���ݤ���');
INSERT INTO `wp_wfFileMods` VALUES ('��c��.D�r� |��','wp-includes/js/tinymce/skins/wordpress/images/dashicon-no.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','R����Z�?f.��8��	');
INSERT INTO `wp_wfFileMods` VALUES ('Ȅ���xy�����','wp-includes/js/tinymce/skins/wordpress/images/embedded.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����p�N��y~�n\"');
INSERT INTO `wp_wfFileMods` VALUES ('F���Ã\\�O�fg�','wp-includes/js/tinymce/skins/wordpress/images/gallery-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��1����v��R');
INSERT INTO `wp_wfFileMods` VALUES ('�_f��;w�a��ځ�','wp-includes/js/tinymce/skins/wordpress/images/gallery.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�_���Pw��PU�4');
INSERT INTO `wp_wfFileMods` VALUES ('F�Hȝl�e��#�','wp-includes/js/tinymce/skins/wordpress/images/more-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','l,��r�%�^x�%');
INSERT INTO `wp_wfFileMods` VALUES ('N�3�j@pu5����^��','wp-includes/js/tinymce/skins/wordpress/images/more.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����\n�\nm\0;�˫�z');
INSERT INTO `wp_wfFileMods` VALUES ('���~��a%��!�P','wp-includes/js/tinymce/skins/wordpress/images/pagebreak-2x.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','{�6�#UQ:��|>#��');
INSERT INTO `wp_wfFileMods` VALUES ('���#����	>�7','wp-includes/js/tinymce/skins/wordpress/images/pagebreak.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�I��m���LWyݓH');
INSERT INTO `wp_wfFileMods` VALUES ('��@��{�J��5䷴X','wp-includes/js/tinymce/skins/wordpress/images/playlist-audio.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','U,�:)��؋\"�QqY');
INSERT INTO `wp_wfFileMods` VALUES ('7�%Wy~׹P?�x��','wp-includes/js/tinymce/skins/wordpress/images/playlist-video.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�lzV6`wmZBs���');
INSERT INTO `wp_wfFileMods` VALUES ('�3^��PM�Y���H�D�','wp-includes/js/tinymce/skins/wordpress/images/video.png',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�¶��B�=\rz��3j�');
INSERT INTO `wp_wfFileMods` VALUES ('۪���	.�ո�\\���','wp-includes/js/tinymce/skins/wordpress/wp-content.css',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','ٞ�R��F1oj�3�X�');
INSERT INTO `wp_wfFileMods` VALUES ('r+zk;� 4��WI','wp-includes/js/tinymce/themes/modern/theme.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','<ڎ\'�,s�bP�;S�');
INSERT INTO `wp_wfFileMods` VALUES ('n#�t=�\'�����b]{�','wp-includes/js/tinymce/themes/modern/theme.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','VL]�����Tg2%\Z�');
INSERT INTO `wp_wfFileMods` VALUES ('�(tTlDά7&��MP.�','wp-includes/js/tinymce/tiny_mce_popup.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�B3�)7�{U�/�V');
INSERT INTO `wp_wfFileMods` VALUES ('	�9��fވU�f����','wp-includes/js/tinymce/tinymce.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�/ZV�9��N.{�Ћ');
INSERT INTO `wp_wfFileMods` VALUES ('Gm��:�MľV��LЉ','wp-includes/js/tinymce/utils/editable_selects.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','y��\0!�e�f��');
INSERT INTO `wp_wfFileMods` VALUES ('*���L�m&&2��\nb','wp-includes/js/tinymce/utils/form_utils.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�-�D{}��wk��k|');
INSERT INTO `wp_wfFileMods` VALUES ('츃�v��6��;�~�','wp-includes/js/tinymce/utils/mctabs.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�x$��\nd��,�P��');
INSERT INTO `wp_wfFileMods` VALUES ('4AI�n09��7c`','wp-includes/js/tinymce/utils/validate.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','hf�\n[�ٺ��V�}4');
INSERT INTO `wp_wfFileMods` VALUES ('If@n����;c>�8','wp-includes/js/tinymce/wp-mce-help.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','X�G;e�������Eq�\'');
INSERT INTO `wp_wfFileMods` VALUES ('�\'������}����0','wp-includes/js/tinymce/wp-tinymce.js.gz',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�}���M��3/��m\"');
INSERT INTO `wp_wfFileMods` VALUES ('�����HԹ��f�k�','wp-includes/js/tinymce/wp-tinymce.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�b\n��0pr���Hv');
INSERT INTO `wp_wfFileMods` VALUES ('p۞�2N<:Z�7�r�','wp-includes/js/tw-sack.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���������9>���');
INSERT INTO `wp_wfFileMods` VALUES ('����h+��B����','wp-includes/js/tw-sack.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���\'��7�ē��n�̄');
INSERT INTO `wp_wfFileMods` VALUES ('�鋭��{^�MU*�_','wp-includes/js/twemoji.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��37�[:.i Ĵ|t�');
INSERT INTO `wp_wfFileMods` VALUES ('M�;C�����8Yyﲏ','wp-includes/js/twemoji.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�|A\0^ֆl�,·MF');
INSERT INTO `wp_wfFileMods` VALUES ('�u��<e�x��@ֈ>','wp-includes/js/underscore.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�����T��Hk�zd..');
INSERT INTO `wp_wfFileMods` VALUES ('<�hj�	�4���4a�2�','wp-includes/js/utils.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�����o���o,Ê');
INSERT INTO `wp_wfFileMods` VALUES ('�&UX\r�L4{����','wp-includes/js/utils.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','A�9����!�;�	��x�');
INSERT INTO `wp_wfFileMods` VALUES ('�0��5��mk��','wp-includes/js/wp-a11y.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����z�L�u�Jg��k');
INSERT INTO `wp_wfFileMods` VALUES ('�/��0��\n*7�f(��','wp-includes/js/wp-a11y.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�9s�%o����V<4');
INSERT INTO `wp_wfFileMods` VALUES ('](R�&!��1;�3��','wp-includes/js/wp-ajax-response.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�#��#Pv�\\��p��');
INSERT INTO `wp_wfFileMods` VALUES ('u�)8FG9�C�(���','wp-includes/js/wp-ajax-response.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','bC;�s�{�K�');
INSERT INTO `wp_wfFileMods` VALUES ('��.��v8-rJŕ�qQ','wp-includes/js/wp-auth-check.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�����]k���Z!V');
INSERT INTO `wp_wfFileMods` VALUES ('tU�/Ds�Iڤ�st�','wp-includes/js/wp-auth-check.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','E�	�8��_oDdJy��s');
INSERT INTO `wp_wfFileMods` VALUES ('��j�8���ď�\Z���','wp-includes/js/wp-backbone.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���S��Y�|�פ�j)p');
INSERT INTO `wp_wfFileMods` VALUES ('0<�����lڿ��J��','wp-includes/js/wp-backbone.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�i���H.�^�V!');
INSERT INTO `wp_wfFileMods` VALUES ('�tr�εF_� ���','wp-includes/js/wp-emoji-loader.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Ԩ�?�WJ���F��');
INSERT INTO `wp_wfFileMods` VALUES (';����*1\Zn��4�','wp-includes/js/wp-emoji-loader.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','&�i��׽-}�_��{)l');
INSERT INTO `wp_wfFileMods` VALUES ('��	b���8�[����y','wp-includes/js/wp-emoji-release.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��)\'RL��N�IN�');
INSERT INTO `wp_wfFileMods` VALUES ('\0���;f��Q�=*Ǖ�','wp-includes/js/wp-emoji.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��\'��ٽ�, �[�');
INSERT INTO `wp_wfFileMods` VALUES ('[�>�x�;�wn/t�H','wp-includes/js/wp-emoji.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',':;���8�%G�/ws ');
INSERT INTO `wp_wfFileMods` VALUES ('���=V;�����N.K','wp-includes/js/wp-list-revisions.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','GQ\ru`�*�L��n$��');
INSERT INTO `wp_wfFileMods` VALUES ('E4��fu\r#R:k!jgh','wp-includes/js/wp-list-revisions.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��OBy��MK�/�l');
INSERT INTO `wp_wfFileMods` VALUES ('�bv��E��H���΄','wp-includes/js/wp-lists.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�L�.�+#/*إ�I08o');
INSERT INTO `wp_wfFileMods` VALUES ('�9�e�E��bݾl�3�','wp-includes/js/wp-lists.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�t|r��5��xŇ�ґ');
INSERT INTO `wp_wfFileMods` VALUES ('�#�AuI.F��/���','wp-includes/js/wp-pointer.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','5ˋ8�.�r:ě���');
INSERT INTO `wp_wfFileMods` VALUES ('�Ǉ���4˓T`�k','wp-includes/js/wp-pointer.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','6��|dMpX\0��fɐ�');
INSERT INTO `wp_wfFileMods` VALUES ('�??n������_2g��j','wp-includes/js/wp-util.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����\n��%;�I���');
INSERT INTO `wp_wfFileMods` VALUES ('H+�E~�}�1Q���','wp-includes/js/wp-util.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','9�f1��bQ\n�ʭ&2');
INSERT INTO `wp_wfFileMods` VALUES ('�A4e���{�^����Z','wp-includes/js/wpdialog.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','r�9_�M@9\0�S�����');
INSERT INTO `wp_wfFileMods` VALUES ('ߗ�Q��u�!ٶx�[','wp-includes/js/wpdialog.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�-���\0�g\r�Fġ�');
INSERT INTO `wp_wfFileMods` VALUES ('��wt�H���-s�\0�n','wp-includes/js/wplink.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','\\�$m��y�l�e���');
INSERT INTO `wp_wfFileMods` VALUES ('����\"�����c)j�\"','wp-includes/js/wplink.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','Μ�^g�o]Dq�`JMi');
INSERT INTO `wp_wfFileMods` VALUES ('���\'�B���7S�','wp-includes/js/zxcvbn-async.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','������\0�V]u#3');
INSERT INTO `wp_wfFileMods` VALUES ('L(���n�9[2�C6�','wp-includes/js/zxcvbn-async.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','1��p9	�9�~��');
INSERT INTO `wp_wfFileMods` VALUES ('J򾁬��Oh���sDؾ','wp-includes/js/zxcvbn.min.js',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�L�;��uc���<��');
INSERT INTO `wp_wfFileMods` VALUES ('��і�q��SGKy(�','wp-includes/kses.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�+�\\`��s�	');
INSERT INTO `wp_wfFileMods` VALUES ('���:m��[ݢ�:#','wp-includes/l10n.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','j��!K����s87[');
INSERT INTO `wp_wfFileMods` VALUES ('��v�E,�-O�{���','wp-includes/link-template.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','K\\�\\�i�/�:��I');
INSERT INTO `wp_wfFileMods` VALUES ('_j���_��/���yӱ','wp-includes/load.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�T�fuJ�\0�G�G0');
INSERT INTO `wp_wfFileMods` VALUES ('D6m�e�r{pK�O�','wp-includes/locale.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�N��~h]:�T�1��Q');
INSERT INTO `wp_wfFileMods` VALUES ('a�����(m�EB�l�','wp-includes/media-template.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','������K��Y�?�');
INSERT INTO `wp_wfFileMods` VALUES ('){�jW-_�Q=?�GlҢ','wp-includes/media.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�k&` ��C8�]:�t�');
INSERT INTO `wp_wfFileMods` VALUES ('�K�Q�}U&;&���Q','wp-includes/meta.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','}�؏�oS�Byy}�;�');
INSERT INTO `wp_wfFileMods` VALUES ('�g��I�!٭���_�','wp-includes/ms-blogs.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',',	�-�U{�%��	 �');
INSERT INTO `wp_wfFileMods` VALUES ('mA��Y�����Rb|�S�','wp-includes/ms-default-constants.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','NM�������9�b�%');
INSERT INTO `wp_wfFileMods` VALUES ('�.݁B��xK�Y�','wp-includes/ms-default-filters.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��ӱ���eu`�.@7');
INSERT INTO `wp_wfFileMods` VALUES ('�[�n�G{��\'��q:�','wp-includes/ms-deprecated.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','_Y+�W��+Ŗ Lp�');
INSERT INTO `wp_wfFileMods` VALUES ('뭷\r�!z}ML�K�E','wp-includes/ms-files.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',']�yï�<�r �L�F|');
INSERT INTO `wp_wfFileMods` VALUES ('�v%���S�[�̪�Ѿ','wp-includes/ms-functions.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��}�zn��GNpܯ�');
INSERT INTO `wp_wfFileMods` VALUES ('�_���jSX�2�QQ=','wp-includes/ms-load.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Ӎ�p�?k,�H��');
INSERT INTO `wp_wfFileMods` VALUES ('j&��^����b����','wp-includes/ms-settings.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��sv�ɂhz�*�e��');
INSERT INTO `wp_wfFileMods` VALUES ('��{A��mm��*�K','wp-includes/nav-menu-template.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��{y�E�-�2�Q�z�');
INSERT INTO `wp_wfFileMods` VALUES ('�[�Hn[P�.~���FU|','wp-includes/nav-menu.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','7h�ޝ�:޿�-�7');
INSERT INTO `wp_wfFileMods` VALUES ('�MR��l�B�F�u','wp-includes/option.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��!+��1,\r�����');
INSERT INTO `wp_wfFileMods` VALUES ('N|�Jв�zn��sw','wp-includes/pluggable-deprecated.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�۠���v�!l\"Ȥ�-');
INSERT INTO `wp_wfFileMods` VALUES ('h0X-�i����^�G`8','wp-includes/pluggable.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','N�Y�C��eF��H3��');
INSERT INTO `wp_wfFileMods` VALUES ('��\00��q�ĊNy)��','wp-includes/plugin.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','N�#���i�����');
INSERT INTO `wp_wfFileMods` VALUES ('� ��C�Y���','wp-includes/pomo/entry.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��}�L�ǼƢ�v�.');
INSERT INTO `wp_wfFileMods` VALUES ('48�Vt���+^X�','wp-includes/pomo/mo.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','z�h�^2�.��t��a');
INSERT INTO `wp_wfFileMods` VALUES ('��[K���b���28�','wp-includes/pomo/po.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','6+\0��n�_HSl��');
INSERT INTO `wp_wfFileMods` VALUES ('�1W;c�����N��\"�u','wp-includes/pomo/streams.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','q;�}���,ʠ����');
INSERT INTO `wp_wfFileMods` VALUES ('���?ڟ�E���$PF','wp-includes/pomo/translations.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�fWۥ�\"�\0Dwf��');
INSERT INTO `wp_wfFileMods` VALUES ('�a�tU�q�^!�0ƣl�','wp-includes/post-formats.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�M�ґ�VȔ$L;Cd�');
INSERT INTO `wp_wfFileMods` VALUES ('M���I�M����rD��-','wp-includes/post-template.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','b��\n�U\'���(�{�m�');
INSERT INTO `wp_wfFileMods` VALUES ('��iY����\0\nR)��','wp-includes/post-thumbnail-template.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','e�1L5R�\r��Y����');
INSERT INTO `wp_wfFileMods` VALUES ('���0j�l�S��K�','wp-includes/post.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','z/��4��+Zclc�iv[');
INSERT INTO `wp_wfFileMods` VALUES ('� �A$ۤfC�N��37','wp-includes/query.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',';�qN��\n��b��');
INSERT INTO `wp_wfFileMods` VALUES ('�E-j��1j��\r�E�','wp-includes/registration-functions.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','_?<���&T�xH�X�CL');
INSERT INTO `wp_wfFileMods` VALUES ('5\\h>��w	���N�','wp-includes/registration.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','q�ύH^�ܲ��I��i�');
INSERT INTO `wp_wfFileMods` VALUES ('_�\0��d �MP~��D','wp-includes/revision.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�{)8\'\'���8���u');
INSERT INTO `wp_wfFileMods` VALUES (')�Oz=�u����˷','wp-includes/rewrite.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��j˨�D��~^��T�');
INSERT INTO `wp_wfFileMods` VALUES ('���w��\'�6)','wp-includes/rss-functions.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','g�����l]�4j0l=�');
INSERT INTO `wp_wfFileMods` VALUES ('�����A���1\Z�;�','wp-includes/rss.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','VYhƤ�3����u	�');
INSERT INTO `wp_wfFileMods` VALUES ('9�} B^��?	�\"�','wp-includes/script-loader.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�<l\nԟW:L#㐢');
INSERT INTO `wp_wfFileMods` VALUES ('Eh���������@aq��','wp-includes/session.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',')|o�.;eX�+}N�');
INSERT INTO `wp_wfFileMods` VALUES ('Vne!�z0u1?��','wp-includes/shortcodes.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','(�+�#1m�ҫ�o�');
INSERT INTO `wp_wfFileMods` VALUES ('��X=U�pfp���Z','wp-includes/taxonomy.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���/���ِ��9J1');
INSERT INTO `wp_wfFileMods` VALUES ('�:+[��g��CZ���','wp-includes/template-loader.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','s�~ǹ��Q9�Zl�=�');
INSERT INTO `wp_wfFileMods` VALUES ('�:=�%�����M�۵','wp-includes/template.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','_���Q��G������');
INSERT INTO `wp_wfFileMods` VALUES ('��`��kYL_��h%\'','wp-includes/theme-compat/comments-popup.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','X�U/����aڌ.u<.');
INSERT INTO `wp_wfFileMods` VALUES ('>hЩ�XX*�v1���','wp-includes/theme-compat/comments.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�o�Q�K?G��}�1');
INSERT INTO `wp_wfFileMods` VALUES ('�Qֿ6��yq�88','wp-includes/theme-compat/footer.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','� ~C~�M������=');
INSERT INTO `wp_wfFileMods` VALUES ('L��bP�-I׭1f�','wp-includes/theme-compat/header.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�x������vY����');
INSERT INTO `wp_wfFileMods` VALUES ('�0�;�-,�A�Ey�','wp-includes/theme-compat/sidebar.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','>\Z���\"}Wuo���.H');
INSERT INTO `wp_wfFileMods` VALUES ('�X�VטO|8}���','wp-includes/theme.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','X�T�u�޷����<#O');
INSERT INTO `wp_wfFileMods` VALUES ('���+���q�pW��','wp-includes/update.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�_�W�\\F�D�$�,0');
INSERT INTO `wp_wfFileMods` VALUES ('k��B˞�b=y��','wp-includes/user.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Q��*�;\'�ep');
INSERT INTO `wp_wfFileMods` VALUES ('g+yr���q����D��/','wp-includes/vars.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���\'���8u���Ƶ8;');
INSERT INTO `wp_wfFileMods` VALUES ('5Z����Sμ�v�`6�9','wp-includes/version.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','-����@����S��');
INSERT INTO `wp_wfFileMods` VALUES ('S��&�az8�Jض9�','wp-includes/widgets.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Z6����̒��$2�p');
INSERT INTO `wp_wfFileMods` VALUES ('�@���sB0<�{l�3��','wp-includes/wlwmanifest.xml',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�Ԑ����i�^��');
INSERT INTO `wp_wfFileMods` VALUES ('L��e�t\"pc(	�e�','wp-includes/wp-db.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','����1�� ���q\\�j�');
INSERT INTO `wp_wfFileMods` VALUES ('(�^�3N������3','wp-includes/wp-diff.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','z{�&���Q����\"');
INSERT INTO `wp_wfFileMods` VALUES ('���^��\'�q���0��','wp-links-opml.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','�c���v��Il�mf�');
INSERT INTO `wp_wfFileMods` VALUES ('�$�����j�X�])D:','wp-load.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','!�i�A��>\'����ж�');
INSERT INTO `wp_wfFileMods` VALUES ('��\r\0FJ��B��e�','wp-login.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��Q�S��Y���st�');
INSERT INTO `wp_wfFileMods` VALUES ('��3�T.^�ƙ<���','wp-mail.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','��R:�߱5�$6��');
INSERT INTO `wp_wfFileMods` VALUES (';1ы#�Y_N��t�','wp-settings.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','� ���r(�l2}+��');
INSERT INTO `wp_wfFileMods` VALUES ('�,�4#��(�#','wp-signup.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','F���*�I\n�gF�t');
INSERT INTO `wp_wfFileMods` VALUES ('o㮚-�;?X:��pҡ','wp-trackback.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���.��d���#k�l');
INSERT INTO `wp_wfFileMods` VALUES ('4ڂ��L$�,K[�u��','xmlrpc.php',1,'\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0','���\Zu�w��nƻ1��');
/*!40000 ALTER TABLE `wp_wfFileMods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wfHits`
--

DROP TABLE IF EXISTS `wp_wfHits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wfHits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` double(17,6) unsigned NOT NULL,
  `IP` binary(16) DEFAULT NULL,
  `jsRun` tinyint(4) DEFAULT '0',
  `is404` tinyint(4) NOT NULL,
  `isGoogle` tinyint(4) NOT NULL,
  `userID` int(10) unsigned NOT NULL,
  `newVisit` tinyint(3) unsigned NOT NULL,
  `URL` text,
  `referer` text,
  `UA` text,
  PRIMARY KEY (`id`),
  KEY `k1` (`ctime`),
  KEY `k2` (`IP`,`ctime`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wfHits`
--

LOCK TABLES `wp_wfHits` WRITE;
/*!40000 ALTER TABLE `wp_wfHits` DISABLE KEYS */;
INSERT INTO `wp_wfHits` VALUES (1,1429155354.536268,'\0\0\0\0\0\0\0\0\0\0��k���',1,0,0,0,0,'http://gmagigolo.com/','','Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.101 Safari/537.36');
INSERT INTO `wp_wfHits` VALUES (2,1429155364.384938,'\0\0\0\0\0\0\0\0\0\0��k���',1,0,0,0,0,'http://gmagigolo.com/?page_id=2','http://gmagigolo.com/','Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.101 Safari/537.36');
/*!40000 ALTER TABLE `wp_wfHits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wfHoover`
--

DROP TABLE IF EXISTS `wp_wfHoover`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wfHoover` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `owner` text,
  `host` text,
  `path` text,
  `hostKey` binary(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `k2` (`hostKey`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wfHoover`
--

LOCK TABLES `wp_wfHoover` WRITE;
/*!40000 ALTER TABLE `wp_wfHoover` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wfHoover` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wfIssues`
--

DROP TABLE IF EXISTS `wp_wfIssues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wfIssues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `time` int(10) unsigned NOT NULL,
  `status` varchar(10) NOT NULL,
  `type` varchar(20) NOT NULL,
  `severity` tinyint(3) unsigned NOT NULL,
  `ignoreP` char(32) NOT NULL,
  `ignoreC` char(32) NOT NULL,
  `shortMsg` varchar(255) NOT NULL,
  `longMsg` text,
  `data` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1137 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wfIssues`
--

LOCK TABLES `wp_wfIssues` WRITE;
/*!40000 ALTER TABLE `wp_wfIssues` DISABLE KEYS */;
INSERT INTO `wp_wfIssues` VALUES (1134,1447498625,'new','wfThemeUpgrade',1,'51760651d9c159657045dbef3a1c781f','51760651d9c159657045dbef3a1c781f','The Theme \"Twenty Fifteen\" needs an upgrade.','You need to upgrade \"Twenty Fifteen\" to the newest version to ensure you have any security fixes the developer has released.','a:6:{s:10:\"newVersion\";s:3:\"1.3\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/theme/twentyfifteen.1.3.zip\";s:3:\"URL\";s:43:\"https://wordpress.org/themes/twentyfifteen/\";s:4:\"Name\";s:14:\"Twenty Fifteen\";s:4:\"name\";s:14:\"Twenty Fifteen\";s:7:\"version\";s:3:\"1.2\";}');
INSERT INTO `wp_wfIssues` VALUES (1135,1447498625,'new','wfThemeUpgrade',1,'927155500e44699b03182c3286f9e0ac','927155500e44699b03182c3286f9e0ac','The Theme \"Twenty Fourteen\" needs an upgrade.','You need to upgrade \"Twenty Fourteen\" to the newest version to ensure you have any security fixes the developer has released.','a:6:{s:10:\"newVersion\";s:3:\"1.5\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/theme/twentyfourteen.1.5.zip\";s:3:\"URL\";s:44:\"https://wordpress.org/themes/twentyfourteen/\";s:4:\"Name\";s:15:\"Twenty Fourteen\";s:4:\"name\";s:15:\"Twenty Fourteen\";s:7:\"version\";s:3:\"1.4\";}');
INSERT INTO `wp_wfIssues` VALUES (1136,1447498625,'new','wfThemeUpgrade',1,'1a9e8e264c2c05e50ab40526af689200','1a9e8e264c2c05e50ab40526af689200','The Theme \"Twenty Thirteen\" needs an upgrade.','You need to upgrade \"Twenty Thirteen\" to the newest version to ensure you have any security fixes the developer has released.','a:6:{s:10:\"newVersion\";s:3:\"1.6\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/theme/twentythirteen.1.6.zip\";s:3:\"URL\";s:44:\"https://wordpress.org/themes/twentythirteen/\";s:4:\"Name\";s:15:\"Twenty Thirteen\";s:4:\"name\";s:15:\"Twenty Thirteen\";s:7:\"version\";s:3:\"1.5\";}');
INSERT INTO `wp_wfIssues` VALUES (1131,1447498625,'new','wfUpgrade',1,'21fa0be0338b3c2b7d423f560e4af236','21fa0be0338b3c2b7d423f560e4af236','Your WordPress version is out of date','WordPress version 4.3.1 is now available. Please upgrade immediately to get the latest security updates from WordPress.','a:2:{s:14:\"currentVersion\";s:5:\"4.2.2\";s:10:\"newVersion\";s:5:\"4.3.1\";}');
INSERT INTO `wp_wfIssues` VALUES (1132,1447498625,'new','wfPluginUpgrade',1,'750ce549e231dceb44fe5add66086d7f','750ce549e231dceb44fe5add66086d7f','The Plugin \"Akismet\" needs an upgrade.','You need to upgrade \"Akismet\" to the newest version to ensure you have any security fixes the developer has released.','a:13:{s:4:\"Name\";s:7:\"Akismet\";s:9:\"PluginURI\";s:19:\"http://akismet.com/\";s:7:\"Version\";s:5:\"3.1.1\";s:11:\"Description\";s:516:\"Used by millions, Akismet is quite possibly the best way in the world to <strong>protect your blog from comment and trackback spam</strong>. It keeps your site protected from spam even while you sleep. To get started: 1) Click the &#8220;Activate&#8221; link to the left of this description, 2) <a href=\"http://akismet.com/get/\">Sign up for an Akismet API key</a>, and 3) Go to your Akismet configuration page, and save your API key. <cite>By <a href=\"http://automattic.com/wordpress-plugins/\">Automattic</a>.</cite>\";s:6:\"Author\";s:65:\"<a href=\"http://automattic.com/wordpress-plugins/\">Automattic</a>\";s:9:\"AuthorURI\";s:40:\"http://automattic.com/wordpress-plugins/\";s:10:\"TextDomain\";s:7:\"akismet\";s:10:\"DomainPath\";s:0:\"\";s:7:\"Network\";b:0;s:5:\"Title\";s:41:\"<a href=\"http://akismet.com/\">Akismet</a>\";s:10:\"AuthorName\";s:10:\"Automattic\";s:10:\"pluginFile\";s:66:\"/home/gmagigolo/public_html/wp-content/plugins/akismet/akismet.php\";s:10:\"newVersion\";s:5:\"3.1.5\";}');
INSERT INTO `wp_wfIssues` VALUES (1133,1447498625,'new','wfPluginUpgrade',1,'ca2e7fbbde76ce2229bd93ba312d7367','ca2e7fbbde76ce2229bd93ba312d7367','The Plugin \"iQ Block Country\" needs an upgrade.','You need to upgrade \"iQ Block Country\" to the newest version to ensure you have any security fixes the developer has released.','a:13:{s:4:\"Name\";s:16:\"iQ Block Country\";s:9:\"PluginURI\";s:79:\"http://www.redeo.nl/2013/12/iq-block-country-wordpress-plugin-blocks-countries/\";s:7:\"Version\";s:6:\"1.1.19\";s:11:\"Description\";s:266:\"Block visitors from visiting your website and backend website based on which country their IP address is from. The Maxmind GeoIP lite database is used for looking up from which country an ip address is from. <cite>By <a href=\"http://www.redeo.nl/\">Pascal</a>.</cite>\";s:6:\"Author\";s:41:\"<a href=\"http://www.redeo.nl/\">Pascal</a>\";s:9:\"AuthorURI\";s:20:\"http://www.redeo.nl/\";s:10:\"TextDomain\";s:0:\"\";s:10:\"DomainPath\";s:0:\"\";s:7:\"Network\";b:0;s:5:\"Title\";s:110:\"<a href=\"http://www.redeo.nl/2013/12/iq-block-country-wordpress-plugin-blocks-countries/\">iQ Block Country</a>\";s:10:\"AuthorName\";s:6:\"Pascal\";s:10:\"pluginFile\";s:84:\"/home/gmagigolo/public_html/wp-content/plugins/iq-block-country/iq-block-country.php\";s:10:\"newVersion\";s:6:\"1.1.23\";}');
/*!40000 ALTER TABLE `wp_wfIssues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wfLeechers`
--

DROP TABLE IF EXISTS `wp_wfLeechers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wfLeechers` (
  `eMin` int(10) unsigned NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hits` int(10) unsigned NOT NULL,
  PRIMARY KEY (`eMin`,`IP`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wfLeechers`
--

LOCK TABLES `wp_wfLeechers` WRITE;
/*!40000 ALTER TABLE `wp_wfLeechers` DISABLE KEYS */;
INSERT INTO `wp_wfLeechers` VALUES (24123972,'\0\0\0\0\0\0\0\0\0\0��C��',1);
INSERT INTO `wp_wfLeechers` VALUES (24123599,'\0\0\0\0\0\0\0\0\0\0��JR/',1);
INSERT INTO `wp_wfLeechers` VALUES (24122439,'\0\0\0\0\0\0\0\0\0\0��B��w',2);
INSERT INTO `wp_wfLeechers` VALUES (24124978,'\0\0\0\0\0\0\0\0\0\0��C��',1);
INSERT INTO `wp_wfLeechers` VALUES (24123318,'\0\0\0\0\0\0\0\0\0\0��C��',1);
INSERT INTO `wp_wfLeechers` VALUES (24122169,'\0\0\0\0\0\0\0\0\0\0��C��',1);
INSERT INTO `wp_wfLeechers` VALUES (24122002,'\0\0\0\0\0\0\0\0\0\0��JR/',1);
INSERT INTO `wp_wfLeechers` VALUES (24121940,'\0\0\0\0\0\0\0\0\0\0��C��',1);
INSERT INTO `wp_wfLeechers` VALUES (24124793,'\0\0\0\0\0\0\0\0\0\0���i��',1);
INSERT INTO `wp_wfLeechers` VALUES (24121706,'\0\0\0\0\0\0\0\0\0\0��C��',1);
INSERT INTO `wp_wfLeechers` VALUES (24124698,'\0\0\0\0\0\0\0\0\0\0��C��',1);
INSERT INTO `wp_wfLeechers` VALUES (24124437,'\0\0\0\0\0\0\0\0\0\0��C��',1);
INSERT INTO `wp_wfLeechers` VALUES (24123048,'\0\0\0\0\0\0\0\0\0\0��C��',1);
INSERT INTO `wp_wfLeechers` VALUES (24121422,'\0\0\0\0\0\0\0\0\0\0��C��',1);
INSERT INTO `wp_wfLeechers` VALUES (24122843,'\0\0\0\0\0\0\0\0\0\0��C��',1);
INSERT INTO `wp_wfLeechers` VALUES (24122553,'\0\0\0\0\0\0\0\0\0\0��C��',1);
INSERT INTO `wp_wfLeechers` VALUES (24124282,'\0\0\0\0\0\0\0\0\0\0��C��',4);
INSERT INTO `wp_wfLeechers` VALUES (24121117,'\0\0\0\0\0\0\0\0\0\0��C��',1);
/*!40000 ALTER TABLE `wp_wfLeechers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wfLockedOut`
--

DROP TABLE IF EXISTS `wp_wfLockedOut`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wfLockedOut` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `blockedTime` bigint(20) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `lastAttempt` int(10) unsigned DEFAULT '0',
  `blockedHits` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`IP`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wfLockedOut`
--

LOCK TABLES `wp_wfLockedOut` WRITE;
/*!40000 ALTER TABLE `wp_wfLockedOut` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wfLockedOut` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wfLocs`
--

DROP TABLE IF EXISTS `wp_wfLocs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wfLocs` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `ctime` int(10) unsigned NOT NULL,
  `failed` tinyint(3) unsigned NOT NULL,
  `city` varchar(255) DEFAULT '',
  `region` varchar(255) DEFAULT '',
  `countryName` varchar(255) DEFAULT '',
  `countryCode` char(2) DEFAULT '',
  `lat` float(10,7) DEFAULT '0.0000000',
  `lon` float(10,7) DEFAULT '0.0000000',
  PRIMARY KEY (`IP`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wfLocs`
--

LOCK TABLES `wp_wfLocs` WRITE;
/*!40000 ALTER TABLE `wp_wfLocs` DISABLE KEYS */;
INSERT INTO `wp_wfLocs` VALUES ('\0\0\0\0\0\0\0\0\0\0��C��',1447498627,0,'Lansing','Michigan','United States','US',42.7257004,-84.6360016);
/*!40000 ALTER TABLE `wp_wfLocs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wfLogins`
--

DROP TABLE IF EXISTS `wp_wfLogins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wfLogins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` double(17,6) unsigned NOT NULL,
  `fail` tinyint(3) unsigned NOT NULL,
  `action` varchar(40) NOT NULL,
  `username` varchar(255) NOT NULL,
  `userID` int(10) unsigned NOT NULL,
  `IP` binary(16) DEFAULT NULL,
  `UA` text,
  PRIMARY KEY (`id`),
  KEY `k1` (`IP`,`fail`)
) ENGINE=MyISAM AUTO_INCREMENT=575 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wfLogins`
--

LOCK TABLES `wp_wfLogins` WRITE;
/*!40000 ALTER TABLE `wp_wfLogins` DISABLE KEYS */;
INSERT INTO `wp_wfLogins` VALUES (1,1429155377.263741,0,'loginOK','trideon',1,'\0\0\0\0\0\0\0\0\0\0��k���','Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.101 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (2,1429157388.545563,0,'logout','trideon',1,'\0\0\0\0\0\0\0\0\0\0��k���','Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.101 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (3,1430151998.769482,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��.���','Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.0.2) Gecko/2008091620 Firefox/3.0.2');
INSERT INTO `wp_wfLogins` VALUES (4,1430156678.126120,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��.���','Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.0.2) Gecko/2008091620 Firefox/3.0.2');
INSERT INTO `wp_wfLogins` VALUES (5,1430157487.812104,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��.���','Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.0.2) Gecko/2008091620 Firefox/3.0.2');
INSERT INTO `wp_wfLogins` VALUES (6,1430159288.988869,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��.���','Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.0.2) Gecko/2008091620 Firefox/3.0.2');
INSERT INTO `wp_wfLogins` VALUES (7,1430159296.025834,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��.���','Mozilla/5.0 (Windows; U; Windows NT 5.1; ru; rv:1.9.0.2) Gecko/2008091620 Firefox/3.0.2');
INSERT INTO `wp_wfLogins` VALUES (8,1432289270.387692,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; rv:19.0) Gecko/20100101 Firefox/19.0');
INSERT INTO `wp_wfLogins` VALUES (9,1432733400.483632,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; rv:19.0) Gecko/20100101 Firefox/19.0');
INSERT INTO `wp_wfLogins` VALUES (10,1433481371.026748,0,'loginOK','trideon',1,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.3; WOW64; rv:38.0) Gecko/20100101 Firefox/38.0');
INSERT INTO `wp_wfLogins` VALUES (11,1433492654.277627,0,'logout','trideon',1,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.3; WOW64; rv:38.0) Gecko/20100101 Firefox/38.0');
INSERT INTO `wp_wfLogins` VALUES (12,1433492674.982545,0,'loginOK','trideon',1,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.3; WOW64; rv:38.0) Gecko/20100101 Firefox/38.0');
INSERT INTO `wp_wfLogins` VALUES (13,1433900673.605371,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; rv:19.0) Gecko/20100101 Firefox/19.0');
INSERT INTO `wp_wfLogins` VALUES (14,1433992381.305415,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; rv:19.0) Gecko/20100101 Firefox/19.0');
INSERT INTO `wp_wfLogins` VALUES (15,1436240410.480188,0,'loginOK','trideon',1,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Fedora; Linux x86_64; rv:37.0) Gecko/20100101 Firefox/37.0');
INSERT INTO `wp_wfLogins` VALUES (16,1440022037.757686,0,'loginOK','trideon',1,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Fedora; Linux x86_64; rv:39.0) Gecko/20100101 Firefox/39.0');
INSERT INTO `wp_wfLogins` VALUES (17,1440920434.154766,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (18,1440920437.406232,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (19,1440920440.719270,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (20,1440920443.945848,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (21,1440920447.178937,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (22,1440920450.389331,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (23,1440920453.600931,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (24,1440920456.816841,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (25,1440920460.036939,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (26,1440920463.251096,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (27,1440920466.475121,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (28,1440920469.755040,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (29,1440920472.964796,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (30,1440920476.179767,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (31,1440920479.393760,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (32,1440920482.607703,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (33,1440920485.820291,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (34,1440920489.033492,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (35,1440920492.253005,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (36,1440946551.120599,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (37,1440946568.781825,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (38,1440946568.787340,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (39,1440946571.958214,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (40,1440946574.402980,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (41,1440946575.160469,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (42,1440946578.603935,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (43,1440946581.816227,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (44,1440946585.033598,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (45,1440946588.233358,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (46,1440946591.433598,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (47,1440946594.638182,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (48,1440946597.842100,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (49,1440946601.047050,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (50,1440946604.250995,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (51,1440946608.457275,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (52,1440946612.667653,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (53,1440946615.878933,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (54,1440946619.083873,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (55,1440961028.247742,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (56,1440961031.887328,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (57,1440961035.373788,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (58,1440961038.853674,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (59,1440961043.349090,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (60,1440961046.878890,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (61,1440961050.374136,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (62,1440961054.849088,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (63,1440961059.338845,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (64,1440961063.850935,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (65,1440961068.339069,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (66,1440961071.843642,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (67,1440961076.340049,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (68,1440961079.824460,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (69,1440961084.331029,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (70,1440961087.844109,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (71,1440961094.343031,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (72,1440961097.842515,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (73,1440961101.348758,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (74,1440990647.048762,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (75,1440990650.632675,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (76,1440990654.164559,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (77,1440990657.700785,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (78,1440990661.229783,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (79,1440990664.647599,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (80,1440990668.052841,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (81,1440990671.876559,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (82,1440990675.396255,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (83,1440990678.904061,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (84,1440990682.432051,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (85,1440990685.825305,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (86,1440990689.353939,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (87,1440990692.908328,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (88,1440990696.306727,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (89,1440990699.705208,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (90,1440990703.106603,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (91,1440990706.594494,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (92,1440990709.990942,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','');
INSERT INTO `wp_wfLogins` VALUES (93,1443464054.864946,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (94,1443467507.081765,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (95,1443471118.822734,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (96,1443472900.656999,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (97,1443474530.387305,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (98,1443476240.348806,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (99,1443479755.090188,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (100,1443481499.225189,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (101,1443483280.337372,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (102,1443484916.248737,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (103,1443486672.456057,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (104,1443488382.995364,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (105,1443491706.379122,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (106,1443493506.187553,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (107,1443495245.045035,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (108,1443497074.638824,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (109,1443498908.795980,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (110,1443500654.019125,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (111,1443502346.657873,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (112,1443505747.354058,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (113,1443803821.128918,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (114,1443807468.472367,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (115,1443811132.623267,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (116,1443814786.540954,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (117,1443818166.506953,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (118,1443822830.889516,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (119,1443824778.178787,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (120,1443828428.562782,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (121,1443830155.563363,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (122,1443831877.497998,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (123,1443835301.093174,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (124,1443836960.302077,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (125,1443838610.296454,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (126,1443840284.711489,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (127,1443843564.681175,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (128,1443845186.641190,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (129,1443846799.414840,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (130,1443848399.203742,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (131,1443850003.008489,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (132,1443872598.969613,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (133,1443874365.600001,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (134,1443881457.632651,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (135,1443883822.008116,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (136,1443888428.874961,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (137,1443891277.604246,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (138,1443894082.249581,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (139,1443904407.416542,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (140,1443907205.448184,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (141,1443915749.286377,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (142,1443939166.445764,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:23.0) Gecko/20100101 Firefox/23.0');
INSERT INTO `wp_wfLogins` VALUES (143,1444334837.010209,0,'loginOK','trideon',1,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (X11; Fedora; Linux x86_64; rv:40.0) Gecko/20100101 Firefox/40.0');
INSERT INTO `wp_wfLogins` VALUES (144,1444815077.193434,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (145,1444815080.882655,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (146,1444827312.510351,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (147,1444827316.168647,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (148,1444839683.875146,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (149,1444839687.560444,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (150,1444852129.722424,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (151,1444852133.373559,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (152,1444864071.976001,1,'loginFailInvalidUsername','gmagigolo.com',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (153,1444864075.607925,1,'loginFailInvalidUsername','gmagigolo.com',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (154,1444876050.906368,1,'loginFailInvalidUsername','gmagigolo.com',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (155,1444876054.577981,1,'loginFailInvalidUsername','gmagigolo.com',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (156,1445475074.780319,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (157,1445475078.429175,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (158,1445541030.794421,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (159,1445541034.433728,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (160,1445577150.705532,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (161,1445577151.359147,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (162,1445613582.875895,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (163,1445613586.531628,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (164,1445649332.662943,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (165,1445649336.302155,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (166,1445688902.778899,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (167,1445688903.586129,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (168,1445714915.920973,1,'loginFailInvalidUsername','gmagigolo.com',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (169,1445714919.570706,1,'loginFailInvalidUsername','gmagigolo.com',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (170,1445750561.650814,1,'loginFailInvalidUsername','gmagigolo.com',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (171,1445750565.381243,1,'loginFailInvalidUsername','gmagigolo.com',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.57 Safari/537.36');
INSERT INTO `wp_wfLogins` VALUES (172,1446468953.918293,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)');
INSERT INTO `wp_wfLogins` VALUES (173,1446468957.271562,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)');
INSERT INTO `wp_wfLogins` VALUES (174,1446468960.609817,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)');
INSERT INTO `wp_wfLogins` VALUES (175,1446468964.091629,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)');
INSERT INTO `wp_wfLogins` VALUES (176,1446468964.473586,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)');
INSERT INTO `wp_wfLogins` VALUES (177,1446468968.089480,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)');
INSERT INTO `wp_wfLogins` VALUES (178,1446468971.864528,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)');
INSERT INTO `wp_wfLogins` VALUES (179,1446468976.334351,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)');
INSERT INTO `wp_wfLogins` VALUES (180,1446468979.666176,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)');
INSERT INTO `wp_wfLogins` VALUES (181,1446468984.141883,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)');
INSERT INTO `wp_wfLogins` VALUES (182,1446468988.576671,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)');
INSERT INTO `wp_wfLogins` VALUES (183,1446468992.279207,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)');
INSERT INTO `wp_wfLogins` VALUES (184,1446468996.851364,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)');
INSERT INTO `wp_wfLogins` VALUES (185,1446469001.521956,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)');
INSERT INTO `wp_wfLogins` VALUES (186,1446469007.312236,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)');
INSERT INTO `wp_wfLogins` VALUES (187,1446469013.322092,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)');
INSERT INTO `wp_wfLogins` VALUES (188,1446469019.501240,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)');
INSERT INTO `wp_wfLogins` VALUES (189,1446469022.805750,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)');
INSERT INTO `wp_wfLogins` VALUES (190,1446469027.714312,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)');
INSERT INTO `wp_wfLogins` VALUES (191,1446469032.674153,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)');
INSERT INTO `wp_wfLogins` VALUES (192,1446469036.970773,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)');
INSERT INTO `wp_wfLogins` VALUES (193,1446489540.575878,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; WOW64; Trident/7.0; SLCC2; .NET CLR 2.0.50727; .NET4.0C; .NET4.0E; .NET CLR 3.5.30729; .NET CLR 3.0.30729)');
INSERT INTO `wp_wfLogins` VALUES (194,1446506532.981003,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (195,1446507200.059231,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (196,1446507512.326401,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (197,1446507649.892228,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (198,1446507660.404786,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (199,1446507698.136847,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (200,1446507972.499403,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (201,1446507996.982950,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (202,1446508361.932969,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (203,1446508578.961303,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (204,1446508715.421405,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (205,1446509025.631660,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (206,1446509206.106607,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (207,1446509528.954209,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (208,1446509537.483733,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (209,1446509765.167654,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (210,1446509790.170195,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (211,1446509893.863993,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (212,1446510008.481010,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (213,1446525353.694401,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (214,1446525437.965747,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (215,1446525644.098667,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (216,1446525684.281072,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (217,1446525917.026814,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (218,1446526378.898094,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (219,1446526593.803057,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (220,1446526759.799885,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (221,1446526876.641820,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (222,1446527130.579316,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (223,1446527644.195032,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (224,1446527755.891011,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (225,1446528053.294154,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (226,1446528243.016856,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (227,1446528462.775142,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (228,1446528484.743996,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (229,1446529301.406109,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (230,1446529353.259319,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (231,1446529546.841343,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (232,1446544097.948427,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (233,1446544425.143347,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (234,1446544466.206410,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (235,1446544471.573714,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (236,1446544639.648650,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (237,1446544691.755588,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (238,1446544927.244167,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (239,1446545244.189943,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (240,1446545562.452150,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (241,1446545605.673047,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (242,1446545614.533451,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (243,1446545841.084197,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (244,1446545850.951541,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (245,1446545919.835596,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (246,1446546011.673253,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (247,1446546131.926347,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (248,1446546704.260060,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (249,1446547187.696171,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (250,1446547190.923580,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (251,1446562336.859233,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (252,1446562504.430043,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (253,1446562537.926500,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (254,1446562616.470529,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (255,1446562832.556851,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (256,1446562975.528038,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (257,1446563523.812836,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (258,1446563555.891344,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (259,1446563602.573068,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (260,1446563932.690640,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (261,1446564058.732770,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (262,1446564403.936328,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (263,1446564444.510352,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (264,1446564491.244850,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (265,1446564533.414555,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (266,1446564846.426050,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (267,1446565094.306268,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (268,1446565407.167431,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (269,1446565647.222843,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (270,1446580450.173660,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (271,1446580770.846950,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (272,1446581086.166614,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (273,1446581097.350141,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (274,1446581192.118582,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (275,1446581381.981894,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (276,1446581766.470424,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (277,1446581868.840932,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (278,1446582429.303431,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (279,1446582492.665575,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (280,1446583046.317149,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (281,1446583448.778505,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (282,1446584372.553912,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (283,1446584390.093938,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (284,1446585952.381611,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (285,1446586070.675302,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (286,1446586285.378675,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (287,1446586300.187643,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (288,1446586469.826020,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (289,1446601865.292432,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (290,1446602507.527141,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (291,1446603931.511898,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (292,1446604548.765593,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (293,1446604662.905869,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (294,1446604693.943237,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (295,1446604844.155527,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (296,1446604989.059635,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (297,1446605218.257489,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (298,1446606315.107402,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (299,1446606546.304323,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (300,1446607289.345233,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (301,1446607521.081700,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (302,1446607653.043893,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (303,1446609388.579443,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (304,1446609649.001100,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (305,1446609688.646314,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (306,1446610555.927991,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (307,1446611687.225331,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (308,1446626921.545548,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (309,1446626968.123727,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (310,1446626985.459798,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (311,1446627359.576591,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (312,1446627600.932943,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (313,1446627703.086910,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (314,1446627976.970690,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (315,1446627987.554466,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (316,1446628428.333365,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (317,1446628480.812958,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (318,1446628645.578844,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (319,1446628907.390311,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (320,1446629058.276978,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (321,1446629151.850224,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (322,1446629217.092576,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (323,1446629349.536186,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (324,1446629352.759218,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (325,1446630138.821533,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (326,1446630410.386717,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (327,1446644944.856776,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (328,1446645412.366586,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (329,1446645412.408989,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (330,1446645568.405625,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (331,1446645852.483727,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (332,1446646147.680956,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (333,1446646434.462089,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (334,1446646455.665001,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (335,1446646886.845489,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (336,1446647215.430713,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (337,1446647999.907036,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (338,1446648059.194524,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (339,1446648595.238310,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (340,1446649163.435522,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (341,1446649432.921159,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (342,1446649649.484161,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (343,1446649722.279268,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (344,1446649767.207586,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (345,1446649842.071267,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (346,1446665339.924584,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (347,1446665372.922379,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (348,1446665376.871664,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (349,1446665817.482460,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (350,1446666030.077259,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (351,1446666135.546134,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (352,1446666143.440848,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (353,1446666540.830855,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (354,1446666913.764941,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (355,1446666943.468578,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (356,1446667160.816093,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (357,1446667217.384260,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (358,1446667414.098877,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (359,1446667639.646724,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (360,1446668243.945501,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (361,1446668325.922137,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (362,1446668916.565000,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (363,1446669003.578443,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (364,1446669543.757421,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (365,1446685073.353095,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (366,1446685139.479588,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (367,1446685785.102215,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (368,1446686714.525216,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (369,1446686896.269662,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (370,1446687818.168746,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (371,1446688038.040911,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (372,1446688289.471975,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (373,1446688768.666298,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (374,1446689101.891698,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (375,1446689123.799227,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (376,1446689385.859123,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (377,1446689429.194336,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (378,1446691078.715181,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (379,1446692026.538881,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (380,1446692481.408386,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (381,1446692773.531427,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (382,1446692859.772333,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (383,1446693104.488514,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (384,1446708109.310792,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (385,1446708130.192358,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (386,1446708419.386811,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (387,1446708798.489001,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (388,1446708910.636828,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (389,1446708982.091836,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (390,1446709134.132006,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (391,1446709463.299517,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (392,1446709475.527502,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (393,1446709880.514007,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (394,1446710004.500490,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (395,1446710127.862200,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (396,1446710189.713784,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (397,1446710375.576660,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (398,1446710496.834124,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (399,1446710553.394181,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (400,1446711259.525875,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (401,1446711757.566172,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (402,1446711768.054254,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (403,1446726363.375952,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (404,1446726555.100979,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (405,1446726672.917759,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (406,1446726799.743831,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (407,1446727457.192140,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (408,1446727649.525852,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (409,1446727694.505759,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (410,1446727775.932020,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (411,1446727834.946360,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (412,1446727897.762513,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (413,1446727946.854763,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (414,1446728103.053563,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (415,1446728132.671112,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (416,1446728305.568071,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (417,1446728678.615538,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (418,1446729093.556421,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (419,1446729286.274169,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (420,1446730019.835758,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (421,1446730101.655056,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (422,1446745069.154429,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (423,1446745154.451019,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (424,1446745240.382887,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (425,1446745565.090572,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (426,1446745930.439726,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (427,1446746302.455121,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (428,1446746480.064877,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (429,1446746783.622696,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (430,1446747009.769247,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (431,1446747501.580597,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (432,1446747610.586396,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (433,1446747760.903175,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (434,1446748182.809515,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (435,1446748884.758258,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (436,1446749106.137510,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (437,1446749293.550683,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (438,1446749402.739637,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (439,1446749541.135254,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (440,1446749730.854076,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (441,1446765240.535792,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (442,1446765971.396003,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (443,1446766091.233979,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (444,1446767422.761245,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (445,1446767563.980360,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (446,1446767831.538420,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (447,1446768183.910876,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (448,1446768933.680716,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (449,1446769067.115783,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (450,1446771402.206822,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (451,1446771759.540618,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (452,1446772550.948841,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (453,1446772800.821635,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (454,1446772811.391163,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (455,1446774003.604140,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (456,1446775157.404785,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (457,1446775944.008662,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (458,1446775950.827706,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (459,1446776829.820723,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (460,1446792559.127615,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (461,1446793044.811792,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (462,1446793114.221549,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (463,1446793599.450543,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (464,1446793893.342308,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (465,1446793931.125160,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (466,1446794044.590935,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (467,1446794685.413459,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (468,1446794998.109408,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (469,1446795075.810054,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (470,1446795340.531949,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (471,1446795870.881227,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (472,1446795954.203695,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (473,1446796053.859036,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (474,1446796124.111808,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (475,1446796188.404309,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (476,1446796365.052455,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (477,1446796712.158350,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (478,1446797064.241684,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (479,1446811628.088585,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (480,1446811835.166431,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (481,1446811872.376692,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (482,1446812156.183121,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (483,1446812285.119117,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (484,1446812404.204058,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (485,1446812574.225179,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (486,1446812768.163166,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (487,1446812896.215573,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (488,1446813017.569023,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (489,1446813193.621233,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (490,1446813299.773580,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (491,1446813567.823600,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (492,1446813670.822589,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (493,1446813733.579632,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (494,1446813769.251112,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (495,1446814269.919825,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (496,1446814392.743892,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (497,1446814615.390926,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (498,1446829188.525716,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (499,1446829636.884430,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (500,1446829749.588373,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (501,1446829863.025795,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (502,1446830172.683458,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (503,1446830291.396218,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (504,1446830411.418847,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (505,1446830636.591766,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (506,1446830745.927451,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (507,1446830978.293908,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (508,1446831074.920315,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (509,1446831099.123421,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (510,1446831165.140275,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (511,1446831250.917571,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (512,1446831372.771244,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (513,1446831387.100560,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (514,1446831394.046258,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (515,1446831617.437127,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (516,1446831960.625398,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (517,1446846830.442683,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (518,1446846997.239764,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (519,1446847508.363859,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (520,1446847550.325371,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (521,1446847723.234167,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (522,1446848726.432658,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (523,1446848853.619554,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (524,1446851685.307977,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (525,1446852615.575376,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (526,1446853116.779912,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (527,1446853291.872526,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (528,1446853295.101274,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (529,1446853544.777772,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (530,1446854019.010117,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (531,1446854241.934019,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (532,1446854787.425113,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (533,1446854864.468060,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (534,1446855009.765796,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (535,1446855015.168276,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (536,1446869994.650258,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (537,1446870829.730062,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (538,1446871424.508459,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (539,1446871801.289944,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (540,1446871933.751366,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (541,1446871967.498038,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (542,1446872348.300812,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (543,1446872811.601235,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (544,1446873044.259896,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (545,1446873555.198744,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (546,1446874232.947176,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (547,1446874804.946118,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (548,1446875063.646948,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (549,1446875074.330973,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (550,1446875285.571561,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (551,1446876319.490655,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (552,1446876327.186865,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (553,1446876649.615492,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (554,1446877013.486369,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (555,1446891805.017084,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (556,1446892252.216675,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (557,1446892263.952019,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (558,1446892381.619040,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (559,1446892871.095780,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (560,1446893223.225191,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (561,1446894767.270209,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (562,1446894980.877090,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (563,1446895104.459144,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (564,1446895391.753183,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (565,1446895730.568002,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (566,1446895864.565419,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (567,1446895905.775047,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (568,1446896221.973470,1,'loginFailInvalidUsername','admin',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (569,1446896448.541092,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (570,1446897121.284764,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (571,1446897367.935426,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (572,1446897484.216742,1,'loginFailInvalidUsername','gmagigolo',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (573,1446897504.408807,1,'loginFailInvalidUsername','administrator',0,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 6.0; rv:34.0) Gecko/20100101 Firefox/34.0');
INSERT INTO `wp_wfLogins` VALUES (574,1447498627.283846,0,'loginOK','trideon',1,'\0\0\0\0\0\0\0\0\0\0��C��','Mozilla/5.0 (Windows NT 10.0; WOW64; rv:41.0) Gecko/20100101 Firefox/41.0');
/*!40000 ALTER TABLE `wp_wfLogins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wfNet404s`
--

DROP TABLE IF EXISTS `wp_wfNet404s`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wfNet404s` (
  `sig` binary(16) NOT NULL,
  `ctime` int(10) unsigned NOT NULL,
  `URI` varchar(1000) NOT NULL,
  PRIMARY KEY (`sig`),
  KEY `k1` (`ctime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wfNet404s`
--

LOCK TABLES `wp_wfNet404s` WRITE;
/*!40000 ALTER TABLE `wp_wfNet404s` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wfNet404s` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wfReverseCache`
--

DROP TABLE IF EXISTS `wp_wfReverseCache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wfReverseCache` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `host` varchar(255) NOT NULL,
  `lastUpdate` int(10) unsigned NOT NULL,
  PRIMARY KEY (`IP`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wfReverseCache`
--

LOCK TABLES `wp_wfReverseCache` WRITE;
/*!40000 ALTER TABLE `wp_wfReverseCache` DISABLE KEYS */;
INSERT INTO `wp_wfReverseCache` VALUES ('\0\0\0\0\0\0\0\0\0\0��C��','host.gmagigolo.com',1447438324);
/*!40000 ALTER TABLE `wp_wfReverseCache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wfScanners`
--

DROP TABLE IF EXISTS `wp_wfScanners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wfScanners` (
  `eMin` int(10) unsigned NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hits` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`eMin`,`IP`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wfScanners`
--

LOCK TABLES `wp_wfScanners` WRITE;
/*!40000 ALTER TABLE `wp_wfScanners` DISABLE KEYS */;
INSERT INTO `wp_wfScanners` VALUES (24124281,'\0\0\0\0\0\0\0\0\0\0��C��',1);
/*!40000 ALTER TABLE `wp_wfScanners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wfStatus`
--

DROP TABLE IF EXISTS `wp_wfStatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wfStatus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` double(17,6) unsigned NOT NULL,
  `level` tinyint(3) unsigned NOT NULL,
  `type` char(5) NOT NULL,
  `msg` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `k1` (`ctime`),
  KEY `k2` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=27252 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wfStatus`
--

LOCK TABLES `wp_wfStatus` WRITE;
/*!40000 ALTER TABLE `wp_wfStatus` DISABLE KEYS */;
INSERT INTO `wp_wfStatus` VALUES (26246,1446868130.836973,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26247,1446868130.838083,2,'info','Done file contents scan');
INSERT INTO `wp_wfStatus` VALUES (26885,1447316520.457571,2,'info','Analyzed 1818 files containing 24.98 MB of data.');
INSERT INTO `wp_wfStatus` VALUES (27184,1447498619.813691,10,'info','SUM_ENDSUCCESS:Fetching core, theme and plugin file signatures from Wordfence');
INSERT INTO `wp_wfStatus` VALUES (27185,1447498619.815393,10,'info','SUM_START:Fetching list of known malware files from Wordfence');
INSERT INTO `wp_wfStatus` VALUES (27186,1447498620.474371,10,'info','SUM_ENDSUCCESS:Fetching list of known malware files from Wordfence');
INSERT INTO `wp_wfStatus` VALUES (27165,1447438399.258284,10,'info','SUM_START:Scanning for old themes, plugins and core files');
INSERT INTO `wp_wfStatus` VALUES (26738,1447225949.793056,2,'info','Done database scan');
INSERT INTO `wp_wfStatus` VALUES (26737,1447225949.528342,2,'info','Starting scan of database');
INSERT INTO `wp_wfStatus` VALUES (27166,1447438399.883749,10,'info','SUM_ENDBAD:Scanning for old themes, plugins and core files');
INSERT INTO `wp_wfStatus` VALUES (27167,1447438399.892941,1,'info','-------------------');
INSERT INTO `wp_wfStatus` VALUES (26676,1447177347.351164,2,'info','Total disk space: 46.9759GB -- Free disk space: 30.2572GB');
INSERT INTO `wp_wfStatus` VALUES (25846,1446651400.924812,2,'info','Starting scan of database');
INSERT INTO `wp_wfStatus` VALUES (26047,1446768924.457393,2,'info','Getting theme list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26048,1446768924.466739,2,'info','Found 4 themes');
INSERT INTO `wp_wfStatus` VALUES (25931,1446711255.075405,2,'info','Examining URLs found in posts we scanned for dangerous websites');
INSERT INTO `wp_wfStatus` VALUES (25722,1446571728.278939,2,'info','Found 4 plugins');
INSERT INTO `wp_wfStatus` VALUES (25723,1446571728.280061,2,'info','Getting theme list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26912,1447316522.339085,10,'info','SUM_ENDOK:Scanning for weak passwords');
INSERT INTO `wp_wfStatus` VALUES (26522,1447062437.756163,2,'info','Wordfence used 23.06MB of memory for scan. Server peak memory usage was: 43.65MB');
INSERT INTO `wp_wfStatus` VALUES (26523,1447090338.702998,1,'info','Scheduled Wordfence scan starting at Monday 9th of November 2015 01:32:18 PM');
INSERT INTO `wp_wfStatus` VALUES (26467,1447062433.681939,2,'info','Analyzed 600 files containing 7.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26466,1447062433.565570,2,'info','Analyzed 500 files containing 6.14 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26170,1446780518.219108,2,'info','Starting scan of database');
INSERT INTO `wp_wfStatus` VALUES (26067,1446768926.887859,2,'info','Analyzed 1100 files containing 12.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26065,1446768926.664368,2,'info','Analyzed 900 files containing 9.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26066,1446768926.778321,2,'info','Analyzed 1000 files containing 11.22 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26903,1447316521.797237,2,'info','Examining URLs found in posts we scanned for dangerous websites');
INSERT INTO `wp_wfStatus` VALUES (26902,1447316521.794885,10,'info','SUM_START:Scanning posts for URL\'s in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (26498,1447062436.499899,2,'info','Examining URLs found in posts we scanned for dangerous websites');
INSERT INTO `wp_wfStatus` VALUES (26924,1447316522.989428,1,'info','-------------------');
INSERT INTO `wp_wfStatus` VALUES (26925,1447316522.989612,1,'info','Scan Complete. Scanned 1818 files, 4 plugins, 4 themes, 5 pages, 1 comments and 3774 records in 13 seconds.');
INSERT INTO `wp_wfStatus` VALUES (26109,1446768929.782887,2,'info','Total disk space: 46.9759GB -- Free disk space: 30.2646GB');
INSERT INTO `wp_wfStatus` VALUES (26110,1446768929.783034,2,'info','The disk has 30990.92 MB space available');
INSERT INTO `wp_wfStatus` VALUES (26306,1446922211.201851,2,'info','Analyzed 700 files containing 9.55 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26545,1447090348.627706,2,'info','Analyzed 300 files containing 4.66 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26023,1446751401.211754,2,'info','Starting DNS scan for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26020,1446751400.970985,2,'info','Starting password strength check on 1 users.');
INSERT INTO `wp_wfStatus` VALUES (26546,1447090348.726655,2,'info','Analyzed 400 files containing 5.25 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26692,1447225944.837419,1,'info','Contacting Wordfence to initiate scan');
INSERT INTO `wp_wfStatus` VALUES (26242,1446868130.432239,2,'info','Starting scan of file contents');
INSERT INTO `wp_wfStatus` VALUES (27179,1447498619.211139,2,'info','Getting plugin list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26693,1447225945.181291,2,'info','Getting plugin list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26694,1447225945.184272,2,'info','Found 4 plugins');
INSERT INTO `wp_wfStatus` VALUES (26695,1447225945.185638,2,'info','Getting theme list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26696,1447225945.192126,2,'info','Found 4 themes');
INSERT INTO `wp_wfStatus` VALUES (27182,1447498619.227481,2,'info','Found 4 themes');
INSERT INTO `wp_wfStatus` VALUES (27183,1447498619.231231,10,'info','SUM_START:Fetching core, theme and plugin file signatures from Wordfence');
INSERT INTO `wp_wfStatus` VALUES (27180,1447498619.217062,2,'info','Found 4 plugins');
INSERT INTO `wp_wfStatus` VALUES (27181,1447498619.218254,2,'info','Getting theme list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26520,1447062437.753473,1,'info','Scan Complete. Scanned 1818 files, 4 plugins, 4 themes, 5 pages, 1 comments and 3778 records in 14 seconds.');
INSERT INTO `wp_wfStatus` VALUES (26519,1447062437.753295,1,'info','-------------------');
INSERT INTO `wp_wfStatus` VALUES (26913,1447316522.340863,10,'info','SUM_START:Scanning DNS for unauthorized changes');
INSERT INTO `wp_wfStatus` VALUES (27046,1447399197.141650,2,'info','Analyzed 1800 files containing 24.58 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26533,1447090347.150377,2,'info','Getting theme list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (27081,1447399199.133504,2,'info','Total disk space: 46.9759GB -- Free disk space: 30.1726GB');
INSERT INTO `wp_wfStatus` VALUES (26904,1447316521.797521,2,'info','Checking 1 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (26534,1447090347.159758,2,'info','Found 4 themes');
INSERT INTO `wp_wfStatus` VALUES (27089,1447399199.458394,2,'info','Wordfence used 23.05MB of memory for scan. Server peak memory usage was: 43.65MB');
INSERT INTO `wp_wfStatus` VALUES (27090,1447438325.137379,1,'info','Scheduled Wordfence scan starting at Friday 13th of November 2015 02:12:05 PM');
INSERT INTO `wp_wfStatus` VALUES (26984,1447370642.942984,2,'info','Examining URLs found in posts we scanned for dangerous websites');
INSERT INTO `wp_wfStatus` VALUES (26985,1447370642.943853,2,'info','Checking 1 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (26013,1446751400.674079,2,'info','Checking 1 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (25911,1446711253.545901,2,'info','Analyzed 1700 files containing 21.71 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25910,1446711253.432616,2,'info','Analyzed 1600 files containing 20.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26475,1447062434.565264,2,'info','Analyzed 1400 files containing 18.56 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26975,1447370642.338918,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26591,1447090352.254394,2,'info','Scanning DNS A record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26592,1447090352.256688,2,'info','Scanning DNS MX record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26590,1447090352.247971,2,'info','Starting DNS scan for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26506,1447062436.849026,2,'info','Starting password strength check on 1 users.');
INSERT INTO `wp_wfStatus` VALUES (26920,1447316522.352299,2,'info','The disk has 30904.59 MB space available');
INSERT INTO `wp_wfStatus` VALUES (26223,1446868128.503951,2,'info','Analyzed 500 files containing 6.14 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26224,1446868128.627547,2,'info','Analyzed 600 files containing 7.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26225,1446868128.749757,2,'info','Analyzed 700 files containing 9.55 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26106,1446768929.780250,2,'info','Scanning DNS MX record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26418,1446973965.189789,2,'info','Checking 1 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (26968,1447370641.597831,10,'info','SUM_ENDOK:Scanning for known malware files');
INSERT INTO `wp_wfStatus` VALUES (26417,1446973965.189527,2,'info','Examining URLs found in posts we scanned for dangerous websites');
INSERT INTO `wp_wfStatus` VALUES (26105,1446768929.777979,2,'info','Scanning DNS A record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26793,1447251205.695386,2,'info','Analyzed 800 files containing 9.6 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26792,1447251205.618487,2,'info','Analyzed 700 files containing 9.55 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26790,1447251205.386575,2,'info','Analyzed 500 files containing 6.14 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26791,1447251205.504844,2,'info','Analyzed 600 files containing 7.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27008,1447370643.841493,2,'info','Wordfence used 23.06MB of memory for scan. Server peak memory usage was: 43.65MB');
INSERT INTO `wp_wfStatus` VALUES (27011,1447399185.254164,10,'info','SUM_PAIDONLY:Remote scan of public facing site only available to paid members');
INSERT INTO `wp_wfStatus` VALUES (27010,1447399185.250894,10,'info','SUM_PREP:Preparing a new scan.');
INSERT INTO `wp_wfStatus` VALUES (27009,1447399124.241890,1,'info','Scheduled Wordfence scan starting at Friday 13th of November 2015 03:18:44 AM');
INSERT INTO `wp_wfStatus` VALUES (26626,1447177343.582669,2,'info','Analyzed 300 files containing 4.66 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26627,1447177343.680753,2,'info','Analyzed 400 files containing 5.25 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26348,1446922214.687416,2,'info','Scanning DNS A record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26349,1446922214.690102,2,'info','Scanning DNS MX record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26245,1446868130.549091,2,'info','Checking 30 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (26244,1446868130.547055,2,'info','Asking Wordfence to check URL\'s against malware list.');
INSERT INTO `wp_wfStatus` VALUES (25721,1446571728.273421,2,'info','Getting plugin list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (25720,1446571727.928717,1,'info','Contacting Wordfence to initiate scan');
INSERT INTO `wp_wfStatus` VALUES (26012,1446751400.673032,2,'info','Examining URLs found in posts we scanned for dangerous websites');
INSERT INTO `wp_wfStatus` VALUES (27086,1447399199.455530,1,'info','-------------------');
INSERT INTO `wp_wfStatus` VALUES (27087,1447399199.455709,1,'info','Scan Complete. Scanned 1818 files, 4 plugins, 4 themes, 5 pages, 1 comments and 3937 records in 14 seconds.');
INSERT INTO `wp_wfStatus` VALUES (27088,1447399199.455861,10,'info','SUM_FINAL:Scan complete. You have 6 new issues to fix. See below.');
INSERT INTO `wp_wfStatus` VALUES (25850,1446651401.195388,2,'info','Examining URLs found in posts we scanned for dangerous websites');
INSERT INTO `wp_wfStatus` VALUES (26776,1447251203.647602,2,'info','Getting theme list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26075,1446768927.807634,2,'info','Analyzed 1818 files containing 24.98 MB of data.');
INSERT INTO `wp_wfStatus` VALUES (26915,1447316522.347251,2,'info','Scanning DNS A record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26916,1447316522.349635,2,'info','Scanning DNS MX record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26515,1447062437.112385,2,'info','The disk has 30988.40 MB space available');
INSERT INTO `wp_wfStatus` VALUES (26953,1447370640.232048,2,'info','Analyzed 600 files containing 7.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26441,1446973966.440379,2,'info','Wordfence used 23.05MB of memory for scan. Server peak memory usage was: 43.65MB');
INSERT INTO `wp_wfStatus` VALUES (26220,1446868128.150237,2,'info','Analyzed 200 files containing 2.44 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26219,1446868128.045055,2,'info','Analyzed 100 files containing 1.36 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27176,1447498617.465885,10,'info','SUM_START:Scanning your site for the HeartBleed vulnerability');
INSERT INTO `wp_wfStatus` VALUES (25908,1446711253.212892,2,'info','Analyzed 1400 files containing 18.56 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25909,1446711253.316221,2,'info','Analyzed 1500 files containing 19.43 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26399,1446973963.792956,2,'info','Analyzed 1818 files containing 24.98 MB of data.');
INSERT INTO `wp_wfStatus` VALUES (26398,1446973963.764713,2,'info','Analyzed 1800 files containing 24.58 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26868,1447316518.642952,2,'info','Analyzed 200 files containing 2.44 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26869,1447316518.776099,2,'info','Analyzed 300 files containing 4.66 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26190,1446780519.039337,2,'info','Total disk space: 46.9759GB -- Free disk space: 30.2650GB');
INSERT INTO `wp_wfStatus` VALUES (27148,1447438398.989672,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26765,1447225950.988076,2,'info','Wordfence used 23.05MB of memory for scan. Server peak memory usage was: 43.65MB');
INSERT INTO `wp_wfStatus` VALUES (27151,1447438398.992710,10,'info','SUM_START:Scanning comments for URL\'s in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (27150,1447438398.990960,10,'info','SUM_ENDOK:Scanning posts for URL\'s in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (26762,1447225950.985099,1,'info','-------------------');
INSERT INTO `wp_wfStatus` VALUES (26763,1447225950.985398,1,'info','Scan Complete. Scanned 1817 files, 4 plugins, 4 themes, 5 pages, 1 comments and 3882 records in 13 seconds.');
INSERT INTO `wp_wfStatus` VALUES (27149,1447438398.990032,2,'info','Done examining URLs');
INSERT INTO `wp_wfStatus` VALUES (26705,1447225946.512564,2,'info','Analyzed 100 files containing 1.36 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25944,1446711255.702311,2,'info','Scanning DNS MX record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (25943,1446711255.699826,2,'info','Scanning DNS A record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (27174,1447498613.461709,10,'info','SUM_PAIDONLY:Check if your site is being Spamvertized is for paid members only');
INSERT INTO `wp_wfStatus` VALUES (25942,1446711255.622068,2,'info','Starting DNS scan for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (27175,1447498615.463370,10,'info','SUM_PAIDONLY:Checking if your IP is generating spam is for paid members only');
INSERT INTO `wp_wfStatus` VALUES (26139,1446780515.262644,2,'info','Analyzed 200 files containing 2.44 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26138,1446780515.161116,2,'info','Analyzed 100 files containing 1.36 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26474,1447062434.418317,2,'info','Analyzed 1300 files containing 16.07 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26976,1447370642.340109,2,'info','Done file contents scan');
INSERT INTO `wp_wfStatus` VALUES (26558,1447090350.050592,2,'info','Analyzed 1600 files containing 20.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26557,1447090349.927337,2,'info','Analyzed 1500 files containing 19.43 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25999,1446751399.588221,2,'info','Starting scan of file contents');
INSERT INTO `wp_wfStatus` VALUES (26000,1446751399.702784,2,'info','Scanned contents of 16 additional files at 140.33 per second');
INSERT INTO `wp_wfStatus` VALUES (27127,1447438397.278911,2,'info','Analyzed 1800 files containing 24.58 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26555,1447090349.681493,2,'info','Analyzed 1300 files containing 16.07 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26068,1446768927.009803,2,'info','Analyzed 1200 files containing 14.27 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26069,1446768927.152213,2,'info','Analyzed 1300 files containing 16.07 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27076,1447399199.120974,2,'info','Starting DNS scan for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26556,1447090349.824015,2,'info','Analyzed 1400 files containing 18.56 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25705,1446557634.903754,2,'info','The disk has 31000.86 MB space available');
INSERT INTO `wp_wfStatus` VALUES (25985,1446751398.333171,2,'info','Analyzed 1000 files containing 11.22 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25986,1446751398.434702,2,'info','Analyzed 1100 files containing 12.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25791,1446571734.222062,1,'info','Scan Complete. Scanned 1818 files, 4 plugins, 4 themes, 5 pages, 1 comments and 3495 records in 14 seconds.');
INSERT INTO `wp_wfStatus` VALUES (26155,1446780517.086457,2,'info','Analyzed 1800 files containing 24.58 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26710,1447225947.065522,2,'info','Analyzed 600 files containing 7.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26709,1447225946.947732,2,'info','Analyzed 500 files containing 6.14 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26708,1447225946.844088,2,'info','Analyzed 400 files containing 5.25 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26279,1446868132.658090,2,'info','Wordfence used 23.06MB of memory for scan. Server peak memory usage was: 43.65MB');
INSERT INTO `wp_wfStatus` VALUES (26280,1446922140.722936,1,'info','Scheduled Wordfence scan starting at Saturday 7th of November 2015 02:49:00 PM');
INSERT INTO `wp_wfStatus` VALUES (26673,1447177347.348625,2,'info','Scanning DNS MX record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (27197,1447498621.283106,2,'info','Analyzed 700 files containing 9.55 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26909,1447316522.097053,10,'info','SUM_ENDOK:Scanning comments for URL\'s in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (26910,1447316522.098692,10,'info','SUM_START:Scanning for weak passwords');
INSERT INTO `wp_wfStatus` VALUES (26861,1447316517.751029,10,'info','SUM_START:Fetching list of known malware files from Wordfence');
INSERT INTO `wp_wfStatus` VALUES (27093,1447438388.151668,10,'info','SUM_PAIDONLY:Check if your site is being Spamvertized is for paid members only');
INSERT INTO `wp_wfStatus` VALUES (26860,1447316517.748554,10,'info','SUM_ENDSUCCESS:Fetching core, theme and plugin file signatures from Wordfence');
INSERT INTO `wp_wfStatus` VALUES (25895,1446711251.775559,2,'info','Analyzed 100 files containing 1.36 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25896,1446711251.878467,2,'info','Analyzed 200 files containing 2.44 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25897,1446711252.011493,2,'info','Analyzed 300 files containing 4.66 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26581,1447090351.999014,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26582,1447090351.999381,2,'info','Done examining URLs');
INSERT INTO `wp_wfStatus` VALUES (26877,1447316519.579799,2,'info','Analyzed 1100 files containing 12.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26878,1447316519.694764,2,'info','Analyzed 1200 files containing 14.27 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26879,1447316519.833100,2,'info','Analyzed 1300 files containing 16.07 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26876,1447316519.478263,2,'info','Analyzed 1000 files containing 11.22 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26923,1447316522.980951,10,'info','SUM_ENDBAD:Scanning for old themes, plugins and core files');
INSERT INTO `wp_wfStatus` VALUES (26922,1447316522.354334,10,'info','SUM_START:Scanning for old themes, plugins and core files');
INSERT INTO `wp_wfStatus` VALUES (27189,1447498620.476938,10,'info','SUM_DISABLED:Skipping plugin scan');
INSERT INTO `wp_wfStatus` VALUES (27190,1447498620.478241,10,'info','SUM_START:Scanning for known malware files');
INSERT INTO `wp_wfStatus` VALUES (26255,1446868131.410397,2,'info','Examining URLs found in posts we scanned for dangerous websites');
INSERT INTO `wp_wfStatus` VALUES (26256,1446868131.410668,2,'info','Checking 1 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (26257,1446868131.700345,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (27145,1447438398.662056,10,'info','SUM_START:Scanning posts for URL\'s in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (27146,1447438398.664232,2,'info','Examining URLs found in posts we scanned for dangerous websites');
INSERT INTO `wp_wfStatus` VALUES (26712,1447225947.260226,2,'info','Analyzed 800 files containing 9.6 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26082,1446768928.267459,2,'info','Asking Wordfence to check URL\'s against malware list.');
INSERT INTO `wp_wfStatus` VALUES (26081,1446768928.267265,2,'info','Scanned contents of 16 additional files at 153.80 per second');
INSERT INTO `wp_wfStatus` VALUES (26080,1446768928.162843,2,'info','Starting scan of file contents');
INSERT INTO `wp_wfStatus` VALUES (26514,1447062437.112231,2,'info','Total disk space: 46.9759GB -- Free disk space: 30.2621GB');
INSERT INTO `wp_wfStatus` VALUES (26327,1446922213.238872,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26046,1446768924.455990,2,'info','Found 4 plugins');
INSERT INTO `wp_wfStatus` VALUES (26950,1447370639.916922,2,'info','Analyzed 300 files containing 4.66 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26951,1447370640.013802,2,'info','Analyzed 400 files containing 5.25 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26949,1447370639.783264,2,'info','Analyzed 200 files containing 2.44 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26948,1447370639.679844,2,'info','Analyzed 100 files containing 1.36 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26946,1447370639.559722,10,'info','SUM_DISABLED:Skipping plugin scan');
INSERT INTO `wp_wfStatus` VALUES (26947,1447370639.560669,10,'info','SUM_START:Scanning for known malware files');
INSERT INTO `wp_wfStatus` VALUES (26604,1447177273.194141,1,'info','Scheduled Wordfence scan starting at Tuesday 10th of November 2015 01:41:13 PM');
INSERT INTO `wp_wfStatus` VALUES (26862,1447316518.415090,10,'info','SUM_ENDSUCCESS:Fetching list of known malware files from Wordfence');
INSERT INTO `wp_wfStatus` VALUES (27139,1447438398.038594,10,'info','SUM_ENDOK:Scanning file contents for infections and vulnerabilities');
INSERT INTO `wp_wfStatus` VALUES (26221,1446868128.292695,2,'info','Analyzed 300 files containing 4.66 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26174,1446780518.487898,2,'info','Examining URLs found in posts we scanned for dangerous websites');
INSERT INTO `wp_wfStatus` VALUES (25991,1446751399.023871,2,'info','Analyzed 1600 files containing 20.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26326,1446922212.946120,2,'info','Checking 30 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (27016,1447399192.797245,1,'info','Contacting Wordfence to initiate scan');
INSERT INTO `wp_wfStatus` VALUES (27015,1447399192.795754,10,'info','SUM_ENDOK:Scanning your site for the HeartBleed vulnerability');
INSERT INTO `wp_wfStatus` VALUES (26147,1446780516.112071,2,'info','Analyzed 1000 files containing 11.22 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26148,1446780516.218045,2,'info','Analyzed 1100 files containing 12.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26149,1446780516.334521,2,'info','Analyzed 1200 files containing 14.27 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26150,1446780516.472387,2,'info','Analyzed 1300 files containing 16.07 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26994,1447370643.497374,10,'info','SUM_START:Scanning DNS for unauthorized changes');
INSERT INTO `wp_wfStatus` VALUES (26995,1447370643.497626,2,'info','Starting DNS scan for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26996,1447370643.505765,2,'info','Scanning DNS A record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26997,1447370643.508063,2,'info','Scanning DNS MX record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26998,1447370643.508804,10,'info','SUM_ENDOK:Scanning DNS for unauthorized changes');
INSERT INTO `wp_wfStatus` VALUES (26405,1446973964.254499,2,'info','Scanned contents of 16 additional files at 155.50 per second');
INSERT INTO `wp_wfStatus` VALUES (26973,1447370642.039674,2,'info','Asking Wordfence to check URL\'s against malware list.');
INSERT INTO `wp_wfStatus` VALUES (26404,1446973964.151161,2,'info','Starting scan of file contents');
INSERT INTO `wp_wfStatus` VALUES (26974,1447370642.042321,2,'info','Checking 30 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (25786,1446571733.586636,2,'info','The disk has 31000.20 MB space available');
INSERT INTO `wp_wfStatus` VALUES (27213,1447498622.612058,10,'info','SUM_START:Scanning files for URLs in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (26647,1447177345.633816,2,'info','Starting scan of file contents');
INSERT INTO `wp_wfStatus` VALUES (26648,1447177345.738069,2,'info','Scanned contents of 16 additional files at 154.10 per second');
INSERT INTO `wp_wfStatus` VALUES (26332,1446922213.590253,2,'info','Starting scan of database');
INSERT INTO `wp_wfStatus` VALUES (26333,1446922213.966331,2,'info','Done database scan');
INSERT INTO `wp_wfStatus` VALUES (25820,1446651398.334715,2,'info','Analyzed 700 files containing 9.55 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27108,1447438395.173894,10,'info','SUM_DISABLED:Skipping plugin scan');
INSERT INTO `wp_wfStatus` VALUES (27107,1447438395.173748,10,'info','SUM_DISABLED:Skipping theme scan');
INSERT INTO `wp_wfStatus` VALUES (25821,1446651398.417719,2,'info','Analyzed 800 files containing 9.6 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27032,1447399194.879373,2,'info','Analyzed 400 files containing 5.25 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26310,1446922211.599647,2,'info','Analyzed 1100 files containing 12.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25777,1446571733.325134,2,'info','Starting password strength check on 1 users.');
INSERT INTO `wp_wfStatus` VALUES (26312,1446922211.870066,2,'info','Analyzed 1300 files containing 16.07 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26311,1446922211.724220,2,'info','Analyzed 1200 files containing 14.27 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27031,1447399194.762582,2,'info','Analyzed 300 files containing 4.66 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26943,1447370639.556269,10,'info','SUM_ENDSUCCESS:Fetching list of known malware files from Wordfence');
INSERT INTO `wp_wfStatus` VALUES (26185,1446780519.025557,2,'info','Starting DNS scan for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (27059,1447399197.908343,10,'info','SUM_ENDOK:Scanning files for URLs in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (25902,1446711252.528107,2,'info','Analyzed 800 files containing 9.6 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25903,1446711252.611266,2,'info','Analyzed 900 files containing 9.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27024,1447399194.223254,10,'info','SUM_ENDSUCCESS:Fetching list of known malware files from Wordfence');
INSERT INTO `wp_wfStatus` VALUES (27077,1447399199.128792,2,'info','Scanning DNS A record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (27078,1447399199.130982,2,'info','Scanning DNS MX record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (27079,1447399199.131719,10,'info','SUM_ENDOK:Scanning DNS for unauthorized changes');
INSERT INTO `wp_wfStatus` VALUES (26101,1446768929.477519,2,'info','Starting password strength check on 1 users.');
INSERT INTO `wp_wfStatus` VALUES (27225,1447498623.992913,10,'info','SUM_ENDOK:Scanning database for infections and vulnerabilities');
INSERT INTO `wp_wfStatus` VALUES (26914,1447316522.341131,2,'info','Starting DNS scan for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (27162,1447438399.256280,2,'info','Total disk space: 46.9759GB -- Free disk space: 30.1708GB');
INSERT INTO `wp_wfStatus` VALUES (26741,1447225949.797436,2,'info','Examining URLs found in posts we scanned for dangerous websites');
INSERT INTO `wp_wfStatus` VALUES (25839,1446651400.233225,2,'info','Asking Wordfence to check URL\'s against malware list.');
INSERT INTO `wp_wfStatus` VALUES (27045,1447399197.006734,2,'info','Analyzed 1700 files containing 21.71 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27073,1447399198.848075,2,'info','Starting password strength check on 1 users.');
INSERT INTO `wp_wfStatus` VALUES (27074,1447399199.118879,10,'info','SUM_ENDOK:Scanning for weak passwords');
INSERT INTO `wp_wfStatus` VALUES (27230,1447498624.355310,2,'info','Done examining URLs');
INSERT INTO `wp_wfStatus` VALUES (27231,1447498624.356915,10,'info','SUM_ENDOK:Scanning posts for URL\'s in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (26384,1446973962.118232,2,'info','Analyzed 400 files containing 5.25 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26071,1446768927.402438,2,'info','Analyzed 1500 files containing 19.43 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25704,1446557634.903608,2,'info','Total disk space: 46.9759GB -- Free disk space: 30.2743GB');
INSERT INTO `wp_wfStatus` VALUES (26887,1447316520.459306,10,'info','SUM_ENDOK:Scanning for known malware files');
INSERT INTO `wp_wfStatus` VALUES (26888,1447316520.467234,10,'info','SUM_START:Scanning file contents for infections and vulnerabilities');
INSERT INTO `wp_wfStatus` VALUES (26889,1447316520.468213,10,'info','SUM_START:Scanning files for URLs in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (26471,1447062434.064683,2,'info','Analyzed 1000 files containing 11.22 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26706,1447225946.614895,2,'info','Analyzed 200 files containing 2.44 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25947,1446711255.704985,2,'info','Total disk space: 46.9759GB -- Free disk space: 30.2673GB');
INSERT INTO `wp_wfStatus` VALUES (25948,1446711255.705134,2,'info','The disk has 30993.68 MB space available');
INSERT INTO `wp_wfStatus` VALUES (26707,1447225946.747922,2,'info','Analyzed 300 files containing 4.66 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25736,1446571729.966245,2,'info','Analyzed 400 files containing 5.25 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26991,1447370643.256060,10,'info','SUM_START:Scanning for weak passwords');
INSERT INTO `wp_wfStatus` VALUES (26990,1447370643.254412,10,'info','SUM_ENDOK:Scanning comments for URL\'s in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (26989,1447370643.252125,10,'info','SUM_START:Scanning comments for URL\'s in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (26381,1446973961.774789,2,'info','Analyzed 100 files containing 1.36 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26166,1446780517.871127,2,'info','Done file contents scan');
INSERT INTO `wp_wfStatus` VALUES (26469,1447062433.877243,2,'info','Analyzed 800 files containing 9.6 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26165,1446780517.869879,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26774,1447251203.640559,2,'info','Getting plugin list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26978,1447370642.342007,10,'info','SUM_ENDOK:Scanning files for URLs in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (26773,1447251203.317254,1,'info','Contacting Wordfence to initiate scan');
INSERT INTO `wp_wfStatus` VALUES (27136,1447438397.707230,2,'info','Checking 30 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (27137,1447438398.036964,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (25977,1446751397.439827,2,'info','Analyzed 200 files containing 2.44 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26388,1446973962.551527,2,'info','Analyzed 800 files containing 9.6 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26389,1446973962.638779,2,'info','Analyzed 900 files containing 9.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26390,1446973962.765205,2,'info','Analyzed 1000 files containing 11.22 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26595,1447090352.259243,2,'info','Total disk space: 46.9759GB -- Free disk space: 30.2609GB');
INSERT INTO `wp_wfStatus` VALUES (27012,1447399187.255248,10,'info','SUM_PAIDONLY:Check if your site is being Spamvertized is for paid members only');
INSERT INTO `wp_wfStatus` VALUES (26338,1446922214.327386,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26090,1446768929.171711,2,'info','Done database scan');
INSERT INTO `wp_wfStatus` VALUES (26336,1446922213.974353,2,'info','Examining URLs found in posts we scanned for dangerous websites');
INSERT INTO `wp_wfStatus` VALUES (26337,1446922213.974856,2,'info','Checking 1 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (25967,1446751396.031868,2,'info','Found 4 themes');
INSERT INTO `wp_wfStatus` VALUES (25965,1446751396.020878,2,'info','Found 4 plugins');
INSERT INTO `wp_wfStatus` VALUES (25966,1446751396.022024,2,'info','Getting theme list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (25964,1446751396.013309,2,'info','Getting plugin list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (25709,1446557635.542436,1,'info','-------------------');
INSERT INTO `wp_wfStatus` VALUES (25710,1446557635.542613,1,'info','Scan Complete. Scanned 1818 files, 4 plugins, 4 themes, 5 pages, 1 comments and 3597 records in 14 seconds.');
INSERT INTO `wp_wfStatus` VALUES (26886,1447316520.457952,10,'info','SUM_ENDOK:Comparing core WordPress files against originals in repository');
INSERT INTO `wp_wfStatus` VALUES (25963,1446751395.712766,1,'info','Contacting Wordfence to initiate scan');
INSERT INTO `wp_wfStatus` VALUES (25826,1446651399.070812,2,'info','Analyzed 1300 files containing 16.07 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26089,1446768928.908416,2,'info','Starting scan of database');
INSERT INTO `wp_wfStatus` VALUES (26919,1447316522.352138,2,'info','Total disk space: 46.9759GB -- Free disk space: 30.1803GB');
INSERT INTO `wp_wfStatus` VALUES (26509,1447062437.096257,2,'info','Starting DNS scan for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26339,1446922214.327836,2,'info','Done examining URLs');
INSERT INTO `wp_wfStatus` VALUES (26633,1447177344.298669,2,'info','Analyzed 1000 files containing 11.22 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26634,1447177344.399776,2,'info','Analyzed 1100 files containing 12.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26635,1447177344.520864,2,'info','Analyzed 1200 files containing 14.27 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26636,1447177344.660854,2,'info','Analyzed 1300 files containing 16.07 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26637,1447177344.802046,2,'info','Analyzed 1400 files containing 18.56 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26638,1447177344.905479,2,'info','Analyzed 1500 files containing 19.43 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26639,1447177345.021430,2,'info','Analyzed 1600 files containing 20.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26640,1447177345.140908,2,'info','Analyzed 1700 files containing 21.71 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26641,1447177345.275990,2,'info','Analyzed 1800 files containing 24.58 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26642,1447177345.298723,2,'info','Analyzed 1818 files containing 24.98 MB of data.');
INSERT INTO `wp_wfStatus` VALUES (27216,1447498623.048882,2,'info','Asking Wordfence to check URL\'s against malware list.');
INSERT INTO `wp_wfStatus` VALUES (27214,1447498622.943039,2,'info','Starting scan of file contents');
INSERT INTO `wp_wfStatus` VALUES (27215,1447498623.048707,2,'info','Scanned contents of 16 additional files at 152.69 per second');
INSERT INTO `wp_wfStatus` VALUES (25907,1446711253.074927,2,'info','Analyzed 1300 files containing 16.07 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25906,1446711252.937529,2,'info','Analyzed 1200 files containing 14.27 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26744,1447225950.087630,2,'info','Done examining URLs');
INSERT INTO `wp_wfStatus` VALUES (26324,1446922212.943641,2,'info','Scanned contents of 16 additional files at 153.75 per second');
INSERT INTO `wp_wfStatus` VALUES (26325,1446922212.943818,2,'info','Asking Wordfence to check URL\'s against malware list.');
INSERT INTO `wp_wfStatus` VALUES (27017,1447399193.125256,2,'info','Getting plugin list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (25765,1446571732.754615,2,'info','Starting scan of database');
INSERT INTO `wp_wfStatus` VALUES (27023,1447399193.634765,10,'info','SUM_START:Fetching list of known malware files from Wordfence');
INSERT INTO `wp_wfStatus` VALUES (25766,1446571733.020443,2,'info','Done database scan');
INSERT INTO `wp_wfStatus` VALUES (26316,1446922212.328786,2,'info','Analyzed 1700 files containing 21.71 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27022,1447399193.632929,10,'info','SUM_ENDSUCCESS:Fetching core, theme and plugin file signatures from Wordfence');
INSERT INTO `wp_wfStatus` VALUES (27018,1447399193.128036,2,'info','Found 4 plugins');
INSERT INTO `wp_wfStatus` VALUES (27019,1447399193.129138,2,'info','Getting theme list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (27020,1447399193.135933,2,'info','Found 4 themes');
INSERT INTO `wp_wfStatus` VALUES (27021,1447399193.140224,10,'info','SUM_START:Fetching core, theme and plugin file signatures from Wordfence');
INSERT INTO `wp_wfStatus` VALUES (26714,1447225947.448009,2,'info','Analyzed 1000 files containing 11.22 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26713,1447225947.341582,2,'info','Analyzed 900 files containing 9.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26531,1447090347.146380,2,'info','Getting plugin list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (25740,1446571730.389894,2,'info','Analyzed 800 files containing 9.6 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25978,1446751397.578200,2,'info','Analyzed 300 files containing 4.66 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26961,1447370641.109754,2,'info','Analyzed 1400 files containing 18.56 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26433,1446973965.799853,2,'info','Total disk space: 46.9759GB -- Free disk space: 30.2603GB');
INSERT INTO `wp_wfStatus` VALUES (26901,1447316521.793211,10,'info','SUM_ENDOK:Scanning database for infections and vulnerabilities');
INSERT INTO `wp_wfStatus` VALUES (25837,1446651400.112877,2,'info','Starting scan of file contents');
INSERT INTO `wp_wfStatus` VALUES (25838,1446651400.233037,2,'info','Scanned contents of 16 additional files at 133.61 per second');
INSERT INTO `wp_wfStatus` VALUES (26552,1447090349.330918,2,'info','Analyzed 1000 files containing 11.22 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27068,1447399198.841862,2,'info','Done examining URLs');
INSERT INTO `wp_wfStatus` VALUES (27069,1447399198.842753,10,'info','SUM_ENDOK:Scanning posts for URL\'s in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (27070,1447399198.844414,10,'info','SUM_START:Scanning comments for URL\'s in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (27071,1447399198.846116,10,'info','SUM_ENDOK:Scanning comments for URL\'s in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (26969,1447370641.606094,10,'info','SUM_START:Scanning file contents for infections and vulnerabilities');
INSERT INTO `wp_wfStatus` VALUES (26495,1447062436.495143,2,'info','Done database scan');
INSERT INTO `wp_wfStatus` VALUES (26414,1446973965.185034,2,'info','Done database scan');
INSERT INTO `wp_wfStatus` VALUES (26970,1447370641.607054,10,'info','SUM_START:Scanning files for URLs in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (26413,1446973964.902554,2,'info','Starting scan of database');
INSERT INTO `wp_wfStatus` VALUES (26494,1447062436.224902,2,'info','Starting scan of database');
INSERT INTO `wp_wfStatus` VALUES (26114,1446768930.431260,1,'info','-------------------');
INSERT INTO `wp_wfStatus` VALUES (26115,1446768930.431466,1,'info','Scan Complete. Scanned 1818 files, 4 plugins, 4 themes, 5 pages, 1 comments and 3767 records in 14 seconds.');
INSERT INTO `wp_wfStatus` VALUES (27226,1447498623.994689,10,'info','SUM_START:Scanning posts for URL\'s in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (26934,1447370638.065904,10,'info','SUM_ENDOK:Scanning your site for the HeartBleed vulnerability');
INSERT INTO `wp_wfStatus` VALUES (26935,1447370638.068257,1,'info','Contacting Wordfence to initiate scan');
INSERT INTO `wp_wfStatus` VALUES (26936,1447370638.399072,2,'info','Getting plugin list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26937,1447370638.401391,2,'info','Found 4 plugins');
INSERT INTO `wp_wfStatus` VALUES (26385,1446973962.227783,2,'info','Analyzed 500 files containing 6.14 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26567,1447090350.748195,2,'info','Scanned contents of 16 additional files at 153.22 per second');
INSERT INTO `wp_wfStatus` VALUES (26156,1446780517.109435,2,'info','Analyzed 1818 files containing 24.98 MB of data.');
INSERT INTO `wp_wfStatus` VALUES (26473,1447062434.282097,2,'info','Analyzed 1200 files containing 14.27 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25883,1446711250.558077,2,'info','Getting plugin list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (25884,1446711250.563241,2,'info','Found 4 plugins');
INSERT INTO `wp_wfStatus` VALUES (25885,1446711250.564388,2,'info','Getting theme list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (25886,1446711250.567598,2,'info','Found 4 themes');
INSERT INTO `wp_wfStatus` VALUES (25817,1446651397.983793,2,'info','Analyzed 400 files containing 5.25 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25816,1446651397.884414,2,'info','Analyzed 300 files containing 4.66 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25815,1446651397.748585,2,'info','Analyzed 200 files containing 2.44 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27066,1447399198.511472,2,'info','Checking 1 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (26628,1447177343.786851,2,'info','Analyzed 500 files containing 6.14 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26477,1447062434.777241,2,'info','Analyzed 1600 files containing 20.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26476,1447062434.665555,2,'info','Analyzed 1500 files containing 19.43 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27003,1447370643.512652,10,'info','SUM_START:Scanning for old themes, plugins and core files');
INSERT INTO `wp_wfStatus` VALUES (26630,1447177344.024122,2,'info','Analyzed 700 files containing 9.55 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26344,1446922214.336647,2,'info','Starting password strength check on 1 users.');
INSERT INTO `wp_wfStatus` VALUES (26629,1447177343.906016,2,'info','Analyzed 600 files containing 7.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26044,1446768924.100524,1,'info','Contacting Wordfence to initiate scan');
INSERT INTO `wp_wfStatus` VALUES (26952,1447370640.115960,2,'info','Analyzed 500 files containing 6.14 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26442,1447062423.382388,1,'info','Scheduled Wordfence scan starting at Monday 9th of November 2015 05:47:03 AM');
INSERT INTO `wp_wfStatus` VALUES (26711,1447225947.182182,2,'info','Analyzed 700 files containing 9.55 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26986,1447370643.247857,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26144,1446780515.835088,2,'info','Analyzed 700 files containing 9.55 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26397,1446973963.614157,2,'info','Analyzed 1700 files containing 21.71 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26145,1446780515.917395,2,'info','Analyzed 800 files containing 9.6 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26391,1446973962.870799,2,'info','Analyzed 1100 files containing 12.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26392,1446973962.988855,2,'info','Analyzed 1200 files containing 14.27 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26393,1446973963.129132,2,'info','Analyzed 1300 files containing 16.07 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26394,1446973963.271234,2,'info','Analyzed 1400 files containing 18.56 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26395,1446973963.374780,2,'info','Analyzed 1500 files containing 19.43 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26396,1446973963.494227,2,'info','Analyzed 1600 files containing 20.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26095,1446768929.470257,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26874,1447316519.291003,2,'info','Analyzed 800 files containing 9.6 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26875,1447316519.371455,2,'info','Analyzed 900 files containing 9.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26544,1447090348.494938,2,'info','Analyzed 200 files containing 2.44 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26025,1446751401.220814,2,'info','Scanning DNS MX record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26024,1446751401.218043,2,'info','Scanning DNS A record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (27126,1447438397.142626,2,'info','Analyzed 1700 files containing 21.71 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27125,1447438397.022722,2,'info','Analyzed 1600 files containing 20.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26900,1447316521.792480,2,'info','Done database scan');
INSERT INTO `wp_wfStatus` VALUES (27118,1447438396.168167,2,'info','Analyzed 900 files containing 9.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26819,1447251208.347764,2,'info','Done database scan');
INSERT INTO `wp_wfStatus` VALUES (27119,1447438396.281582,2,'info','Analyzed 1000 files containing 11.22 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27120,1447438396.389787,2,'info','Analyzed 1100 files containing 12.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26818,1447251208.076525,2,'info','Starting scan of database');
INSERT INTO `wp_wfStatus` VALUES (27121,1447438396.510806,2,'info','Analyzed 1200 files containing 14.27 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26290,1446922209.220099,2,'info','Getting theme list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26407,1446973964.257211,2,'info','Checking 30 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (25819,1446651398.213590,2,'info','Analyzed 600 files containing 7.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25818,1446651398.092185,2,'info','Analyzed 500 files containing 6.14 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27112,1447438395.536079,2,'info','Analyzed 300 files containing 4.66 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26372,1446973960.380935,2,'info','Found 4 themes');
INSERT INTO `wp_wfStatus` VALUES (26370,1446973960.372155,2,'info','Found 4 plugins');
INSERT INTO `wp_wfStatus` VALUES (26371,1446973960.373434,2,'info','Getting theme list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26369,1446973960.369752,2,'info','Getting plugin list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26368,1446973960.023430,1,'info','Contacting Wordfence to initiate scan');
INSERT INTO `wp_wfStatus` VALUES (26611,1447177341.760693,1,'info','Contacting Wordfence to initiate scan');
INSERT INTO `wp_wfStatus` VALUES (26612,1447177342.058193,2,'info','Getting plugin list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26613,1447177342.060383,2,'info','Found 4 plugins');
INSERT INTO `wp_wfStatus` VALUES (26614,1447177342.061487,2,'info','Getting theme list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26615,1447177342.069060,2,'info','Found 4 themes');
INSERT INTO `wp_wfStatus` VALUES (27227,1447498623.997371,2,'info','Examining URLs found in posts we scanned for dangerous websites');
INSERT INTO `wp_wfStatus` VALUES (27035,1447399195.377710,2,'info','Analyzed 700 files containing 9.55 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25780,1446571733.572707,2,'info','Starting DNS scan for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (25781,1446571733.581477,2,'info','Scanning DNS A record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (25992,1446751399.134536,2,'info','Analyzed 1700 files containing 21.71 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25993,1446751399.263430,2,'info','Analyzed 1800 files containing 24.58 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25904,1446711252.719423,2,'info','Analyzed 1000 files containing 11.22 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25955,1446711256.342242,2,'info','Wordfence used 23.06MB of memory for scan. Server peak memory usage was: 43.65MB');
INSERT INTO `wp_wfStatus` VALUES (26940,1447370638.409747,10,'info','SUM_START:Fetching core, theme and plugin file signatures from Wordfence');
INSERT INTO `wp_wfStatus` VALUES (26941,1447370638.911272,10,'info','SUM_ENDSUCCESS:Fetching core, theme and plugin file signatures from Wordfence');
INSERT INTO `wp_wfStatus` VALUES (26009,1446751400.668551,2,'info','Done database scan');
INSERT INTO `wp_wfStatus` VALUES (27025,1447399194.225626,10,'info','SUM_START:Comparing core WordPress files against originals in repository');
INSERT INTO `wp_wfStatus` VALUES (26794,1447251205.776600,2,'info','Analyzed 900 files containing 9.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26795,1447251205.883814,2,'info','Analyzed 1000 files containing 11.22 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26796,1447251205.987806,2,'info','Analyzed 1100 files containing 12.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26206,1446868126.347566,1,'info','Contacting Wordfence to initiate scan');
INSERT INTO `wp_wfStatus` VALUES (26207,1446868126.697185,2,'info','Getting plugin list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26999,1447370643.510404,10,'info','SUM_START:Scanning to check available disk space');
INSERT INTO `wp_wfStatus` VALUES (26125,1446780513.403332,1,'info','Contacting Wordfence to initiate scan');
INSERT INTO `wp_wfStatus` VALUES (26126,1446780513.748419,2,'info','Getting plugin list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26127,1446780513.755494,2,'info','Found 4 plugins');
INSERT INTO `wp_wfStatus` VALUES (26128,1446780513.756754,2,'info','Getting theme list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26129,1446780513.765446,2,'info','Found 4 themes');
INSERT INTO `wp_wfStatus` VALUES (26485,1447062435.410812,2,'info','Starting scan of file contents');
INSERT INTO `wp_wfStatus` VALUES (26486,1447062435.529312,2,'info','Scanned contents of 16 additional files at 135.62 per second');
INSERT INTO `wp_wfStatus` VALUES (26291,1446922209.228421,2,'info','Found 4 themes');
INSERT INTO `wp_wfStatus` VALUES (27204,1447498622.097424,2,'info','Analyzed 1400 files containing 18.56 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26662,1447177347.089761,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26663,1447177347.090141,2,'info','Done examining URLs');
INSERT INTO `wp_wfStatus` VALUES (26661,1447177346.691540,2,'info','Checking 1 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (26660,1447177346.691261,2,'info','Examining URLs found in posts we scanned for dangerous websites');
INSERT INTO `wp_wfStatus` VALUES (26117,1446768930.440142,2,'info','Wordfence used 23.06MB of memory for scan. Server peak memory usage was: 43.65MB');
INSERT INTO `wp_wfStatus` VALUES (26926,1447316522.989762,10,'info','SUM_FINAL:Scan complete. You have 6 new issues to fix. See below.');
INSERT INTO `wp_wfStatus` VALUES (27198,1447498621.363086,2,'info','Analyzed 800 files containing 9.6 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26671,1447177347.338784,2,'info','Starting DNS scan for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (25840,1446651400.235934,2,'info','Checking 30 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (25841,1446651400.576163,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (25842,1446651400.577596,2,'info','Done file contents scan');
INSERT INTO `wp_wfStatus` VALUES (26002,1446751399.703852,2,'info','Checking 30 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (26045,1446768924.449127,2,'info','Getting plugin list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (27036,1447399195.514735,2,'info','Analyzed 800 files containing 9.6 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27037,1447399195.628521,2,'info','Analyzed 900 files containing 9.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27038,1447399195.754918,2,'info','Analyzed 1000 files containing 11.22 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27039,1447399195.889304,2,'info','Analyzed 1100 files containing 12.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27040,1447399196.055752,2,'info','Analyzed 1200 files containing 14.27 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27041,1447399196.277031,2,'info','Analyzed 1300 files containing 16.07 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27042,1447399196.520792,2,'info','Analyzed 1400 files containing 18.56 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27043,1447399196.697888,2,'info','Analyzed 1500 files containing 19.43 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27044,1447399196.886695,2,'info','Analyzed 1600 files containing 20.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27007,1447370643.838924,10,'info','SUM_FINAL:Scan complete. You have 6 new issues to fix. See below.');
INSERT INTO `wp_wfStatus` VALUES (27006,1447370643.838773,1,'info','Scan Complete. Scanned 1818 files, 4 plugins, 4 themes, 5 pages, 1 comments and 3855 records in 13 seconds.');
INSERT INTO `wp_wfStatus` VALUES (27005,1447370643.838604,1,'info','-------------------');
INSERT INTO `wp_wfStatus` VALUES (26758,1447225950.349109,2,'info','The disk has 30909.22 MB space available');
INSERT INTO `wp_wfStatus` VALUES (26757,1447225950.348918,2,'info','Total disk space: 46.9759GB -- Free disk space: 30.1848GB');
INSERT INTO `wp_wfStatus` VALUES (27152,1447438398.994983,10,'info','SUM_ENDOK:Scanning comments for URL\'s in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (27153,1447438398.996623,10,'info','SUM_START:Scanning for weak passwords');
INSERT INTO `wp_wfStatus` VALUES (26754,1447225950.346356,2,'info','Scanning DNS MX record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26488,1447062435.531452,2,'info','Checking 30 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (26489,1447062435.875503,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26171,1446780518.483059,2,'info','Done database scan');
INSERT INTO `wp_wfStatus` VALUES (26465,1447062433.461489,2,'info','Analyzed 400 files containing 5.25 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26033,1446751401.856322,1,'info','-------------------');
INSERT INTO `wp_wfStatus` VALUES (26895,1447316521.195834,2,'info','Done file contents scan');
INSERT INTO `wp_wfStatus` VALUES (26896,1447316521.196242,10,'info','SUM_ENDOK:Scanning file contents for infections and vulnerabilities');
INSERT INTO `wp_wfStatus` VALUES (26897,1447316521.197278,10,'info','SUM_ENDOK:Scanning files for URLs in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (26898,1447316521.198867,10,'info','SUM_START:Scanning database for infections and vulnerabilities');
INSERT INTO `wp_wfStatus` VALUES (26096,1446768929.470652,2,'info','Done examining URLs');
INSERT INTO `wp_wfStatus` VALUES (26921,1447316522.352663,10,'info','SUM_ENDOK:Scanning to check available disk space');
INSERT INTO `wp_wfStatus` VALUES (26029,1446751401.223581,2,'info','The disk has 30991.70 MB space available');
INSERT INTO `wp_wfStatus` VALUES (26028,1446751401.223422,2,'info','Total disk space: 46.9759GB -- Free disk space: 30.2653GB');
INSERT INTO `wp_wfStatus` VALUES (26543,1447090348.392031,2,'info','Analyzed 100 files containing 1.36 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26408,1446973964.550732,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26409,1446973964.551885,2,'info','Done file contents scan');
INSERT INTO `wp_wfStatus` VALUES (26972,1447370642.039476,2,'info','Scanned contents of 16 additional files at 154.69 per second');
INSERT INTO `wp_wfStatus` VALUES (26228,1446868129.031555,2,'info','Analyzed 1000 files containing 11.22 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25927,1446711254.802194,2,'info','Starting scan of database');
INSERT INTO `wp_wfStatus` VALUES (27205,1447498622.201988,2,'info','Analyzed 1500 files containing 19.43 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27206,1447498622.320059,2,'info','Analyzed 1600 files containing 20.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26715,1447225947.549708,2,'info','Analyzed 1100 files containing 12.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25928,1446711255.070903,2,'info','Done database scan');
INSERT INTO `wp_wfStatus` VALUES (26226,1446868128.833146,2,'info','Analyzed 800 files containing 9.6 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26227,1446868128.917729,2,'info','Analyzed 900 files containing 9.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27064,1447399198.509153,10,'info','SUM_START:Scanning posts for URL\'s in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (27065,1447399198.511169,2,'info','Examining URLs found in posts we scanned for dangerous websites');
INSERT INTO `wp_wfStatus` VALUES (27193,1447498620.838885,2,'info','Analyzed 300 files containing 4.66 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26263,1446868131.708355,2,'info','Starting password strength check on 1 users.');
INSERT INTO `wp_wfStatus` VALUES (26014,1446751400.964100,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26015,1446751400.964492,2,'info','Done examining URLs');
INSERT INTO `wp_wfStatus` VALUES (26550,1447090349.142855,2,'info','Analyzed 800 files containing 9.6 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27156,1447438399.242721,10,'info','SUM_START:Scanning DNS for unauthorized changes');
INSERT INTO `wp_wfStatus` VALUES (26749,1447225950.094822,2,'info','Starting password strength check on 1 users.');
INSERT INTO `wp_wfStatus` VALUES (27157,1447438399.242966,2,'info','Starting DNS scan for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (27158,1447438399.251387,2,'info','Scanning DNS A record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (27159,1447438399.253786,2,'info','Scanning DNS MX record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (27161,1447438399.256082,10,'info','SUM_START:Scanning to check available disk space');
INSERT INTO `wp_wfStatus` VALUES (27160,1447438399.254507,10,'info','SUM_ENDOK:Scanning DNS for unauthorized changes');
INSERT INTO `wp_wfStatus` VALUES (26318,1446922212.483215,2,'info','Analyzed 1818 files containing 24.98 MB of data.');
INSERT INTO `wp_wfStatus` VALUES (25758,1446571732.052989,2,'info','Asking Wordfence to check URL\'s against malware list.');
INSERT INTO `wp_wfStatus` VALUES (25759,1446571732.054205,2,'info','Checking 30 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (25760,1446571732.409565,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (25761,1446571732.410667,2,'info','Done file contents scan');
INSERT INTO `wp_wfStatus` VALUES (25861,1446651401.792141,2,'info','Starting DNS scan for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (25785,1446571733.586435,2,'info','Total disk space: 46.9759GB -- Free disk space: 30.2736GB');
INSERT INTO `wp_wfStatus` VALUES (26308,1446922211.357688,2,'info','Analyzed 900 files containing 9.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26307,1446922211.279823,2,'info','Analyzed 800 files containing 9.6 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26908,1447316522.094464,10,'info','SUM_START:Scanning comments for URL\'s in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (26907,1447316522.092830,10,'info','SUM_ENDOK:Scanning posts for URL\'s in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (26906,1447316522.091918,2,'info','Done examining URLs');
INSERT INTO `wp_wfStatus` VALUES (26905,1447316522.091545,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (27232,1447498624.358667,10,'info','SUM_START:Scanning comments for URL\'s in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (27233,1447498624.365202,10,'info','SUM_ENDOK:Scanning comments for URL\'s in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (25987,1446751398.549361,2,'info','Analyzed 1200 files containing 14.27 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25988,1446751398.679727,2,'info','Analyzed 1300 files containing 16.07 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25989,1446751398.814932,2,'info','Analyzed 1400 files containing 18.56 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26977,1447370642.340940,10,'info','SUM_ENDOK:Scanning file contents for infections and vulnerabilities');
INSERT INTO `wp_wfStatus` VALUES (26559,1447090350.179104,2,'info','Analyzed 1700 files containing 21.71 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26911,1447316522.099528,2,'info','Starting password strength check on 1 users.');
INSERT INTO `wp_wfStatus` VALUES (25994,1446751399.285425,2,'info','Analyzed 1818 files containing 24.98 MB of data.');
INSERT INTO `wp_wfStatus` VALUES (26560,1447090350.313316,2,'info','Analyzed 1800 files containing 24.58 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26561,1447090350.336248,2,'info','Analyzed 1818 files containing 24.98 MB of data.');
INSERT INTO `wp_wfStatus` VALUES (26893,1447316520.903252,2,'info','Checking 30 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (26894,1447316521.194628,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26800,1447251206.580936,2,'info','Analyzed 1500 files containing 19.43 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25825,1446651398.889699,2,'info','Analyzed 1200 files containing 14.27 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25824,1446651398.739367,2,'info','Analyzed 1100 files containing 12.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25823,1446651398.637681,2,'info','Analyzed 1000 files containing 11.22 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25822,1446651398.503413,2,'info','Analyzed 900 files containing 9.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25939,1446711255.381907,2,'info','Starting password strength check on 1 users.');
INSERT INTO `wp_wfStatus` VALUES (26777,1447251203.656919,2,'info','Found 4 themes');
INSERT INTO `wp_wfStatus` VALUES (27135,1447438397.705090,2,'info','Asking Wordfence to check URL\'s against malware list.');
INSERT INTO `wp_wfStatus` VALUES (27134,1447438397.704919,2,'info','Scanned contents of 16 additional files at 152.15 per second');
INSERT INTO `wp_wfStatus` VALUES (27133,1447438397.599353,2,'info','Starting scan of file contents');
INSERT INTO `wp_wfStatus` VALUES (27132,1447438397.313331,10,'info','SUM_START:Scanning files for URLs in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (26468,1447062433.798455,2,'info','Analyzed 700 files containing 9.55 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26955,1447370640.434564,2,'info','Analyzed 800 files containing 9.6 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26954,1447370640.353207,2,'info','Analyzed 700 files containing 9.55 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26302,1446922210.757667,2,'info','Analyzed 300 files containing 4.66 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26277,1446868132.655363,1,'info','Scan Complete. Scanned 1818 files, 4 plugins, 4 themes, 5 pages, 1 comments and 3745 records in 14 seconds.');
INSERT INTO `wp_wfStatus` VALUES (26154,1446780516.950068,2,'info','Analyzed 1700 files containing 21.71 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27051,1447399197.175748,10,'info','SUM_START:Scanning files for URLs in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (27050,1447399197.174788,10,'info','SUM_START:Scanning file contents for infections and vulnerabilities');
INSERT INTO `wp_wfStatus` VALUES (27049,1447399197.166364,10,'info','SUM_ENDOK:Scanning for known malware files');
INSERT INTO `wp_wfStatus` VALUES (27048,1447399197.165173,10,'info','SUM_ENDOK:Comparing core WordPress files against originals in repository');
INSERT INTO `wp_wfStatus` VALUES (26753,1447225950.343919,2,'info','Scanning DNS A record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26752,1447225950.335429,2,'info','Starting DNS scan for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (25984,1446751398.226277,2,'info','Analyzed 900 files containing 9.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27188,1447498620.476733,10,'info','SUM_DISABLED:Skipping theme scan');
INSERT INTO `wp_wfStatus` VALUES (27187,1447498620.476117,10,'info','SUM_START:Comparing core WordPress files against originals in repository');
INSERT INTO `wp_wfStatus` VALUES (26251,1446868131.141783,2,'info','Starting scan of database');
INSERT INTO `wp_wfStatus` VALUES (26252,1446868131.405354,2,'info','Done database scan');
INSERT INTO `wp_wfStatus` VALUES (26843,1447251209.585787,1,'info','-------------------');
INSERT INTO `wp_wfStatus` VALUES (26844,1447251209.585952,1,'info','Scan Complete. Scanned 1818 files, 4 plugins, 4 themes, 5 pages, 1 comments and 3967 records in 14 seconds.');
INSERT INTO `wp_wfStatus` VALUES (26846,1447251209.588535,2,'info','Wordfence used 23.06MB of memory for scan. Server peak memory usage was: 43.65MB');
INSERT INTO `wp_wfStatus` VALUES (27101,1447438393.965470,2,'info','Found 4 themes');
INSERT INTO `wp_wfStatus` VALUES (27102,1447438393.969292,10,'info','SUM_START:Fetching core, theme and plugin file signatures from Wordfence');
INSERT INTO `wp_wfStatus` VALUES (26001,1446751399.702972,2,'info','Asking Wordfence to check URL\'s against malware list.');
INSERT INTO `wp_wfStatus` VALUES (27200,1447498621.561123,2,'info','Analyzed 1000 files containing 11.22 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27201,1447498621.668959,2,'info','Analyzed 1100 files containing 12.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27199,1447498621.447747,2,'info','Analyzed 900 files containing 9.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26668,1447177347.097769,2,'info','Starting password strength check on 1 users.');
INSERT INTO `wp_wfStatus` VALUES (27222,1447498623.393683,10,'info','SUM_START:Scanning database for infections and vulnerabilities');
INSERT INTO `wp_wfStatus` VALUES (26470,1447062433.958234,2,'info','Analyzed 900 files containing 9.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25979,1446751397.674023,2,'info','Analyzed 400 files containing 5.25 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27029,1447399194.411491,2,'info','Analyzed 100 files containing 1.36 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27030,1447399194.577739,2,'info','Analyzed 200 files containing 2.44 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26789,1447251205.283116,2,'info','Analyzed 400 files containing 5.25 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25772,1446571733.319074,2,'info','Done examining URLs');
INSERT INTO `wp_wfStatus` VALUES (26314,1446922212.105069,2,'info','Analyzed 1500 files containing 19.43 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25737,1446571730.072181,2,'info','Analyzed 500 files containing 6.14 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25738,1446571730.190474,2,'info','Analyzed 600 files containing 7.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27113,1447438395.639793,2,'info','Analyzed 400 files containing 5.25 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26289,1446922209.218943,2,'info','Found 4 plugins');
INSERT INTO `wp_wfStatus` VALUES (26288,1446922209.216743,2,'info','Getting plugin list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26287,1446922208.865743,1,'info','Contacting Wordfence to initiate scan');
INSERT INTO `wp_wfStatus` VALUES (25814,1446651397.644138,2,'info','Analyzed 100 files containing 1.36 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26809,1447251207.376588,2,'info','Starting scan of file contents');
INSERT INTO `wp_wfStatus` VALUES (26360,1446922215.357247,2,'info','Wordfence used 23.05MB of memory for scan. Server peak memory usage was: 43.65MB');
INSERT INTO `wp_wfStatus` VALUES (26361,1446973891.536251,1,'info','Scheduled Wordfence scan starting at Sunday 8th of November 2015 05:11:31 AM');
INSERT INTO `wp_wfStatus` VALUES (25771,1446571733.318700,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (27026,1447399194.226193,10,'info','SUM_DISABLED:Skipping theme scan');
INSERT INTO `wp_wfStatus` VALUES (27027,1447399194.226586,10,'info','SUM_DISABLED:Skipping plugin scan');
INSERT INTO `wp_wfStatus` VALUES (27028,1447399194.227554,10,'info','SUM_START:Scanning for known malware files');
INSERT INTO `wp_wfStatus` VALUES (26931,1447370632.654525,10,'info','SUM_PAIDONLY:Check if your site is being Spamvertized is for paid members only');
INSERT INTO `wp_wfStatus` VALUES (26930,1447370630.654135,10,'info','SUM_PAIDONLY:Remote scan of public facing site only available to paid members');
INSERT INTO `wp_wfStatus` VALUES (27251,1447498625.263762,2,'info','Wordfence used 23.06MB of memory for scan. Server peak memory usage was: 43.65MB');
INSERT INTO `wp_wfStatus` VALUES (27250,1447498625.261035,10,'info','SUM_FINAL:Scan complete. You have 6 new issues to fix. See below.');
INSERT INTO `wp_wfStatus` VALUES (27248,1447498625.260724,1,'info','-------------------');
INSERT INTO `wp_wfStatus` VALUES (27249,1447498625.260887,1,'info','Scan Complete. Scanned 1818 files, 4 plugins, 4 themes, 5 pages, 1 comments and 3850 records in 14 seconds.');
INSERT INTO `wp_wfStatus` VALUES (27247,1447498625.251790,10,'info','SUM_ENDBAD:Scanning for old themes, plugins and core files');
INSERT INTO `wp_wfStatus` VALUES (27246,1447498624.626266,10,'info','SUM_START:Scanning for old themes, plugins and core files');
INSERT INTO `wp_wfStatus` VALUES (27245,1447498624.624661,10,'info','SUM_ENDOK:Scanning to check available disk space');
INSERT INTO `wp_wfStatus` VALUES (27210,1447498622.601234,10,'info','SUM_ENDOK:Comparing core WordPress files against originals in repository');
INSERT INTO `wp_wfStatus` VALUES (26657,1447177346.686769,2,'info','Done database scan');
INSERT INTO `wp_wfStatus` VALUES (25801,1446651395.881256,1,'info','Contacting Wordfence to initiate scan');
INSERT INTO `wp_wfStatus` VALUES (25802,1446651396.222354,2,'info','Getting plugin list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (25803,1446651396.226932,2,'info','Found 4 plugins');
INSERT INTO `wp_wfStatus` VALUES (25770,1446571733.025171,2,'info','Checking 1 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (26722,1447225948.388347,2,'info','Analyzed 1800 files containing 24.57 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26721,1447225948.262371,2,'info','Analyzed 1700 files containing 21.71 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26553,1447090349.429495,2,'info','Analyzed 1100 files containing 12.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27172,1447498611.456990,10,'info','SUM_PREP:Preparing a new scan.');
INSERT INTO `wp_wfStatus` VALUES (26723,1447225948.409567,2,'info','Analyzed 1817 files containing 24.98 MB of data.');
INSERT INTO `wp_wfStatus` VALUES (27173,1447498611.461310,10,'info','SUM_PAIDONLY:Remote scan of public facing site only available to paid members');
INSERT INTO `wp_wfStatus` VALUES (25847,1446651401.190457,2,'info','Done database scan');
INSERT INTO `wp_wfStatus` VALUES (27147,1447438398.664552,2,'info','Checking 1 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (27062,1447399198.506742,2,'info','Done database scan');
INSERT INTO `wp_wfStatus` VALUES (27060,1447399197.909971,10,'info','SUM_START:Scanning database for infections and vulnerabilities');
INSERT INTO `wp_wfStatus` VALUES (27061,1447399198.242849,2,'info','Starting scan of database');
INSERT INTO `wp_wfStatus` VALUES (25922,1446711254.455000,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (25923,1446711254.456194,2,'info','Done file contents scan');
INSERT INTO `wp_wfStatus` VALUES (26231,1446868129.397909,2,'info','Analyzed 1300 files containing 16.07 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26232,1446868129.545107,2,'info','Analyzed 1400 files containing 18.56 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25862,1446651401.949280,2,'info','Scanning DNS A record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (25827,1446651399.262914,2,'info','Analyzed 1400 files containing 18.56 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26163,1446780517.577575,2,'info','Asking Wordfence to check URL\'s against malware list.');
INSERT INTO `wp_wfStatus` VALUES (26162,1446780517.577396,2,'info','Scanned contents of 16 additional files at 142.54 per second');
INSERT INTO `wp_wfStatus` VALUES (26161,1446780517.464746,2,'info','Starting scan of file contents');
INSERT INTO `wp_wfStatus` VALUES (27138,1447438398.038181,2,'info','Done file contents scan');
INSERT INTO `wp_wfStatus` VALUES (26382,1446973961.878131,2,'info','Analyzed 200 files containing 2.44 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26234,1446868129.783136,2,'info','Analyzed 1600 files containing 20.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26233,1446868129.651169,2,'info','Analyzed 1500 files containing 19.43 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25918,1446711254.056716,2,'info','Starting scan of file contents');
INSERT INTO `wp_wfStatus` VALUES (25919,1446711254.162041,2,'info','Scanned contents of 16 additional files at 152.50 per second');
INSERT INTO `wp_wfStatus` VALUES (26775,1447251203.646412,2,'info','Found 4 plugins');
INSERT INTO `wp_wfStatus` VALUES (25782,1446571733.583673,2,'info','Scanning DNS MX record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26530,1447090346.858352,1,'info','Contacting Wordfence to initiate scan');
INSERT INTO `wp_wfStatus` VALUES (27075,1447399199.120726,10,'info','SUM_START:Scanning DNS for unauthorized changes');
INSERT INTO `wp_wfStatus` VALUES (26568,1447090350.748383,2,'info','Asking Wordfence to check URL\'s against malware list.');
INSERT INTO `wp_wfStatus` VALUES (25696,1446557634.645579,2,'info','Starting password strength check on 1 users.');
INSERT INTO `wp_wfStatus` VALUES (26222,1446868128.394767,2,'info','Analyzed 400 files containing 5.25 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25933,1446711255.374770,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (25934,1446711255.375132,2,'info','Done examining URLs');
INSERT INTO `wp_wfStatus` VALUES (25932,1446711255.075678,2,'info','Checking 1 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (25913,1446711253.702565,2,'info','Analyzed 1818 files containing 24.98 MB of data.');
INSERT INTO `wp_wfStatus` VALUES (25912,1446711253.680205,2,'info','Analyzed 1800 files containing 24.58 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27178,1447498618.875456,1,'info','Contacting Wordfence to initiate scan');
INSERT INTO `wp_wfStatus` VALUES (27177,1447498618.874026,10,'info','SUM_ENDOK:Scanning your site for the HeartBleed vulnerability');
INSERT INTO `wp_wfStatus` VALUES (27154,1447438398.997334,2,'info','Starting password strength check on 1 users.');
INSERT INTO `wp_wfStatus` VALUES (27155,1447438399.240909,10,'info','SUM_ENDOK:Scanning for weak passwords');
INSERT INTO `wp_wfStatus` VALUES (26847,1447316450.688125,1,'info','Scheduled Wordfence scan starting at Thursday 12th of November 2015 04:20:50 AM');
INSERT INTO `wp_wfStatus` VALUES (27100,1447438393.958559,2,'info','Getting theme list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (27099,1447438393.957045,2,'info','Found 4 plugins');
INSERT INTO `wp_wfStatus` VALUES (27097,1447438393.669625,1,'info','Contacting Wordfence to initiate scan');
INSERT INTO `wp_wfStatus` VALUES (27098,1447438393.954869,2,'info','Getting plugin list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (27096,1447438393.668656,10,'info','SUM_ENDOK:Scanning your site for the HeartBleed vulnerability');
INSERT INTO `wp_wfStatus` VALUES (27095,1447438392.154240,10,'info','SUM_START:Scanning your site for the HeartBleed vulnerability');
INSERT INTO `wp_wfStatus` VALUES (27094,1447438390.152276,10,'info','SUM_PAIDONLY:Checking if your IP is generating spam is for paid members only');
INSERT INTO `wp_wfStatus` VALUES (26854,1447316516.822467,1,'info','Contacting Wordfence to initiate scan');
INSERT INTO `wp_wfStatus` VALUES (26855,1447316517.148251,2,'info','Getting plugin list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26856,1447316517.150482,2,'info','Found 4 plugins');
INSERT INTO `wp_wfStatus` VALUES (26857,1447316517.151649,2,'info','Getting theme list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26858,1447316517.153481,2,'info','Found 4 themes');
INSERT INTO `wp_wfStatus` VALUES (26419,1446973965.532063,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26420,1446973965.532446,2,'info','Done examining URLs');
INSERT INTO `wp_wfStatus` VALUES (26500,1447062436.841700,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26501,1447062436.842082,2,'info','Done examining URLs');
INSERT INTO `wp_wfStatus` VALUES (26963,1447370641.323342,2,'info','Analyzed 1600 files containing 20.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26425,1446973965.539715,2,'info','Starting password strength check on 1 users.');
INSERT INTO `wp_wfStatus` VALUES (26964,1447370641.440123,2,'info','Analyzed 1700 files containing 21.71 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26967,1447370641.596768,10,'info','SUM_ENDOK:Comparing core WordPress files against originals in repository');
INSERT INTO `wp_wfStatus` VALUES (26966,1447370641.596383,2,'info','Analyzed 1818 files containing 24.98 MB of data.');
INSERT INTO `wp_wfStatus` VALUES (26965,1447370641.574266,2,'info','Analyzed 1800 files containing 24.58 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26880,1447316519.970641,2,'info','Analyzed 1400 files containing 18.56 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26881,1447316520.071498,2,'info','Analyzed 1500 files containing 19.43 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26580,1447090351.663867,2,'info','Checking 1 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (27055,1447399197.610188,2,'info','Checking 30 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (27056,1447399197.905684,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (27057,1447399197.906914,2,'info','Done file contents scan');
INSERT INTO `wp_wfStatus` VALUES (27058,1447399197.907312,10,'info','SUM_ENDOK:Scanning file contents for infections and vulnerabilities');
INSERT INTO `wp_wfStatus` VALUES (25901,1446711252.449270,2,'info','Analyzed 700 files containing 9.55 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25900,1446711252.329597,2,'info','Analyzed 600 files containing 7.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25899,1446711252.210508,2,'info','Analyzed 500 files containing 6.14 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25898,1446711252.108670,2,'info','Analyzed 400 files containing 5.25 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26872,1447316519.094240,2,'info','Analyzed 600 files containing 7.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26587,1447090352.005747,2,'info','Starting password strength check on 1 users.');
INSERT INTO `wp_wfStatus` VALUES (27194,1447498620.939229,2,'info','Analyzed 400 files containing 5.25 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25858,1446651401.550960,2,'info','Starting password strength check on 1 users.');
INSERT INTO `wp_wfStatus` VALUES (26272,1446868132.016075,2,'info','The disk has 30986.04 MB space available');
INSERT INTO `wp_wfStatus` VALUES (26271,1446868132.015921,2,'info','Total disk space: 46.9759GB -- Free disk space: 30.2598GB');
INSERT INTO `wp_wfStatus` VALUES (25794,1446651328.402182,1,'info','Scheduled Wordfence scan starting at Wednesday 4th of November 2015 11:35:28 AM');
INSERT INTO `wp_wfStatus` VALUES (27072,1447399198.847790,10,'info','SUM_START:Scanning for weak passwords');
INSERT INTO `wp_wfStatus` VALUES (27004,1447370643.830511,10,'info','SUM_ENDBAD:Scanning for old themes, plugins and core files');
INSERT INTO `wp_wfStatus` VALUES (26037,1446768915.303140,1,'info','Scheduled Wordfence scan starting at Thursday 5th of November 2015 08:15:15 PM');
INSERT INTO `wp_wfStatus` VALUES (27052,1447399197.503924,2,'info','Starting scan of file contents');
INSERT INTO `wp_wfStatus` VALUES (27053,1447399197.609371,2,'info','Scanned contents of 16 additional files at 152.34 per second');
INSERT INTO `wp_wfStatus` VALUES (26804,1447251207.036729,2,'info','Analyzed 1818 files containing 24.98 MB of data.');
INSERT INTO `wp_wfStatus` VALUES (26803,1447251207.006351,2,'info','Analyzed 1800 files containing 24.58 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25724,1446571728.288432,2,'info','Found 4 themes');
INSERT INTO `wp_wfStatus` VALUES (26650,1447177345.740740,2,'info','Checking 30 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (26684,1447177347.988465,2,'info','Wordfence used 23.05MB of memory for scan. Server peak memory usage was: 43.65MB');
INSERT INTO `wp_wfStatus` VALUES (27192,1447498620.699782,2,'info','Analyzed 200 files containing 2.44 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25875,1446711241.460184,1,'info','Scheduled Wordfence scan starting at Thursday 5th of November 2015 04:14:01 AM');
INSERT INTO `wp_wfStatus` VALUES (25874,1446651402.594857,2,'info','Wordfence used 23.06MB of memory for scan. Server peak memory usage was: 43.65MB');
INSERT INTO `wp_wfStatus` VALUES (25851,1446651401.195671,2,'info','Checking 1 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (27171,1447498611.051148,1,'info','Scheduled Wordfence scan starting at Saturday 14th of November 2015 06:56:51 AM');
INSERT INTO `wp_wfStatus` VALUES (26801,1447251206.742901,2,'info','Analyzed 1600 files containing 20.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26802,1447251206.860837,2,'info','Analyzed 1700 files containing 21.71 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26104,1446768929.719295,2,'info','Starting DNS scan for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26499,1447062436.500169,2,'info','Checking 1 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (26258,1446868131.700726,2,'info','Done examining URLs');
INSERT INTO `wp_wfStatus` VALUES (27191,1447498620.596191,2,'info','Analyzed 100 files containing 1.36 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26685,1447225876.379792,1,'info','Scheduled Wordfence scan starting at Wednesday 11th of November 2015 03:11:16 AM');
INSERT INTO `wp_wfStatus` VALUES (26575,1447090351.393135,2,'info','Starting scan of database');
INSERT INTO `wp_wfStatus` VALUES (26576,1447090351.659038,2,'info','Done database scan');
INSERT INTO `wp_wfStatus` VALUES (27228,1447498623.997680,2,'info','Checking 1 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (25691,1446557634.632680,2,'info','Done examining URLs');
INSERT INTO `wp_wfStatus` VALUES (26892,1447316520.901201,2,'info','Asking Wordfence to check URL\'s against malware list.');
INSERT INTO `wp_wfStatus` VALUES (27169,1447438399.893308,10,'info','SUM_FINAL:Scan complete. You have 6 new issues to fix. See below.');
INSERT INTO `wp_wfStatus` VALUES (27170,1447438399.895975,2,'info','Wordfence used 23.05MB of memory for scan. Server peak memory usage was: 43.65MB');
INSERT INTO `wp_wfStatus` VALUES (25956,1446751327.128187,1,'info','Scheduled Wordfence scan starting at Thursday 5th of November 2015 03:22:07 PM');
INSERT INTO `wp_wfStatus` VALUES (26649,1447177345.738247,2,'info','Asking Wordfence to check URL\'s against malware list.');
INSERT INTO `wp_wfStatus` VALUES (26839,1447251208.948640,2,'info','The disk has 30907.92 MB space available');
INSERT INTO `wp_wfStatus` VALUES (27103,1447438394.536515,10,'info','SUM_ENDSUCCESS:Fetching core, theme and plugin file signatures from Wordfence');
INSERT INTO `wp_wfStatus` VALUES (27104,1447438394.538253,10,'info','SUM_START:Fetching list of known malware files from Wordfence');
INSERT INTO `wp_wfStatus` VALUES (27105,1447438395.171858,10,'info','SUM_ENDSUCCESS:Fetching list of known malware files from Wordfence');
INSERT INTO `wp_wfStatus` VALUES (26549,1447090349.063574,2,'info','Analyzed 700 files containing 9.55 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26548,1447090348.945092,2,'info','Analyzed 600 files containing 7.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27033,1447399195.001254,2,'info','Analyzed 500 files containing 6.14 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27034,1447399195.194665,2,'info','Analyzed 600 files containing 7.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26309,1446922211.469133,2,'info','Analyzed 1000 files containing 11.22 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25713,1446571660.470647,1,'info','Scheduled Wordfence scan starting at Tuesday 3rd of November 2015 01:27:40 PM');
INSERT INTO `wp_wfStatus` VALUES (26797,1447251206.100875,2,'info','Analyzed 1200 files containing 14.27 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25769,1446571733.024896,2,'info','Examining URLs found in posts we scanned for dangerous websites');
INSERT INTO `wp_wfStatus` VALUES (26315,1446922212.216662,2,'info','Analyzed 1600 files containing 20.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26383,1446973962.020702,2,'info','Analyzed 300 files containing 4.66 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27067,1447399198.841478,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26182,1446780518.784413,2,'info','Starting password strength check on 1 users.');
INSERT INTO `wp_wfStatus` VALUES (26942,1447370638.913744,10,'info','SUM_START:Fetching list of known malware files from Wordfence');
INSERT INTO `wp_wfStatus` VALUES (26352,1446922214.694131,2,'info','Total disk space: 46.9759GB -- Free disk space: 30.2574GB');
INSERT INTO `wp_wfStatus` VALUES (26353,1446922214.694385,2,'info','The disk has 30983.59 MB space available');
INSERT INTO `wp_wfStatus` VALUES (26625,1447177343.450078,2,'info','Analyzed 200 files containing 2.44 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27217,1447498623.049287,2,'info','Checking 30 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (26624,1447177343.345322,2,'info','Analyzed 100 files containing 1.36 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27218,1447498623.389336,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (27219,1447498623.390522,2,'info','Done file contents scan');
INSERT INTO `wp_wfStatus` VALUES (27220,1447498623.390937,10,'info','SUM_ENDOK:Scanning file contents for infections and vulnerabilities');
INSERT INTO `wp_wfStatus` VALUES (26208,1446868126.702702,2,'info','Found 4 plugins');
INSERT INTO `wp_wfStatus` VALUES (27080,1447399199.133303,10,'info','SUM_START:Scanning to check available disk space');
INSERT INTO `wp_wfStatus` VALUES (26982,1447370642.939198,10,'info','SUM_ENDOK:Scanning database for infections and vulnerabilities');
INSERT INTO `wp_wfStatus` VALUES (26983,1447370642.940907,10,'info','SUM_START:Scanning posts for URL\'s in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (26453,1447062431.698866,2,'info','Found 4 themes');
INSERT INTO `wp_wfStatus` VALUES (25882,1446711250.218136,1,'info','Contacting Wordfence to initiate scan');
INSERT INTO `wp_wfStatus` VALUES (27221,1447498623.391967,10,'info','SUM_ENDOK:Scanning files for URLs in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (26357,1446922215.352127,1,'info','-------------------');
INSERT INTO `wp_wfStatus` VALUES (26358,1446922215.352454,1,'info','Scan Complete. Scanned 1818 files, 4 plugins, 4 themes, 5 pages, 1 comments and 3855 records in 14 seconds.');
INSERT INTO `wp_wfStatus` VALUES (26074,1446768927.784901,2,'info','Analyzed 1800 files containing 24.58 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25735,1446571729.868425,2,'info','Analyzed 300 files containing 4.66 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26118,1446780445.343311,1,'info','Scheduled Wordfence scan starting at Thursday 5th of November 2015 11:27:25 PM');
INSERT INTO `wp_wfStatus` VALUES (26927,1447316522.992237,2,'info','Wordfence used 23.05MB of memory for scan. Server peak memory usage was: 43.65MB');
INSERT INTO `wp_wfStatus` VALUES (26928,1447370630.143267,1,'info','Scheduled Wordfence scan starting at Thursday 12th of November 2015 07:23:50 PM');
INSERT INTO `wp_wfStatus` VALUES (26175,1446780518.488661,2,'info','Checking 1 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (26176,1446780518.777683,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26177,1446780518.778076,2,'info','Done examining URLs');
INSERT INTO `wp_wfStatus` VALUES (26933,1447370636.658539,10,'info','SUM_START:Scanning your site for the HeartBleed vulnerability');
INSERT INTO `wp_wfStatus` VALUES (26462,1447062433.124876,2,'info','Analyzed 100 files containing 1.36 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26463,1447062433.229572,2,'info','Analyzed 200 files containing 2.44 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26464,1447062433.365440,2,'info','Analyzed 300 files containing 4.66 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26838,1447251208.948485,2,'info','Total disk space: 46.9759GB -- Free disk space: 30.1835GB');
INSERT INTO `wp_wfStatus` VALUES (27106,1447438395.173590,10,'info','SUM_START:Comparing core WordPress files against originals in repository');
INSERT INTO `wp_wfStatus` VALUES (26833,1447251208.936402,2,'info','Starting DNS scan for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26834,1447251208.943503,2,'info','Scanning DNS A record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26835,1447251208.945941,2,'info','Scanning DNS MX record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (25952,1446711256.339431,1,'info','-------------------');
INSERT INTO `wp_wfStatus` VALUES (25953,1446711256.339594,1,'info','Scan Complete. Scanned 1818 files, 4 plugins, 4 themes, 5 pages, 1 comments and 3752 records in 14 seconds.');
INSERT INTO `wp_wfStatus` VALUES (26209,1446868126.703834,2,'info','Getting theme list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26210,1446868126.715903,2,'info','Found 4 themes');
INSERT INTO `wp_wfStatus` VALUES (26478,1447062434.888789,2,'info','Analyzed 1700 files containing 21.71 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27000,1447370643.510626,2,'info','Total disk space: 46.9759GB -- Free disk space: 30.1779GB');
INSERT INTO `wp_wfStatus` VALUES (26824,1447251208.680884,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26823,1447251208.352664,2,'info','Checking 1 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (26140,1446780515.399032,2,'info','Analyzed 300 files containing 4.66 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26141,1446780515.497883,2,'info','Analyzed 400 files containing 5.25 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26142,1446780515.600728,2,'info','Analyzed 500 files containing 6.14 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26143,1446780515.717549,2,'info','Analyzed 600 files containing 7.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26347,1446922214.680324,2,'info','Starting DNS scan for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26917,1447316522.350355,10,'info','SUM_ENDOK:Scanning DNS for unauthorized changes');
INSERT INTO `wp_wfStatus` VALUES (26510,1447062437.105392,2,'info','Scanning DNS A record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26511,1447062437.109672,2,'info','Scanning DNS MX record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26918,1447316522.351942,10,'info','SUM_START:Scanning to check available disk space');
INSERT INTO `wp_wfStatus` VALUES (26235,1446868129.919905,2,'info','Analyzed 1700 files containing 21.71 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26236,1446868130.053018,2,'info','Analyzed 1800 files containing 24.58 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26237,1446868130.075397,2,'info','Analyzed 1818 files containing 24.98 MB of data.');
INSERT INTO `wp_wfStatus` VALUES (25983,1446751398.137974,2,'info','Analyzed 800 files containing 9.6 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25982,1446751398.060317,2,'info','Analyzed 700 files containing 9.55 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25981,1446751397.909512,2,'info','Analyzed 600 files containing 7.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27244,1447498624.624357,2,'info','The disk has 30715.07 MB space available');
INSERT INTO `wp_wfStatus` VALUES (27243,1447498624.624216,2,'info','Total disk space: 46.9759GB -- Free disk space: 29.9952GB');
INSERT INTO `wp_wfStatus` VALUES (27234,1447498624.366829,10,'info','SUM_START:Scanning for weak passwords');
INSERT INTO `wp_wfStatus` VALUES (27235,1447498624.367686,2,'info','Starting password strength check on 1 users.');
INSERT INTO `wp_wfStatus` VALUES (27236,1447498624.612256,10,'info','SUM_ENDOK:Scanning for weak passwords');
INSERT INTO `wp_wfStatus` VALUES (27237,1447498624.614101,10,'info','SUM_START:Scanning DNS for unauthorized changes');
INSERT INTO `wp_wfStatus` VALUES (27238,1447498624.614361,2,'info','Starting DNS scan for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (27239,1447498624.620628,2,'info','Scanning DNS A record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (27240,1447498624.621707,2,'info','Scanning DNS MX record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (27241,1447498624.622407,10,'info','SUM_ENDOK:Scanning DNS for unauthorized changes');
INSERT INTO `wp_wfStatus` VALUES (27242,1447498624.624024,10,'info','SUM_START:Scanning to check available disk space');
INSERT INTO `wp_wfStatus` VALUES (25712,1446557635.545265,2,'info','Wordfence used 23.06MB of memory for scan. Server peak memory usage was: 43.65MB');
INSERT INTO `wp_wfStatus` VALUES (26229,1446868129.138096,2,'info','Analyzed 1100 files containing 12.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26230,1446868129.257664,2,'info','Analyzed 1200 files containing 14.27 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26891,1447316520.901020,2,'info','Scanned contents of 16 additional files at 156.14 per second');
INSERT INTO `wp_wfStatus` VALUES (25790,1446571734.221840,1,'info','-------------------');
INSERT INTO `wp_wfStatus` VALUES (26406,1446973964.254685,2,'info','Asking Wordfence to check URL\'s against malware list.');
INSERT INTO `wp_wfStatus` VALUES (26093,1446768929.176183,2,'info','Examining URLs found in posts we scanned for dangerous websites');
INSERT INTO `wp_wfStatus` VALUES (26094,1446768929.176447,2,'info','Checking 1 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (26811,1447251207.488290,2,'info','Asking Wordfence to check URL\'s against malware list.');
INSERT INTO `wp_wfStatus` VALUES (26073,1446768927.647570,2,'info','Analyzed 1700 files containing 21.71 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26072,1446768927.523778,2,'info','Analyzed 1600 files containing 20.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26070,1446768927.296252,2,'info','Analyzed 1400 files containing 18.56 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27229,1447498624.354933,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (27168,1447438399.893121,1,'info','Scan Complete. Scanned 1818 files, 4 plugins, 4 themes, 5 pages, 1 comments and 3763 records in 13 seconds.');
INSERT INTO `wp_wfStatus` VALUES (26992,1447370643.256833,2,'info','Starting password strength check on 1 users.');
INSERT INTO `wp_wfStatus` VALUES (26993,1447370643.495584,10,'info','SUM_ENDOK:Scanning for weak passwords');
INSERT INTO `wp_wfStatus` VALUES (26487,1447062435.529489,2,'info','Asking Wordfence to check URL\'s against malware list.');
INSERT INTO `wp_wfStatus` VALUES (27163,1447438399.256433,2,'info','The disk has 30894.86 MB space available');
INSERT INTO `wp_wfStatus` VALUES (27164,1447438399.256745,10,'info','SUM_ENDOK:Scanning to check available disk space');
INSERT INTO `wp_wfStatus` VALUES (26323,1446922212.839124,2,'info','Starting scan of file contents');
INSERT INTO `wp_wfStatus` VALUES (25733,1446571729.629518,2,'info','Analyzed 100 files containing 1.36 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25734,1446571729.734074,2,'info','Analyzed 200 files containing 2.44 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26729,1447225948.850116,2,'info','Scanned contents of 15 additional files at 150.04 per second');
INSERT INTO `wp_wfStatus` VALUES (26728,1447225948.749729,2,'info','Starting scan of file contents');
INSERT INTO `wp_wfStatus` VALUES (26547,1447090348.829602,2,'info','Analyzed 500 files containing 6.14 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26981,1447370642.938456,2,'info','Done database scan');
INSERT INTO `wp_wfStatus` VALUES (26490,1447062435.876832,2,'info','Done file contents scan');
INSERT INTO `wp_wfStatus` VALUES (26929,1447370630.650896,10,'info','SUM_PREP:Preparing a new scan.');
INSERT INTO `wp_wfStatus` VALUES (25739,1446571730.309000,2,'info','Analyzed 700 files containing 9.55 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26873,1447316519.210625,2,'info','Analyzed 700 files containing 9.55 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26571,1447090351.096229,2,'info','Done file contents scan');
INSERT INTO `wp_wfStatus` VALUES (27001,1447370643.510775,2,'info','The disk has 30902.20 MB space available');
INSERT INTO `wp_wfStatus` VALUES (27002,1447370643.511072,10,'info','SUM_ENDOK:Scanning to check available disk space');
INSERT INTO `wp_wfStatus` VALUES (25745,1446571730.947011,2,'info','Analyzed 1300 files containing 16.07 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25744,1446571730.806119,2,'info','Analyzed 1200 files containing 14.27 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27123,1447438396.796987,2,'info','Analyzed 1400 files containing 18.56 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27122,1447438396.651040,2,'info','Analyzed 1300 files containing 16.07 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26814,1447251207.781167,2,'info','Done file contents scan');
INSERT INTO `wp_wfStatus` VALUES (26813,1447251207.779925,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (25743,1446571730.688006,2,'info','Analyzed 1100 files containing 12.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25742,1446571730.582176,2,'info','Analyzed 1000 files containing 11.22 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25741,1446571730.470965,2,'info','Analyzed 900 files containing 9.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27013,1447399189.256590,10,'info','SUM_PAIDONLY:Checking if your IP is generating spam is for paid members only');
INSERT INTO `wp_wfStatus` VALUES (26825,1447251208.681243,2,'info','Done examining URLs');
INSERT INTO `wp_wfStatus` VALUES (26328,1446922213.240025,2,'info','Done file contents scan');
INSERT INTO `wp_wfStatus` VALUES (26651,1447177346.074064,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26305,1446922211.087983,2,'info','Analyzed 600 files containing 7.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26304,1446922210.963275,2,'info','Analyzed 500 files containing 6.14 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26303,1446922210.857847,2,'info','Analyzed 400 files containing 5.25 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27124,1447438396.903763,2,'info','Analyzed 1500 files containing 19.43 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26988,1447370643.249600,10,'info','SUM_ENDOK:Scanning posts for URL\'s in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (26987,1447370643.248329,2,'info','Done examining URLs');
INSERT INTO `wp_wfStatus` VALUES (27092,1447438386.151250,10,'info','SUM_PAIDONLY:Remote scan of public facing site only available to paid members');
INSERT INTO `wp_wfStatus` VALUES (27091,1447438386.147314,10,'info','SUM_PREP:Preparing a new scan.');
INSERT INTO `wp_wfStatus` VALUES (26146,1446780516.001110,2,'info','Analyzed 900 files containing 9.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26186,1446780519.033839,2,'info','Scanning DNS A record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26187,1446780519.036733,2,'info','Scanning DNS MX record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26944,1447370639.558686,10,'info','SUM_START:Comparing core WordPress files against originals in repository');
INSERT INTO `wp_wfStatus` VALUES (25863,1446651401.951765,2,'info','Scanning DNS MX record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26681,1447177347.985635,1,'info','-------------------');
INSERT INTO `wp_wfStatus` VALUES (26682,1447177347.985821,1,'info','Scan Complete. Scanned 1818 files, 4 plugins, 4 themes, 5 pages, 1 comments and 3798 records in 13 seconds.');
INSERT INTO `wp_wfStatus` VALUES (25866,1446651401.954439,2,'info','Total disk space: 46.9759GB -- Free disk space: 30.2696GB');
INSERT INTO `wp_wfStatus` VALUES (25867,1446651401.954602,2,'info','The disk has 30996.09 MB space available');
INSERT INTO `wp_wfStatus` VALUES (26632,1447177344.190663,2,'info','Analyzed 900 files containing 9.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25829,1446651399.491877,2,'info','Analyzed 1600 files containing 20.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25828,1446651399.368674,2,'info','Analyzed 1500 files containing 19.43 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26742,1447225949.797709,2,'info','Checking 1 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (25832,1446651399.803547,2,'info','Analyzed 1818 files containing 24.98 MB of data.');
INSERT INTO `wp_wfStatus` VALUES (25831,1446651399.770396,2,'info','Analyzed 1800 files containing 24.58 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26890,1447316520.797752,2,'info','Starting scan of file contents');
INSERT INTO `wp_wfStatus` VALUES (26566,1447090350.643324,2,'info','Starting scan of file contents');
INSERT INTO `wp_wfStatus` VALUES (27084,1447399199.135496,10,'info','SUM_START:Scanning for old themes, plugins and core files');
INSERT INTO `wp_wfStatus` VALUES (27083,1447399199.133975,10,'info','SUM_ENDOK:Scanning to check available disk space');
INSERT INTO `wp_wfStatus` VALUES (27082,1447399199.133664,2,'info','The disk has 30896.74 MB space available');
INSERT INTO `wp_wfStatus` VALUES (26313,1446922212.005852,2,'info','Analyzed 1400 files containing 18.56 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25804,1446651396.228191,2,'info','Getting theme list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26720,1447225948.154236,2,'info','Analyzed 1600 files containing 20.73 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27014,1447399191.259999,10,'info','SUM_START:Scanning your site for the HeartBleed vulnerability');
INSERT INTO `wp_wfStatus` VALUES (26938,1447370638.402673,2,'info','Getting theme list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26939,1447370638.405480,2,'info','Found 4 themes');
INSERT INTO `wp_wfStatus` VALUES (27207,1447498622.440667,2,'info','Analyzed 1700 files containing 21.71 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27208,1447498622.577937,2,'info','Analyzed 1800 files containing 24.58 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26716,1447225947.664147,2,'info','Analyzed 1200 files containing 14.27 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26719,1447225948.043444,2,'info','Analyzed 1500 files containing 19.42 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26718,1447225947.936870,2,'info','Analyzed 1400 files containing 18.57 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25805,1446651396.237657,2,'info','Found 4 themes');
INSERT INTO `wp_wfStatus` VALUES (27209,1447498622.600810,2,'info','Analyzed 1818 files containing 24.98 MB of data.');
INSERT INTO `wp_wfStatus` VALUES (26717,1447225947.799946,2,'info','Analyzed 1300 files containing 16.09 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26199,1446868058.755764,1,'info','Scheduled Wordfence scan starting at Friday 6th of November 2015 11:47:38 PM');
INSERT INTO `wp_wfStatus` VALUES (25920,1446711254.162222,2,'info','Asking Wordfence to check URL\'s against malware list.');
INSERT INTO `wp_wfStatus` VALUES (26810,1447251207.488090,2,'info','Scanned contents of 16 additional files at 144.02 per second');
INSERT INTO `wp_wfStatus` VALUES (27128,1447438397.302424,2,'info','Analyzed 1818 files containing 24.98 MB of data.');
INSERT INTO `wp_wfStatus` VALUES (27129,1447438397.302819,10,'info','SUM_ENDOK:Comparing core WordPress files against originals in repository');
INSERT INTO `wp_wfStatus` VALUES (27130,1447438397.303893,10,'info','SUM_ENDOK:Scanning for known malware files');
INSERT INTO `wp_wfStatus` VALUES (27131,1447438397.312275,10,'info','SUM_START:Scanning file contents for infections and vulnerabilities');
INSERT INTO `wp_wfStatus` VALUES (25871,1446651402.592080,1,'info','-------------------');
INSERT INTO `wp_wfStatus` VALUES (26266,1446868131.950587,2,'info','Starting DNS scan for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26267,1446868132.010943,2,'info','Scanning DNS A record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26268,1446868132.013219,2,'info','Scanning DNS MX record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26730,1447225948.850301,2,'info','Asking Wordfence to check URL\'s against malware list.');
INSERT INTO `wp_wfStatus` VALUES (26731,1447225948.852085,2,'info','Checking 30 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (26732,1447225949.197472,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26733,1447225949.198707,2,'info','Done file contents scan');
INSERT INTO `wp_wfStatus` VALUES (26956,1447370640.515468,2,'info','Analyzed 900 files containing 9.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26957,1447370640.621893,2,'info','Analyzed 1000 files containing 11.22 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26958,1447370640.721822,2,'info','Analyzed 1100 files containing 12.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26579,1447090351.663592,2,'info','Examining URLs found in posts we scanned for dangerous websites');
INSERT INTO `wp_wfStatus` VALUES (25990,1446751398.912364,2,'info','Analyzed 1500 files containing 19.43 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26034,1446751401.856485,1,'info','Scan Complete. Scanned 1818 files, 4 plugins, 4 themes, 5 pages, 1 comments and 3677 records in 13 seconds.');
INSERT INTO `wp_wfStatus` VALUES (27085,1447399199.448094,10,'info','SUM_ENDBAD:Scanning for old themes, plugins and core files');
INSERT INTO `wp_wfStatus` VALUES (27224,1447498623.992119,2,'info','Done database scan');
INSERT INTO `wp_wfStatus` VALUES (27223,1447498623.721671,2,'info','Starting scan of database');
INSERT INTO `wp_wfStatus` VALUES (26243,1446868130.546504,2,'info','Scanned contents of 16 additional files at 140.56 per second');
INSERT INTO `wp_wfStatus` VALUES (26057,1446768925.797015,2,'info','Analyzed 100 files containing 1.36 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26058,1446768925.908649,2,'info','Analyzed 200 files containing 2.44 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26059,1446768926.042667,2,'info','Analyzed 300 files containing 4.66 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26060,1446768926.140017,2,'info','Analyzed 400 files containing 5.25 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26061,1446768926.247241,2,'info','Analyzed 500 files containing 6.14 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26062,1446768926.367073,2,'info','Analyzed 600 files containing 7.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26063,1446768926.491298,2,'info','Analyzed 700 files containing 9.55 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26064,1446768926.576792,2,'info','Analyzed 800 files containing 9.6 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25976,1446751397.338717,2,'info','Analyzed 100 files containing 1.36 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26472,1447062434.165803,2,'info','Analyzed 1100 files containing 12.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27047,1447399197.164767,2,'info','Analyzed 1818 files containing 24.98 MB of data.');
INSERT INTO `wp_wfStatus` VALUES (25980,1446751397.794066,2,'info','Analyzed 500 files containing 6.14 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26164,1446780517.578838,2,'info','Checking 30 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (25872,1446651402.592247,1,'info','Scan Complete. Scanned 1818 files, 4 plugins, 4 themes, 5 pages, 1 comments and 3608 records in 14 seconds.');
INSERT INTO `wp_wfStatus` VALUES (27110,1447438395.294702,2,'info','Analyzed 100 files containing 1.36 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27111,1447438395.399131,2,'info','Analyzed 200 files containing 2.44 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26788,1447251205.183934,2,'info','Analyzed 300 files containing 4.66 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26532,1447090347.149074,2,'info','Found 4 plugins');
INSERT INTO `wp_wfStatus` VALUES (26979,1447370642.343606,10,'info','SUM_START:Scanning database for infections and vulnerabilities');
INSERT INTO `wp_wfStatus` VALUES (26980,1447370642.674646,2,'info','Starting scan of database');
INSERT INTO `wp_wfStatus` VALUES (26003,1446751400.052012,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26004,1446751400.053277,2,'info','Done file contents scan');
INSERT INTO `wp_wfStatus` VALUES (26672,1447177347.346141,2,'info','Scanning DNS A record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26656,1447177346.421350,2,'info','Starting scan of database');
INSERT INTO `wp_wfStatus` VALUES (26300,1446922210.504812,2,'info','Analyzed 100 files containing 1.36 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26301,1446922210.623227,2,'info','Analyzed 200 files containing 2.44 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25756,1446571731.947749,2,'info','Starting scan of file contents');
INSERT INTO `wp_wfStatus` VALUES (25757,1446571732.052786,2,'info','Scanned contents of 16 additional files at 152.92 per second');
INSERT INTO `wp_wfStatus` VALUES (26812,1447251207.489425,2,'info','Checking 30 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (26428,1446973965.786374,2,'info','Starting DNS scan for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26429,1446973965.794829,2,'info','Scanning DNS A record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26430,1446973965.797236,2,'info','Scanning DNS MX record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26962,1447370641.210417,2,'info','Analyzed 1500 files containing 19.43 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26153,1446780516.830630,2,'info','Analyzed 1600 files containing 20.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26799,1447251206.434517,2,'info','Analyzed 1400 files containing 18.56 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26798,1447251206.241839,2,'info','Analyzed 1300 files containing 16.07 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26932,1447370634.655130,10,'info','SUM_PAIDONLY:Checking if your IP is generating spam is for paid members only');
INSERT INTO `wp_wfStatus` VALUES (25793,1446571734.226105,2,'info','Wordfence used 23.06MB of memory for scan. Server peak memory usage was: 43.65MB');
INSERT INTO `wp_wfStatus` VALUES (27140,1447438398.039613,10,'info','SUM_ENDOK:Scanning files for URLs in Google\'s Safe Browsing List');
INSERT INTO `wp_wfStatus` VALUES (27141,1447438398.041216,10,'info','SUM_START:Scanning database for infections and vulnerabilities');
INSERT INTO `wp_wfStatus` VALUES (27142,1447438398.384281,2,'info','Starting scan of database');
INSERT INTO `wp_wfStatus` VALUES (27143,1447438398.659510,2,'info','Done database scan');
INSERT INTO `wp_wfStatus` VALUES (27144,1447438398.660310,10,'info','SUM_ENDOK:Scanning database for infections and vulnerabilities');
INSERT INTO `wp_wfStatus` VALUES (25830,1446651399.617252,2,'info','Analyzed 1700 files containing 21.71 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26603,1447090352.897432,2,'info','Wordfence used 23.06MB of memory for scan. Server peak memory usage was: 43.65MB');
INSERT INTO `wp_wfStatus` VALUES (26863,1447316518.416814,10,'info','SUM_START:Comparing core WordPress files against originals in repository');
INSERT INTO `wp_wfStatus` VALUES (26600,1447090352.894608,1,'info','-------------------');
INSERT INTO `wp_wfStatus` VALUES (26601,1447090352.894781,1,'info','Scan Complete. Scanned 1818 files, 4 plugins, 4 themes, 5 pages, 1 comments and 3852 records in 13 seconds.');
INSERT INTO `wp_wfStatus` VALUES (26864,1447316518.418222,10,'info','SUM_DISABLED:Skipping theme scan');
INSERT INTO `wp_wfStatus` VALUES (26569,1447090350.749630,2,'info','Checking 30 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (25921,1446711254.163438,2,'info','Checking 30 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (26317,1446922212.460452,2,'info','Analyzed 1800 files containing 24.58 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26551,1447090349.223995,2,'info','Analyzed 900 files containing 9.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26276,1446868132.655157,1,'info','-------------------');
INSERT INTO `wp_wfStatus` VALUES (26008,1446751400.404042,2,'info','Starting scan of database');
INSERT INTO `wp_wfStatus` VALUES (26554,1447090349.545709,2,'info','Analyzed 1200 files containing 14.27 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26871,1447316518.976428,2,'info','Analyzed 500 files containing 6.14 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26570,1447090351.095023,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (25699,1446557634.890767,2,'info','Starting DNS scan for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (25700,1446557634.898860,2,'info','Scanning DNS A record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (25701,1446557634.901017,2,'info','Scanning DNS MX record for gmagigolo.com');
INSERT INTO `wp_wfStatus` VALUES (26870,1447316518.874483,2,'info','Analyzed 400 files containing 5.25 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26479,1447062435.023259,2,'info','Analyzed 1800 files containing 24.58 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26480,1447062435.050066,2,'info','Analyzed 1818 files containing 24.98 MB of data.');
INSERT INTO `wp_wfStatus` VALUES (26152,1446780516.714730,2,'info','Analyzed 1500 files containing 19.43 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26151,1446780516.612602,2,'info','Analyzed 1400 files containing 18.56 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26386,1446973962.350427,2,'info','Analyzed 600 files containing 7.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26387,1446973962.468604,2,'info','Analyzed 700 files containing 9.55 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26830,1447251208.687639,2,'info','Starting password strength check on 1 users.');
INSERT INTO `wp_wfStatus` VALUES (27109,1447438395.174804,10,'info','SUM_START:Scanning for known malware files');
INSERT INTO `wp_wfStatus` VALUES (26899,1447316521.527641,2,'info','Starting scan of database');
INSERT INTO `wp_wfStatus` VALUES (26036,1446751401.859213,2,'info','Wordfence used 23.05MB of memory for scan. Server peak memory usage was: 43.65MB');
INSERT INTO `wp_wfStatus` VALUES (26786,1447251204.946517,2,'info','Analyzed 100 files containing 1.36 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26787,1447251205.048383,2,'info','Analyzed 200 files containing 2.44 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26631,1447177344.104915,2,'info','Analyzed 800 files containing 9.6 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26434,1446973965.800000,2,'info','The disk has 30986.55 MB space available');
INSERT INTO `wp_wfStatus` VALUES (27054,1447399197.609577,2,'info','Asking Wordfence to check URL\'s against malware list.');
INSERT INTO `wp_wfStatus` VALUES (26959,1447370640.836698,2,'info','Analyzed 1200 files containing 14.27 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26960,1447370640.971324,2,'info','Analyzed 1300 files containing 16.07 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25852,1446651401.542705,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (25853,1446651401.543123,2,'info','Done examining URLs');
INSERT INTO `wp_wfStatus` VALUES (26677,1447177347.351310,2,'info','The disk has 30983.37 MB space available');
INSERT INTO `wp_wfStatus` VALUES (27196,1447498621.162428,2,'info','Analyzed 600 files containing 7.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27195,1447498621.043617,2,'info','Analyzed 500 files containing 6.14 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26084,1446768928.559186,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (26085,1446768928.560385,2,'info','Done file contents scan');
INSERT INTO `wp_wfStatus` VALUES (26596,1447090352.259399,2,'info','The disk has 30987.21 MB space available');
INSERT INTO `wp_wfStatus` VALUES (26867,1447316518.538778,2,'info','Analyzed 100 files containing 1.36 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26866,1447316518.419989,10,'info','SUM_START:Scanning for known malware files');
INSERT INTO `wp_wfStatus` VALUES (26865,1447316518.418395,10,'info','SUM_DISABLED:Skipping plugin scan');
INSERT INTO `wp_wfStatus` VALUES (26083,1446768928.268312,2,'info','Checking 30 host keys against Wordfence scanning servers.');
INSERT INTO `wp_wfStatus` VALUES (26971,1447370641.935638,2,'info','Starting scan of file contents');
INSERT INTO `wp_wfStatus` VALUES (25747,1446571731.197361,2,'info','Analyzed 1500 files containing 19.43 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25746,1446571731.091042,2,'info','Analyzed 1400 files containing 18.56 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25748,1446571731.315670,2,'info','Analyzed 1600 files containing 20.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25749,1446571731.435021,2,'info','Analyzed 1700 files containing 21.71 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25750,1446571731.574043,2,'info','Analyzed 1800 files containing 24.58 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (25751,1446571731.596268,2,'info','Analyzed 1818 files containing 24.98 MB of data.');
INSERT INTO `wp_wfStatus` VALUES (26652,1447177346.075366,2,'info','Done file contents scan');
INSERT INTO `wp_wfStatus` VALUES (27212,1447498622.611010,10,'info','SUM_START:Scanning file contents for infections and vulnerabilities');
INSERT INTO `wp_wfStatus` VALUES (27211,1447498622.602347,10,'info','SUM_ENDOK:Scanning for known malware files');
INSERT INTO `wp_wfStatus` VALUES (26439,1446973966.436587,1,'info','Scan Complete. Scanned 1818 files, 4 plugins, 4 themes, 5 pages, 1 comments and 3941 records in 14 seconds.');
INSERT INTO `wp_wfStatus` VALUES (26882,1447316520.187594,2,'info','Analyzed 1600 files containing 20.74 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26883,1447316520.302808,2,'info','Analyzed 1700 files containing 21.71 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26884,1447316520.435035,2,'info','Analyzed 1800 files containing 24.58 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26438,1446973966.436353,1,'info','-------------------');
INSERT INTO `wp_wfStatus` VALUES (27063,1447399198.507462,10,'info','SUM_ENDOK:Scanning database for infections and vulnerabilities');
INSERT INTO `wp_wfStatus` VALUES (26766,1447251135.715377,1,'info','Scheduled Wordfence scan starting at Wednesday 11th of November 2015 10:12:15 AM');
INSERT INTO `wp_wfStatus` VALUES (26191,1446780519.039509,2,'info','The disk has 30991.32 MB space available');
INSERT INTO `wp_wfStatus` VALUES (26451,1447062431.687728,2,'info','Found 4 plugins');
INSERT INTO `wp_wfStatus` VALUES (26452,1447062431.689304,2,'info','Getting theme list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26450,1447062431.680507,2,'info','Getting plugin list from WordPress');
INSERT INTO `wp_wfStatus` VALUES (26449,1447062431.386220,1,'info','Contacting Wordfence to initiate scan');
INSERT INTO `wp_wfStatus` VALUES (26195,1446780519.364364,1,'info','-------------------');
INSERT INTO `wp_wfStatus` VALUES (26196,1446780519.364537,1,'info','Scan Complete. Scanned 1818 files, 4 plugins, 4 themes, 5 pages, 1 comments and 3861 records in 14 seconds.');
INSERT INTO `wp_wfStatus` VALUES (26945,1447370639.559248,10,'info','SUM_DISABLED:Skipping theme scan');
INSERT INTO `wp_wfStatus` VALUES (26198,1446780519.367146,2,'info','Wordfence used 23.05MB of memory for scan. Server peak memory usage was: 43.65MB');
INSERT INTO `wp_wfStatus` VALUES (26743,1447225950.087220,2,'info','Done host key check.');
INSERT INTO `wp_wfStatus` VALUES (25905,1446711252.822488,2,'info','Analyzed 1100 files containing 12.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (26822,1447251208.352368,2,'info','Examining URLs found in posts we scanned for dangerous websites');
INSERT INTO `wp_wfStatus` VALUES (27114,1447438395.748139,2,'info','Analyzed 500 files containing 6.14 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27115,1447438395.871234,2,'info','Analyzed 600 files containing 7.64 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27116,1447438395.997471,2,'info','Analyzed 700 files containing 9.55 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27117,1447438396.082575,2,'info','Analyzed 800 files containing 9.6 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27203,1447498621.952625,2,'info','Analyzed 1300 files containing 16.07 MB of data so far');
INSERT INTO `wp_wfStatus` VALUES (27202,1447498621.812548,2,'info','Analyzed 1200 files containing 14.27 MB of data so far');
/*!40000 ALTER TABLE `wp_wfStatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wfThrottleLog`
--

DROP TABLE IF EXISTS `wp_wfThrottleLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wfThrottleLog` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `startTime` int(10) unsigned NOT NULL,
  `endTime` int(10) unsigned NOT NULL,
  `timesThrottled` int(10) unsigned NOT NULL,
  `lastReason` varchar(255) NOT NULL,
  PRIMARY KEY (`IP`),
  KEY `k2` (`endTime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wfThrottleLog`
--

LOCK TABLES `wp_wfThrottleLog` WRITE;
/*!40000 ALTER TABLE `wp_wfThrottleLog` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wfThrottleLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wfVulnScanners`
--

DROP TABLE IF EXISTS `wp_wfVulnScanners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wfVulnScanners` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `ctime` int(10) unsigned NOT NULL,
  `hits` int(10) unsigned NOT NULL,
  PRIMARY KEY (`IP`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wfVulnScanners`
--

LOCK TABLES `wp_wfVulnScanners` WRITE;
/*!40000 ALTER TABLE `wp_wfVulnScanners` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wfVulnScanners` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-14  5:59:27
